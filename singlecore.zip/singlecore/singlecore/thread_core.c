#include "libmc/libmc.h"

#include "thread_core.h"

struct thread_master_control_block *fgmt_get_tmcb() {
    //printf("TMCB = %x\n", THREAD_MASTER_CONTROL_BLOCK_ADDR);
    return (struct thread_master_control_block *) THREAD_MASTER_CONTROL_BLOCK_ADDR;
}

struct thread_control_block *fgmt_get_tcb(native_t thread) {
    //printf("TCB(%d) = %x\n", thread, &fgmt_get_tmcb()->thread_control_blocks[thread]);
    return &fgmt_get_tmcb()->thread_control_blocks[thread];
}

struct thread_integer_register_block *fgmt_get_irb(native_t thread) {
    //printf("IRB(%d) = %x\n", thread, &fgmt_get_tmcb()->thread_integer_register_blocks[thread]);
    return &fgmt_get_tmcb()->thread_integer_register_blocks[thread];
}

native_t fgmt_threads_in_core() {
    return mmio_read_native(&fgmt_get_tmcb()->thread_count);
}

native_t fgmt_current_thread() {
    return mmio_read_native(&fgmt_get_tmcb()->current_thread);
}

void fgmt_thread_end() {
    mmio_write_native(&fgmt_get_tcb(fgmt_current_thread())->status_word, 0);
    while(1) ;
}

void fgmt_pause_thread(native_t thread_id, native_t pause_for) {
    mmio_write_native(&fgmt_get_tcb(thread_id)->pause_for, pause_for);
} 

void fgmt_pause_current_thread(native_t pause_for) {
    fgmt_pause_thread(fgmt_current_thread(), pause_for);
} 


void fgmt_thread_start(native_t thread, void *fptr, native_t a0, native_t a1, void *sp) {
    volatile struct thread_integer_register_block *irb = fgmt_get_irb(thread);
    volatile struct thread_control_block *tcb = fgmt_get_tcb(thread);
  
    native_t sp_i = (native_t)(sp);
    if (sp_i & 0x8)
        sp_i -= sizeof(uint64_t); 
    irb->regs[REG_A0] = a0;
    irb->regs[REG_A1] = a1;
    irb->regs[REG_SP] = (native_t) sp_i;
    tcb->pc = (native_t) fptr;
    tcb->status_word = THREAD_STATUS_BIT_ENABLED;
}

#define THREAD_STACK_SIZE 2048
#define THREADS_TO_TEST 5

uint8_t thread_stack[THREADS_TO_TEST][THREAD_STACK_SIZE];

#define LOCKED 1
#define UNLOCKED 0
#define MAX_BACKOFF_DELAY 16
typedef native_t lock_t;

void lock(lock_t *lock_addr) {
    int spin_count = 0;
    int delay_for = 1;
    
    while (true) {
        //while (mmio_read64(lock_addr) == LOCKED)
        //    ;
        if (amoswap64((uint64_t *)lock_addr, LOCKED) == UNLOCKED) {
            return;
        }
        //pause(64);
        //if (*lock_addr == UNLOCKED) {
        //    *lock_addr = LOCKED;
        //    return;
        //}
        ++spin_count;
        if (delay_for < MAX_BACKOFF_DELAY)
            delay_for = delay_for << 2;
        //if (spin_count > 1000)
        //    printf("Probable deadlock on %x\n", lock_addr);
        fgmt_pause_current_thread(delay_for);
    }
}

void unlock(lock_t *lock_addr) {
    mmio_write64(lock_addr, UNLOCKED);
}

lock_t libc_lock = UNLOCKED;

extern void puts(char *);
int thread_worker(native_t a0) {
    putc('$');
    putc('\n');
//    puts("First greetings from the second thread\n");

    for (int i = 0; i < 10; i++) {
        lock(&libc_lock);
        puts("Treetings from the second thread");
        unlock(&libc_lock);
    }
    lock(&libc_lock);
    puts("Exiting second thread loop");
    unlock(&libc_lock);
    fgmt_thread_end();
    //
    //
    puts("this should never execute\n");
}

int thread_test() {

    printf("Thread test\n");
    printf("Core supports %d threads\n", fgmt_threads_in_core());
    printf("Current lead core is %d\n", fgmt_current_thread());
    //printf("thread stack will be %llx\n", &thread_stack[THREAD_STACK_SIZE - 24]);
    printf("lock address: %llx\n", &libc_lock);
    lock(&libc_lock);
    unlock(&libc_lock);
    printf("Carry on\n");
    //printf("About to start thread\n");
    for(int i = 0; i < THREADS_TO_TEST; i++)
        fgmt_thread_start(i + 1, thread_worker, 0x42, 0, &thread_stack[i][THREAD_STACK_SIZE - 32]);
    putc('%');
    putc('\n');

    //while(1);
//    while(fgmt_get_tcb(1)->status_word & THREAD_STATUS_BIT_ENABLED) {
        for (int i = 0; i < 10; i++) {
            lock(&libc_lock);
            puts("Greetings from the main thread");
            unlock(&libc_lock);
        }
//    }
    lock(&libc_lock);
    puts("#\n");
    printf("-- thread_id %d supported_threads: %d\n", fgmt_current_thread(), fgmt_threads_in_core());
    unlock(&libc_lock);
}

