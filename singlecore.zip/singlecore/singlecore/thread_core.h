#ifndef _thread_core_h
#define _thread_core_h

#include "libmc/libmc.h"
#include "ports.h"


#define THREAD_STATUS_BIT_ENABLED  0x01    // read/write
#define THREAD_STATUS_BIT_STALLED  0x02    // read only
#define THREAD_MASTER_CONTROL_BLOCK_ADDR (FGMT_INTERNAL_MMIO_LOW + 0x0010)

struct thread_control_block {
    volatile native_t status_word;                // variable
    volatile native_t pc;                         // read/write
    volatile native_t pause_for;
    volatile native_t reserved;
};

struct thread_integer_register_block {
    volatile native_t regs[32];           // read/write

#define REG_SP  2
#define REG_A0  10
#define REG_A1  11
};

struct thread_master_control_block {
    native_t current_thread;                                          // read only
    native_t thread_count;                                   // read only
    struct thread_control_block *thread_control_blocks;     // read only
    struct thread_integer_register_block *thread_integer_register_blocks;   // read only
};

// Interface to core threads
void fgmt_thread_start(native_t thread, void *fptr, native_t a0, native_t a1, void *sp);
native_t fgmt_threads_in_core();
native_t fgmt_current_thread();
static inline native_t current_thread() { return fgmt_current_thread(); }
void fgmt_thread_end();
void fgmt_pause_thread(native_t thread_id, native_t pause_for);
void fgmt_pause_current_thread(native_t pause_for);

#define LOCKED 1
#define UNLOCKED 0
typedef native_t lock_t;
void lock(lock_t *lock_addr);
void unlock(lock_t *lock_addr);
#endif
