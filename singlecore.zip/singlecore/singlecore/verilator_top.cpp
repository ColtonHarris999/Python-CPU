#include <verilated.h>          // Defines common routines
#include <iostream>             // Need std::cout
#include "Vtop.h"               // From Verilating "top.v"
#include "verilated_vcd_c.h"
//#include "Vtest_manycore_test_manycore.h"               // From Verilating "top.v"
//#include "Vtest_manycore_core__pi1.h"
//#include "Vtest_manycore_armv2_cpu__S41000000.h"

Vtop *top;                      // Instantiation of module

vluint64_t main_time = 0;       // Current simulation time
// This is a 64-bit integer to reduce wrap over issues and
// allow modulus.  This is in units of the timeprecision
// used in Verilog (or from --timescale-override)

double sc_time_stamp () {       // Called by $time in Verilog
    return main_time;           // converts to double, to match
                               // what SystemC does
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);   // Remember args

    top = new Vtop;             // Create instance

  // init trace dump
//#define TRACE

#ifdef TRACE
    Verilated::traceEverOn(true);
    VerilatedVcdC* tfp = new VerilatedVcdC;
    top->trace(tfp, 99);
    tfp->open ("cpu.vcd");
#endif
    top->reset = 1;           // Set some inputs

    int i = 0;
    while (!Verilated::gotFinish() /*&& main_time < 8000*/ ) {
        if (main_time > 10)
            top->reset = 0;   // Deassert reset
        top->clk = 1;
#ifdef TRACE
        tfp->dump(4*i+0);
#endif
        top->eval();
        top->clk = 0;
#ifdef TRACE
        tfp->dump(4*i+1);
#endif
        top->eval();
        if (top->halt == 1)
            break;
        main_time++;            // Time passes...
#ifdef TRACE
        if (main_time > 1000)
            break;
#endif
        ++i;
    }
#ifdef TRACE
    tfp->close();
#endif
    top->final();               // Done simulating
    //    // (Though this example doesn't get here)
    delete top;
}
