`include "system.sv"
`include "base.sv"
`include "clean_core.sv"
`include "memory.sv"

`include "cache.sv"
module top(input clk, input reset, output logic halt);


memory_io_req 	inst_mem_req;
memory_io_rsp 	inst_mem_rsp;
memory_io_req   data_mem_req;
memory_io_rsp   data_mem_rsp;
memory_io_req   data_mem_req_from_proc;
memory_io_rsp   data_mem_rsp_to_proc;

clean_core core(
	.clk(clk)
	,.reset(reset)
`ifdef __64bit__
	,.reset_pc(64'h8000_0000_0100_0000)
`else 
    ,.reset_pc(32'h0001_0000)
`endif
	,.inst_mem_req(inst_mem_req)
	,.inst_mem_rsp(inst_mem_rsp)

	,.data_mem_req(data_mem_req_from_proc)
	,.data_mem_rsp(data_mem_rsp_to_proc)
    );

memory_io_req   data_mem_req1;
memory_io_rsp   data_mem_rsp1;

cache #(.set_size(32)
    ,.line_size(64)
    ,.set_count(4)
    ,.mshr_count(4)
    ) data_cache (
    .clk(clk)
    ,.reset(reset)
    ,.enabled_in(true)
    ,.upstream_mem_req_in(data_mem_req_from_proc)
    ,.upstream_mem_rsp_out(data_mem_rsp_to_proc)
    ,.downstream_mem_req_out(data_mem_req1)
    ,.downstream_mem_rsp_in(data_mem_rsp1)
    );


cache #(.set_size(128)
    ,.line_size(64)
    ,.set_count(4)
    ,.mshr_count(4)
    ) data_cache_level2 (
    .clk(clk)
    ,.reset(reset)
    ,.enabled_in(true)
    ,.upstream_mem_req_in(data_mem_req1)
    ,.upstream_mem_rsp_out(data_mem_rsp1)
    ,.downstream_mem_req_out(data_mem_req)
    ,.downstream_mem_rsp_in(data_mem_rsp)
    );


/*
always_ff @(posedge clk) begin
    if (!reset && inst_mem_req.do_read != 0) begin
        $display("[%d] inst address: %x", inst_mem_req.user_tag, inst_mem_req.addr);
    end
    if (!reset && (data_mem_req.do_read != 0 || data_mem_req.do_write != 0)) begin
        $display("[%d] data address: %x r=%x w=%x v=%x", data_mem_req.user_tag, data_mem_req.addr,
            data_mem_req.do_read, data_mem_req.do_write, data_mem_req.data );
    end
end
*/

`memory #(
    .size(32'h0010_0000)
    ,.initialize_mem(true)
    ,.byte0("code0.hex")
    ,.byte1("code1.hex")
    ,.byte2("code2.hex")
    ,.byte3("code3.hex")
`ifdef __64bit__
    ,.byte4("code4.hex")
    ,.byte5("code5.hex")
    ,.byte6("code6.hex")
    ,.byte7("code7.hex")
`endif
    ,.enable_rsp_addr(true)
    ) code_mem (
    .clk(clk)
    ,.reset(reset)
    ,.req(inst_mem_req)
    ,.rsp(inst_mem_rsp)
    );

`memory #(
    .size(32'h0010_0000)
    ,.initialize_mem(true)
    ,.byte0("data0.hex")
    ,.byte1("data1.hex")
    ,.byte2("data2.hex")
    ,.byte3("data3.hex")
`ifdef __64bit__
    ,.byte4("data4.hex")
    ,.byte5("data5.hex")
    ,.byte6("data6.hex")
    ,.byte7("data7.hex")
`endif
    ,.enable_rsp_addr(true)
    ) data_mem (
    .clk(clk)
    ,.reset(reset)
    ,.req(data_mem_req)
    ,.rsp(data_mem_rsp)
    );


/*
always_ff @(posedge clk) begin
    if (data_mem_req.valid && data_mem_req.do_write != 0)
        $display("%x write: %x do_write: %x data: %x", inst_mem_req.addr, data_mem_req.addr, data_mem_req.do_write, data_mem_req.data);
    if (data_mem_req.valid && data_mem_req.do_read != 0)
        $display("%x read: %x do_read:", inst_mem_req.addr, data_mem_req.addr, data_mem_req.do_read);

end
*/
always_ff @(posedge clk)
	if (data_mem_req_from_proc.valid && data_mem_req_from_proc.addr == `word_address_size'h0002_FFF8 &&
        data_mem_req_from_proc.do_write != {(`word_address_size/8){1'b0}}) begin
		//$display("Ouptut data: %x and do_write %x", data_mem_req.data, data_mem_req.do_write);
		$write("%c", data_mem_req_from_proc.data[7:0]);
	end

always_ff @(posedge clk)
	if (data_mem_req_from_proc.valid && data_mem_req_from_proc.addr == `word_address_size'h0002_FFFC &&
        data_mem_req_from_proc.do_write != {(`word_address_size/8){1'b0}}) begin
            
		halt <= true;

        $display("Cache hits: %d fetches: %d writebacks: %d",
            data_cache.hits, data_cache.fetches, data_cache.writebacks);
        end
	//else
	//	halt <= false;

endmodule
