#!/bin/bash
#
# This file is both a bash file and a Makefile include.
#
# Edit this file and rename it to site-config.sh
#
#

# 32bit version
RISCV_PREFIX=/home/oskin/research/xpack-riscv-none-elf-gcc-14.2.0-3/bin/riscv-none-elf
RISCV_LIB=/home/oskin/research/xpack-riscv-none-elf-gcc-14.2.0-3/lib/gcc/riscv-none-elf/14.2.0/rv32i/ilp32
RISCV_MODEL=_32bit

## IF want 64bit uncomment these two lines
RISCV_LIB=/home/oskin/research/xpack-riscv-none-elf-gcc-14.2.0-3/lib/gcc/riscv-none-elf/14.2.0/rv64i/lp64
RISCV_MODEL=_64bit

