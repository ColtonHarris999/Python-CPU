#include "libmc/libmc.h"


extern int thread_test();
extern void halt();

int memory[1024];

void cache_test() {
    int i;
    for (i = 0; i < 1024; i++)
        memory[i] = i;
    for (i = 0; i < 1024; i++) {
        if (memory[i] != i)
            printf("Failure on %d got %d\n", i, memory[i]);
    }
}

int main() { 
    putc('#');
    putc('\n');
    putc('H');
    putc('i');
    putc('\n');
    puts("123456789ABCDEF\n");
    printf("Hello world : %d %d\n", atoi("55"), -55);
    cache_test();
//    thread_test();
}

