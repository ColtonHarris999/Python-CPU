### tiles_x = 4 tiles_y = 4 local_memories = 4 data_memory_size = 0x80000
.extern main
.globl _start
.text

_start:
    li      sp, (0x8000000002080000 - 16)
    call    main
    call    halt

