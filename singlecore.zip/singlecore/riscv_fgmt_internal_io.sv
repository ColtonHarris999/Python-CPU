`include "riscv.sv"

typedef struct {
    bool valid;
    riscv::word data;
    generic_thread_id_t thread_id;
    riscv::tag rs;
} cross_thread_write_register_t;

typedef struct {
    bool valid;
    generic_thread_id_t thread_id;
    bool set_enable;
    bool enable;
    bool set_pc;
    riscv::word pc;
    bool set_pause;
    riscv::word pause_for;
} cross_thread_pc_control_t;

typedef struct {
    bool valid;
    riscv::word data;  
} same_thread_io_result_t;

module fgmt_internal_control #(parameter thread_count = 16) (
     input bool valid_in
    ,input riscv::word addr_in
    ,input riscv::word data_in
    ,input [$clog2(thread_count)-1:0] thread_id_in
    ,input bool do_write_in
    ,output bool is_internal_mmio_out
    ,output cross_thread_write_register_t cross_thread_write_register_out
    ,output cross_thread_pc_control_t cross_thread_pc_control_out
    ,output same_thread_io_result_t same_thread_io_result_out
    );

import riscv::*;

localparam thread_count_l2 = $clog2(thread_count);
typedef logic [thread_count_l2 - 1:0] thread_id_t;

function automatic generic_thread_id_t cast_to_generic(input thread_id_t id);
    return $bits(generic_thread_id_t)'(id);
endfunction

function automatic thread_id_t cast_to_specific(input generic_thread_id_t id);
    return id[$bits(thread_id_t)-1:0];
endfunction

/*

 Almost all of the lower 32KB is for internal processor control
 Really anything can be mapped into this space for accessing CPU
 specific regs.  In this design there's a lot of control for
 the FGMT aspect.  But the infrastructure built for this MMIO
 mapping of CPU regs is general enough that any CPU specific reg
 can be mapped into it.

*/

localparam internal_mmio_control_low = `fgmt_internal_mmio_low;
localparam internal_mmio_control_mask = (internal_mmio_control_low - 1);
localparam internal_mmio_control_high = `fgmt_internal_mmio_high;
`define internal_mmio_size  21

// Thread control
localparam thread_master_control_block_addr = (`internal_mmio_size'h0010 + internal_mmio_control_low);
localparam thread_control_block_addr = (`internal_mmio_size'h0100 + internal_mmio_control_low);
localparam thread_integer_register_block_addr = (`internal_mmio_size'h1000 + internal_mmio_control_low);
localparam thread_integer_register_block_mask = `internal_mmio_size'(32 * `word_size_bytes - 1);
localparam thread_control_block_size = 32; // size of tcb per thread
`define thread_status_word  0
`define thread_pc           1
`define thread_pause        2
`define thread_reserved     3


// Layout of TCMCB
// thread_id
// thread_count
// addr(thread control block start)
// addr(thread integer register block start)

always_comb begin
    automatic logic [`internal_mmio_size-1:0] internal_mmio_addr = addr_in[`internal_mmio_size-1:0];

    // This is written this way because there's some bugs in V erilator..
    //cross_thread_write_register_out = {($bits(cross_thread_write_register_t)){1'b0}};
    cross_thread_write_register_out.valid = false;
    cross_thread_write_register_out.data = 0;
    cross_thread_write_register_out.rs = 0;
    cross_thread_write_register_out.thread_id = 0;

    //cross_thread_pc_control_out = {($bits(cross_thread_pc_control_t)){1'b0}};
    cross_thread_pc_control_out.valid = false;
    cross_thread_pc_control_out.pc = 0;
    cross_thread_pc_control_out.set_enable = false;
    cross_thread_pc_control_out.set_pc = false;
    cross_thread_pc_control_out.enable = false;
    //same_thread_io_result_out = {($bits(same_thread_io_result_t)){1'b0}};
    same_thread_io_result_out.valid = false;
    same_thread_io_result_out.data = 0;

    is_internal_mmio_out = false;
    if (valid_in) begin
        if (addr_in >= `word_address_size'(`fgmt_internal_mmio_low)
            && addr_in < `word_address_size'(`fgmt_internal_mmio_high))
        is_internal_mmio_out = true;
    end

    if (is_internal_mmio_out) begin
        /*
        struct thread_master_control_block {
            unsigned long current_thread;                           // read only
            unsigned long thread_count;                             // read only
            struct thread_control_block *thread_control_blocks;     // read only
            struct thread_integer_register_block *thread_integer_register_blocks;   // read only
        };
        */
        //$display("IS_INTERNAL_MMIO: %x current_thread = %x do_internal_write=%d do_internal_read=%d", internal_mmio_addr, current_thread, do_internal_write, do_internal_read);
        case (internal_mmio_addr)
            thread_master_control_block_addr: begin
                same_thread_io_result_out.valid = true;
                same_thread_io_result_out.data = `word_size'(thread_id_in);
            end
            (thread_master_control_block_addr + 1*`word_size_bytes): begin
                same_thread_io_result_out.valid = true;
                same_thread_io_result_out.data = `word_size'(thread_count);
            end
            (thread_master_control_block_addr + 2*`word_size_bytes): begin
                same_thread_io_result_out.valid = true;
                same_thread_io_result_out.data = `word_size'(thread_control_block_addr);
            end
            (thread_master_control_block_addr + 3*`word_size_bytes): begin
                same_thread_io_result_out.valid = true;
                same_thread_io_result_out.data = `word_size'(thread_integer_register_block_addr);
            end
        endcase;

        if (internal_mmio_addr >= thread_control_block_addr &&
            internal_mmio_addr < (thread_control_block_addr + thread_control_block_size * thread_count)) begin
            logic [thread_count_l2-1:0] thread_of_interest =
                thread_count_l2'(
                    (internal_mmio_addr - thread_control_block_addr) >> (
                        $clog2(`word_size_bytes) +
                        $clog2(thread_control_block_size/`word_size_bytes)));

            logic [$clog2(thread_control_block_size/`word_size_bytes)-1:0] offset =
                $clog2(thread_control_block_size/`word_size_bytes - 1)'(internal_mmio_addr >> $clog2(`word_size_bytes));

            /*
            struct thread_control_block {
                volatile unsigned long status_word;                // variable
                volatile unsigned long pc;                         // read/write
                volatile unsigned long delay;
                volatile unsigned long reserved;
            };
            */
            case (offset)
                `thread_status_word:
                    if (do_write_in != 0) begin
                        //$display("%d/%x Setting thread %d status to %x", current_thread, pc[current_thread], thread_of_interest, internal_mmio_write_data[0]);
                        cross_thread_pc_control_out.valid = true;
                        cross_thread_pc_control_out.set_enable = true;
                        cross_thread_pc_control_out.thread_id = cast_to_generic(thread_of_interest);
                        cross_thread_pc_control_out.enable = data_in[0];
                    end
                    else begin
                        //$display("Reading thread %d status", thread_of_interest);

                    end

                `thread_pc: 
                    if (do_write_in != 0) begin
                        //$display("Setting thread %d PC to %x", thread_of_interest, internal_mmio_write_data);
                        cross_thread_pc_control_out.valid = true;
                        cross_thread_pc_control_out.set_pc = true;
                        cross_thread_pc_control_out.thread_id = cast_to_generic(thread_of_interest);
                        cross_thread_pc_control_out.pc = data_in;
                    end else begin
                        //$display("Reading thread %d PC", thread_of_interest);
                        //internal_mmio_read_result = 0;//pc[thread_of_interest];
                    end
                `thread_pause:
                    if (do_write_in != 0) begin
                        cross_thread_pc_control_out.valid = true;
                        cross_thread_pc_control_out.set_pause = true;
                        cross_thread_pc_control_out.thread_id = cast_to_generic(thread_of_interest);
                        cross_thread_pc_control_out.pause_for = data_in;
                        //$display("Setting thread %d pause to %x", thread_of_interest, internal_mmio_write_data);
                    end else begin
                        //$display("Reading thread pause %d", thread_of_interest);

                    end
            endcase;
        end

        if (internal_mmio_addr >= thread_integer_register_block_addr &&
            internal_mmio_addr < (thread_integer_register_block_addr + 32 * `word_size_bytes * thread_count)) begin
            thread_id_t thread_of_interest = thread_count_l2'(internal_mmio_addr >> $clog2(`word_size_bytes) + $clog2((32 * `word_size_bytes)/`word_size_bytes));
            tag offset = 5'((internal_mmio_addr & thread_integer_register_block_mask) >> $clog2(`word_size_bytes));
            
            /*
            struct thread_integer_register_block {
                volatile native_t regs[32];           // read/write
            };
            */
            if (do_write_in != 0) begin
                //$display("MMIO cross thread write to register %d on thread %d to %x", offset, thread_of_interest, internal_mmio_write_data);
                cross_thread_write_register_out.valid = true;
                cross_thread_write_register_out.rs = offset;
                cross_thread_write_register_out.data = data_in;
                cross_thread_write_register_out.thread_id = cast_to_generic(thread_of_interest);
            end else begin
                //$display("MMIO cross thread read of register %d on thread %d", offset, thread_of_interest);

            end
            
        end
    end    

end

endmodule