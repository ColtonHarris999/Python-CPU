
`include "riscv.sv"

// can be any size >= bits needed for actual thread_id
typedef logic [19:0]    generic_thread_id_t;

`include "riscv_fgmt_internal_io.sv"

typedef struct packed {
    bool valid;
    generic_thread_id_t thread_id;
    riscv::instr32 instruction;
    riscv::word pc;
} fgmt_fetched_instruction_t;

typedef struct packed {
    bool valid;
    generic_thread_id_t thread_id;
    riscv::word pc;
} fgmt_fetch_update_pc_call_t;

typedef struct packed {
    bool _unused_;
} fgmt_fetch_update_pc_return_t;

function void fgmt_fetch_update_pc(inout fgmt_fetch_update_pc_call_t fetch_update_pc_call,
                                input generic_thread_id_t thread_id,
                                input riscv::word addr);
    fetch_update_pc_call.pc = addr;
    fetch_update_pc_call.thread_id = thread_id;
    fetch_update_pc_call.valid = true;
endfunction;

function void fgmt_fetch_update_pc_init(inout fgmt_fetch_update_pc_call_t fetch_update_pc_call);
    fetch_update_pc_call.valid = false;
    fetch_update_pc_call.thread_id = 0;
    fetch_update_pc_call.pc = 0;
endfunction;


typedef struct packed {
    bool advance;
    bool flush;
    bool all_threads;
    generic_thread_id_t thread_id;
} fgmt_stage_signal_t;

function void fgmt_stage_signal_not_advance(inout fgmt_stage_signal_t stage_signal);
    stage_signal.advance = false;
endfunction;

function void fgmt_stage_signal_flush_set(inout fgmt_stage_signal_t stage_signal, input generic_thread_id_t id);
    stage_signal.flush = true;
    stage_signal.all_threads = false;
    stage_signal.thread_id = id;
endfunction;

function void fgmt_stage_signal_init(inout fgmt_stage_signal_t stage_signal);
    stage_signal.advance = true;
    stage_signal.flush = false;
    stage_signal.all_threads = false;
    stage_signal.thread_id = 0;
endfunction;

typedef logic [7:0] pause_t;

module fgmt_fetch #(
    parameter thread_count = 16
    ) (
    input logic       clk
    ,input logic      reset
    ,input logic      [`word_address_size-1:0] reset_pc
    ,output memory_io_req   inst_mem_req
    ,input  memory_io_rsp   inst_mem_rsp

    // Read only access to global structures
    ,input bool thread_active[0:thread_count-1]
    ,input bool thread_stalled_on_data_memory[0:thread_count-1]

    // Stage control signalling
    ,input fgmt_stage_signal_t       fetch_signal_in

    // Control function interfaces
    ,input fgmt_fetch_update_pc_call_t    fgmt_fetch_update_pc_call_in
    ,output fgmt_fetch_update_pc_return_t  fgmt_fetch_update_pc_return_out

    // Fetch result
    ,output fgmt_fetched_instruction_t fgmt_fetched_instruction_out
    );
import riscv::*;

localparam thread_count_l2 = $clog2(thread_count);
typedef logic [thread_count_l2 - 1:0] thread_id_t;

function automatic generic_thread_id_t cast_to_generic(input thread_id_t id);
    return $bits(generic_thread_id_t)'(id);
endfunction

function automatic thread_id_t cast_to_specific(input generic_thread_id_t id);
    return id[$bits(thread_id_t)-1:0];
endfunction

typedef struct packed {
    bool issued;
    bool returned;
    word fetch_pc;
    word issued_pc;
    instr32 instruction;
    word  addr;
    pause_t pause_for;
}   thread_state_fetch_t;

thread_state_fetch_t thread_state_fetch[0:thread_count-1]; 
thread_id_t thread_to_issue_fetch;
bool thread_to_issue_fetch_valid;

bool decode_advance = true;

fgmt_fetched_instruction_t to_decode;
assign fgmt_fetched_instruction_out = to_decode;

word counter;

thread_id_t last_thread_to_decode;
thread_id_t last_thread_to_issue_fetch;

bool thread_to_decode_valid;
thread_id_t thread_to_decode;

always_comb begin
    automatic integer current_thread_i = 0, i = 0, ii = 0;
    automatic bool next_thread_valid;
    automatic thread_id_t next_thread;
    automatic thread_id_t inst_mem_rsp_thread = inst_mem_rsp.user_tag[thread_count_l2 - 1:0];

    inst_mem_req = memory_io_no_req;

    thread_to_decode_valid = false;
    thread_to_decode = 0;

    current_thread_i = 0;
    i  =0;
    ii = 0;
    next_thread_valid = false;
    next_thread = 0;
    current_thread_i = integer'(last_thread_to_decode);
    for (ii = 0; ii < thread_count; ii++) begin 
        i = (ii + current_thread_i + 1) % integer'(thread_count);
        if (!next_thread_valid
            && thread_active[i]
            && !thread_stalled_on_data_memory[i]
            && thread_state_fetch[i].returned) begin
                next_thread = thread_count_l2'(i);
                next_thread_valid = true;
        end
    end
    thread_to_decode_valid = next_thread_valid && !reset;
    thread_to_decode = next_thread;

    thread_to_issue_fetch = 0;
    thread_to_issue_fetch_valid = false;
    current_thread_i = 0;
    i  =0;
    ii = 0;
    next_thread_valid = false;
    next_thread = 0;
    current_thread_i = integer'(last_thread_to_issue_fetch);
    for (ii = 0; ii < thread_count; ii++) begin 
        i = (ii + current_thread_i + 1) % integer'(thread_count);
        if (!next_thread_valid
            && thread_active[i]
            && thread_state_fetch[i].pause_for == 0
            // Either we haven't issued on this thread
            && (!thread_state_fetch[i].issued
            // OR we received on this thread *and* we will pass it to decode
            || (inst_mem_rsp.valid
                && integer'(inst_mem_rsp_thread) == i
                && inst_mem_rsp.addr == thread_state_fetch[i].issued_pc
                && fetch_signal_in.advance
                && !thread_to_decode_valid))) begin
                next_thread = thread_count_l2'(i);
                next_thread_valid = true;
        end
    end
    thread_to_issue_fetch = next_thread;
    thread_to_issue_fetch_valid = next_thread_valid & !reset;   

    if (!reset && inst_mem_rsp.ready && thread_to_issue_fetch_valid) begin
        inst_mem_req.addr = thread_state_fetch[thread_to_issue_fetch].fetch_pc;
        inst_mem_req.valid = true;
        inst_mem_req.do_read[3:0] = 4'b1111;
        inst_mem_req.user_tag = (`user_tag_size)'(thread_to_issue_fetch);
        //$display("%d: issueing request for: %d:%x", counter, thread_to_issue_fetch, thread_state_fetch[thread_to_issue_fetch].fetch_pc);
    end

end

always_ff @(posedge clk) begin
    if (reset) begin
        for (integer i = 0; i < thread_count; i++) begin
            thread_state_fetch[i] <= {($bits(thread_state_fetch_t)){1'b0}};
            thread_state_fetch[i].fetch_pc <= reset_pc;
        end
        last_thread_to_issue_fetch <= 0;
        last_thread_to_decode <= 0;
    end
    else begin
        automatic thread_id_t inst_mem_rsp_thread = inst_mem_rsp.user_tag[thread_count_l2 - 1:0];
        automatic thread_id_t to_decode_next_thread = cast_to_specific(to_decode.thread_id);
        automatic word to_decode_next_pc = to_decode.pc;
        automatic bool to_decode_next_valid = to_decode.valid;

        for (integer i = 0; i < thread_count; i++) begin
            if (thread_state_fetch[i].pause_for != 0)
                thread_state_fetch[i].pause_for <= thread_state_fetch[i].pause_for - 1;
        end

        counter <= counter + 1;
        // Choose next thread to fetch
        if (thread_to_issue_fetch_valid) begin
            last_thread_to_issue_fetch <= thread_to_issue_fetch;
            thread_state_fetch[thread_to_issue_fetch].issued_pc <= thread_state_fetch[thread_to_issue_fetch].fetch_pc;
            thread_state_fetch[thread_to_issue_fetch].issued <= true;
            thread_state_fetch[thread_to_issue_fetch].returned <= false;
            thread_state_fetch[thread_to_issue_fetch].fetch_pc <= thread_state_fetch[thread_to_issue_fetch].fetch_pc + 4;
            //$display("%d Valid thread to fetch: %x", counter, thread_state_fetch[thread_to_issue_fetch].fetch_pc);
        end else begin
            //$display("%d No valid fetchable thread. 0: issued=%d", counter, thread_state_fetch[0].issued);
        end

        if (fetch_signal_in.advance
            || fetch_signal_in.flush) begin
            to_decode <= {($bits(fgmt_fetched_instruction_t)){1'b0}};
        end

        if (thread_to_decode_valid && fetch_signal_in.advance) begin
            last_thread_to_decode <= thread_to_decode;
            to_decode.valid <= true;
            to_decode.pc <= thread_state_fetch[thread_to_decode].addr;
            to_decode.instruction <= thread_state_fetch[thread_to_decode].instruction;
            to_decode.thread_id <= cast_to_generic(thread_to_decode);
            thread_state_fetch[thread_to_decode].returned <= false;
            thread_state_fetch[thread_to_decode].issued <= false;
            
            to_decode_next_thread = thread_to_decode;
            to_decode_next_pc = thread_state_fetch[thread_to_decode].addr;
            to_decode_next_valid = true;
            //$display("%d Valid thread to decode: returned: %x", counter, thread_state_fetch[thread_to_decode].addr);
        end else begin
            //$display("%d No valid thread to decode: returned: %d", counter, thread_state_fetch[0].returned);
        end

        if (inst_mem_rsp.valid) begin
            automatic instr32 instruction = shuffle_store_data(inst_mem_rsp.data, inst_mem_rsp.addr)[31:0];
            if (!thread_state_fetch[inst_mem_rsp_thread].issued
                || thread_state_fetch[inst_mem_rsp_thread].issued_pc != inst_mem_rsp.addr) begin
                
                //thread_state_fetch[inst_mem_rsp_thread].issued <= false;
                //$display("Fetch return discarded. Expecting %x received: %x",
                //    thread_state_fetch[inst_mem_rsp_thread].issued_pc,
                //    inst_mem_rsp.addr);

            end
            else begin
                //$display("Fetch returned. pc=%x", inst_mem_rsp.addr);
                if (!thread_to_decode_valid
                    && fetch_signal_in.advance) begin
                    // bypass the the table if no other thread is decoded.
                    //$display("Bypassing the table sending to decode %d-%x",
                    //    inst_mem_rsp_thread, inst_mem_rsp.addr);
                    last_thread_to_decode <= inst_mem_rsp_thread;
                    to_decode.pc <= inst_mem_rsp.addr;
                    to_decode.valid <= true;                    
                    to_decode.thread_id <= cast_to_generic(inst_mem_rsp_thread);
                    to_decode.instruction <= instruction;
                    
                    to_decode_next_thread = inst_mem_rsp_thread;
                    to_decode_next_pc = inst_mem_rsp.addr;
                    to_decode_next_valid = true;
                    
                    if (thread_to_issue_fetch_valid &&
                        thread_to_issue_fetch != inst_mem_rsp_thread)
                        thread_state_fetch[inst_mem_rsp_thread].issued <= false;
                    thread_state_fetch[inst_mem_rsp_thread].returned <= false;                    
                end else if (thread_to_decode_valid
                    && fetch_signal_in.advance
                    && thread_to_decode == inst_mem_rsp_thread) begin
                        // send to decode and response thread is the same
                    thread_state_fetch[inst_mem_rsp_thread].returned <= true;
                    thread_state_fetch[inst_mem_rsp_thread].issued <= 
                        thread_to_issue_fetch_valid && 
                        thread_to_issue_fetch == inst_mem_rsp_thread;
                    thread_state_fetch[inst_mem_rsp_thread].instruction <= instruction;
                    thread_state_fetch[inst_mem_rsp_thread].addr <= inst_mem_rsp.addr;
                end else if (!thread_state_fetch[inst_mem_rsp_thread].returned) begin
                    thread_state_fetch[inst_mem_rsp_thread].returned <= true;
                    thread_state_fetch[inst_mem_rsp_thread].issued <= 
                        thread_to_issue_fetch_valid &&
                        thread_to_issue_fetch == inst_mem_rsp_thread;
                    thread_state_fetch[inst_mem_rsp_thread].instruction <= instruction;
                    thread_state_fetch[inst_mem_rsp_thread].addr <= inst_mem_rsp.addr;
                end else begin
                    // Dropping response.  Resetting fetch_pc because we probably want it
                    thread_state_fetch[inst_mem_rsp_thread].fetch_pc <= inst_mem_rsp.addr;
                end
            end
        end
    
        // Respond to branch mispredicts, which should cause a refetch

        if (fgmt_fetch_update_pc_call_in.valid) begin
            automatic thread_id_t thread_id = cast_to_specific(fgmt_fetch_update_pc_call_in.thread_id);
            //$display("[%d] PC_CALL_UPDATE: pc=%x",
            //    thread_id, fgmt_fetch_update_pc_call_in.pc);
            // Easier to work with the complement
            if (to_decode.valid
                && to_decode.pc == fgmt_fetch_update_pc_call_in.pc
                && to_decode.thread_id == fgmt_fetch_update_pc_call_in.thread_id
                ) begin
                    
            end else
            if (to_decode_next_valid
                && to_decode_next_pc == fgmt_fetch_update_pc_call_in.pc
                && to_decode_next_thread == thread_id
                ) begin
                    
            end else
            if (thread_state_fetch[thread_id].issued
                && thread_state_fetch[thread_id].issued_pc == fgmt_fetch_update_pc_call_in.pc
                ) begin
                    
            end
            if (!thread_state_fetch[thread_id].issued
                && thread_state_fetch[thread_id].fetch_pc == fgmt_fetch_update_pc_call_in.pc
                ) begin
            
            end else
            begin
                // Here we deduce that we need to reset fetch for this thread
                //$display("[%d] Resettting fetch", thread_id);

                thread_state_fetch[thread_id].fetch_pc <= fgmt_fetch_update_pc_call_in.pc;
                thread_state_fetch[thread_id].returned <= false;
                thread_state_fetch[thread_id].issued <= false;
                if (to_decode_next_valid && to_decode_next_thread == thread_id)
                    to_decode.valid <= false;
            end
            /*
            //if (fgmt_fetch_update_pc_call_in.thread_id == 1)
                //$display("[1] CALLIN: correct_pc=%x flush=%b",
                //    fgmt_fetch_update_pc_call_in.pc, fetch_signal_in.flush);
            // Note: this will be simplified significantly in synthesis.  But it's
            // nice to lay it out here in long form so it is easier to follow. 
            if (fetch_signal_in.flush) begin
                // detected mispredict.  This happens when decode/exec are on the
                // same thread and exec next_pc != decode pc.  Decode will flush itself.
                thread_state_fetch[thread_id].fetch_pc <= fgmt_fetch_update_pc_call_in.pc;
                thread_state_fetch[thread_id].returned <= false;
                thread_state_fetch[thread_id].issued <= false;
                if (to_decode_next_valid && to_decode_next_thread == thread_id)
                    to_decode.valid <= false;
            end
            // else if (to_decode_next_valid
            //             && to_decode_next_thread == thread_id
            //             && to_decode_next_pc != fgmt_fetch_update_pc_call_in.pc) begin 
            //    $display("Issue 1: %x != %x  current: %x",
            //        to_decode_next_pc, fgmt_fetch_update_pc_call_in.pc, to_decode.pc);
            //    to_decode.valid <= false;
            //    // no (externally) detected mispredict, because decode/exec are on
            //    // different threads.  But could still be a mis-predict.
            //    thread_state_fetch[thread_id].fetch_pc <= fgmt_fetch_update_pc_call_in.pc;
            //    thread_state_fetch[thread_id].returned <= false;
            //    thread_state_fetch[thread_id].issued <= false;        
            //end
            else if (// Valid next
                to_decode_next_valid &&
                // Not the same PC or not the same thread
                (to_decode_next_pc != to_decode.pc ||
                to_decode_next_thread != cast_to_specific(to_decode.thread_id)) &&
                // thread matches reset
                to_decode_next_thread == cast_to_specific(fgmt_fetch_update_pc_call_in.thread_id) &&
                // PC's don't match
                to_decode_next_pc != fgmt_fetch_update_pc_call_in.pc) begin
                to_decode.valid <= false;
                thread_state_fetch[thread_id].fetch_pc <= fgmt_fetch_update_pc_call_in.pc;
                thread_state_fetch[thread_id].returned <= false;
                thread_state_fetch[thread_id].issued <= false;        
                end
            else if (thread_state_fetch[thread_id].returned &&
                    thread_state_fetch[thread_id].addr != fgmt_fetch_update_pc_call_in.pc) begin
                // Instruction retrieved and it is wrong.
                thread_state_fetch[thread_id].fetch_pc <= fgmt_fetch_update_pc_call_in.pc;
                thread_state_fetch[thread_id].returned <= false;
                thread_state_fetch[thread_id].issued <= false;        
            end else if (thread_state_fetch[thread_id].issued &&
                         thread_state_fetch[thread_id].issued_pc != fgmt_fetch_update_pc_call_in.pc) begin
                // Request for the wrong instruction is in progress.
                thread_state_fetch[thread_id].fetch_pc <= fgmt_fetch_update_pc_call_in.pc;
                thread_state_fetch[thread_id].returned <= false;
                thread_state_fetch[thread_id].issued <= false;        
            end else begin
                // Neither issued nor returned
                thread_state_fetch[thread_id].fetch_pc <= fgmt_fetch_update_pc_call_in.pc;
                thread_state_fetch[thread_id].returned <= false;
                thread_state_fetch[thread_id].issued <= false;        
            end
            */
        end
    end
end

endmodule



typedef struct packed {
    bool valid;
    riscv::tag rs1;
    riscv::tag rs2;
    riscv::word rd1;
    riscv::word rd2;
    riscv::word imm;
    riscv::tag wbs;
    bool wbv;
    riscv::funct3 f3;
    riscv::funct7 f7;
    riscv::opcode_q op_q;
    riscv::instr_format format;
    riscv::instr32 instruction;
    riscv::word pc;
    generic_thread_id_t thread_id;
} fgmt_decoded_instruction_t;

typedef struct packed {
    bool valid;
    bool wbv;
    riscv::tag wbs;
    riscv::word wbd;
    generic_thread_id_t thread_id;
} fgmt_writeback_instruction_t;

typedef struct packed {
    bool    valid;
    riscv::word    rd;
    riscv::tag     rs;
    generic_thread_id_t thread_id;
} fgmt_reg_file_bypass_t;

module fgmt_decode_and_writeback #(
    parameter thread_count = 16) (
    input logic       clk
    ,input logic      reset

    // Stage control signalling
    ,input fgmt_stage_signal_t   decode_signal_in

    // Control function interfaces
    ,output fgmt_reg_file_bypass_t reg_file_bypass_out

    // Principle operation data path
    ,input fgmt_fetched_instruction_t fetched_instruction_in
    ,output fgmt_decoded_instruction_t decoded_instruction_out

    ,input fgmt_writeback_instruction_t writeback_instruction_in
    );
    
import riscv::*;

localparam thread_count_l2 = $clog2(thread_count);
typedef logic [thread_count_l2 - 1:0] thread_id_t;

function automatic generic_thread_id_t cast_to_generic(input thread_id_t id);
    return $bits(generic_thread_id_t)'(id);
endfunction

function automatic thread_id_t cast_to_specific(input generic_thread_id_t id);
    return id[thread_count_l2 - 1:0];
endfunction

`syn_ram_no_collision word    reg_file[0:thread_count-1][0:31];

word    reg_file_bypass_rd;
tag     reg_file_bypass_rs;
bool    reg_file_bypass_valid;
thread_id_t reg_file_bypass_thread;

always_comb begin
    reg_file_bypass_out.valid = reg_file_bypass_valid;
    reg_file_bypass_out.rd = reg_file_bypass_rd;
    reg_file_bypass_out.rs = reg_file_bypass_rs;
    reg_file_bypass_out.thread_id = cast_to_generic(reg_file_bypass_thread);
end

tag last_decode_instruction_rs1;
tag last_decode_instruction_rs2;
thread_id_t last_decode_instruction_thread;

initial begin
    for (int t = 0; t < thread_count; t++)
    for (int i = 0; i < 32; i++)
        reg_file[t][i] = `word_size'd0;
end

always_ff @(posedge clk) begin
    word    wbd;
    automatic tag     rs1 = decode_rs1(fetched_instruction_in.instruction);
    automatic tag     rs2 = decode_rs2(fetched_instruction_in.instruction);
    automatic opcode_q op_q = decode_opcode_q(fetched_instruction_in.instruction);
    automatic instr_format format = decode_format(op_q);
    automatic tag read_reg_rs1 = decoded_instruction_out.rs1;
    automatic tag read_reg_rs2 = decoded_instruction_out.rs2;
    automatic thread_id_t read_reg_thread_id = cast_to_specific(decoded_instruction_out.thread_id);

    if (reset)
        reg_file_bypass_valid <= false;
    else if (decode_signal_in.advance
            || decode_signal_in.flush) begin
        decoded_instruction_out.valid <= fetched_instruction_in.valid
                                        & !decode_signal_in.flush;
        decoded_instruction_out.rs1 <= rs1;
        decoded_instruction_out.rs2 <= rs2;
        decoded_instruction_out.wbs <= decode_rd(fetched_instruction_in.instruction);
        decoded_instruction_out.f3 <= decode_funct3(fetched_instruction_in.instruction);
        decoded_instruction_out.op_q <= op_q;
        decoded_instruction_out.format <= format;
        decoded_instruction_out.imm <= decode_imm(fetched_instruction_in.instruction, format);
        decoded_instruction_out.wbv <= decode_writeback(op_q);
        decoded_instruction_out.f7 <= decode_funct7(fetched_instruction_in.instruction, format);
        decoded_instruction_out.pc <= fetched_instruction_in.pc;
        decoded_instruction_out.thread_id <= fetched_instruction_in.thread_id;

        read_reg_rs1 = rs1;
        read_reg_rs2 = rs2;
        read_reg_thread_id = cast_to_specific(fetched_instruction_in.thread_id);
    end
    decoded_instruction_out.rd1 <= reg_file[read_reg_thread_id][read_reg_rs1];
    decoded_instruction_out.rd2 <= reg_file[read_reg_thread_id][read_reg_rs2];            

    // Write back
    if (!reset
        && writeback_instruction_in.valid
        && writeback_instruction_in.wbv) begin
        //// There's a bug in V erilator we're avoiding here
        //if (writeback_instruction_in.thread_id != 0)
        //    $display("[%d] reg(%d) = %x", writeback_instruction_in.thread_id[$bits(thread_id_t)-1:0],
        //        writeback_instruction_in.wbs, writeback_instruction_in.wbd);
        reg_file[writeback_instruction_in.thread_id[thread_count_l2-1:0]][writeback_instruction_in.wbs] <= writeback_instruction_in.wbd;
        reg_file_bypass_rs <= writeback_instruction_in.wbs;
        reg_file_bypass_rd <= writeback_instruction_in.wbd;
        reg_file_bypass_valid <= true;
        reg_file_bypass_thread <= cast_to_specific(writeback_instruction_in.thread_id);
    end

end
endmodule

typedef struct packed {
    bool valid;
    riscv::word pc;
    riscv::word next_pc;
    riscv::word rd1;
    riscv::word rd2;
    riscv::tag rs1;
    riscv::tag rs2;
    riscv::funct3 f3;
    riscv::opcode_q op_q;
    generic_thread_id_t thread_id;
    fgmt_writeback_instruction_t writeback_instruction;
} fgmt_executed_instruction_t;

typedef struct packed {
    bool valid;
    bool fetch_mispredict;
    bool wrong_pc;
    riscv::word current_pc;
    riscv::word correct_pc;
    generic_thread_id_t thread_id;
}   fgmt_pc_control_t;

typedef struct packed {
    bool valid;
    riscv::word pc;
    riscv::word next_pc;
    riscv::word exec_result;
    riscv::funct3 f3;
    riscv::opcode_q op_q;
    generic_thread_id_t thread_id;
    fgmt_writeback_instruction_t writeback_instruction;
} fgmt_memory_instruction_t;

module fgmt_execute #(parameter thread_count = 16) (
    input logic       clk
    ,input logic      reset
    ,input riscv::word       reset_pc
    // Stage control signalling
    ,input fgmt_stage_signal_t   execute_signal_in
    ,input fgmt_stage_signal_t   memory_signal_in

    // For detecting a branch mispredict
    ,input fgmt_fetched_instruction_t fetched_instruction_in

    // For bypassing
    ,input fgmt_reg_file_bypass_t reg_file_bypass_in
    ,input fgmt_executed_instruction_t executed_instruction_in
    ,input fgmt_memory_instruction_t memory_instruction_in[0:thread_count-1]
    ,input fgmt_writeback_instruction_t writeback_instruction_in

    // Datapath proper
    ,input fgmt_decoded_instruction_t  decoded_instruction_in
    ,output fgmt_executed_instruction_t executed_instruction_out

    ,output fgmt_pc_control_t pc_control_out
    );

import riscv::*;

localparam thread_count_l2 = $clog2(thread_count);
typedef logic [thread_count_l2 - 1:0] thread_id_t;

function automatic generic_thread_id_t cast_to_generic(input thread_id_t id);
    return $bits(generic_thread_id_t)'(id);
endfunction

function automatic thread_id_t cast_to_specific(input generic_thread_id_t id);
    return id[$bits(thread_id_t)-1:0];
endfunction

word pc[0:thread_count-1];

ext_operand exec_result_comb;
word next_pc_comb;
word exec_bypassed_rd1_comb;
word exec_bypassed_rd2_comb;

bool wrong_pc;

always_comb begin
    word rd1;
    word rd2;

    // By pass in the following priority: zero, from start of mem, from start of WB, from completed WB, and finally reg file
    rd1 =   
            // Zero takes priority over all
            ((decoded_instruction_in.rs1 == 5'd0) ? `word_size'd0 :

            // Bypass from start of memory stage when not a load
            ((decoded_instruction_in.rs1 == executed_instruction_in.writeback_instruction.wbs
                && decoded_instruction_in.thread_id == executed_instruction_in.thread_id
                && executed_instruction_in.valid 
                && executed_instruction_in.writeback_instruction.wbv
                && executed_instruction_in.op_q != q_load
                && executed_instruction_in.op_q != q_amo) ? executed_instruction_in.writeback_instruction.wbd :

            // Bypass from inside the defer table but only if it's not a load/store
            ((decoded_instruction_in.rs1 == memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.wbs
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.wbv
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.valid
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].op_q != q_load
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].op_q != q_amo
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].valid) ? memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.wbd :

            // Bypass from start of writeback
            ((decoded_instruction_in.rs1 == writeback_instruction_in.wbs
                && decoded_instruction_in.thread_id == writeback_instruction_in.thread_id
                && writeback_instruction_in.valid
                && writeback_instruction_in.wbv) ? writeback_instruction_in.wbd :

            // Bypass on write-through on the register file
            ((decoded_instruction_in.rs1 == reg_file_bypass_in.rs
                && decoded_instruction_in.thread_id == reg_file_bypass_in.thread_id
                && reg_file_bypass_in.valid
                ) ? reg_file_bypass_in.rd 

            // Believe the register file
                : decoded_instruction_in.rd1)))));


    rd2 =   
            // Zero takes priority over all
            ((decoded_instruction_in.rs2 == 5'd0) ? `word_size'd0 :
            // Bypass from start of memory stage when not a load
            ((decoded_instruction_in.rs2 == executed_instruction_in.writeback_instruction.wbs
                && decoded_instruction_in.thread_id == executed_instruction_in.thread_id
                && executed_instruction_in.valid 
                && executed_instruction_in.writeback_instruction.wbv
                && executed_instruction_in.op_q != q_load
                && executed_instruction_in.op_q != q_amo) ? executed_instruction_in.writeback_instruction.wbd :

            // Bypass from inside the defer table
            ((decoded_instruction_in.rs2 == memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.wbs
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.wbv
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.valid
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].op_q != q_load
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].op_q != q_amo
                && memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].valid) ? memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.wbd :


            // Bypass from start of writeback
            ((decoded_instruction_in.rs2 == writeback_instruction_in.wbs
                && decoded_instruction_in.thread_id == writeback_instruction_in.thread_id
                && writeback_instruction_in.valid
                && writeback_instruction_in.wbv) ? writeback_instruction_in.wbd :

            // Bypass on write-through on the register file
            ((decoded_instruction_in.rs2 == reg_file_bypass_in.rs
                && decoded_instruction_in.thread_id == reg_file_bypass_in.thread_id
                && reg_file_bypass_in.valid) ? reg_file_bypass_in.rd 

            // Believe the register file
                : decoded_instruction_in.rd2)))));

    exec_bypassed_rd1_comb = rd1;
    exec_bypassed_rd2_comb = rd2;

    exec_result_comb = execute(
        cast_to_ext_operand(rd1),
        cast_to_ext_operand(rd2),
        cast_to_ext_operand(decoded_instruction_in.imm),
        decoded_instruction_in.pc,
        decoded_instruction_in.op_q,
        decoded_instruction_in.f3,
        decoded_instruction_in.f7);

    // "ground truth" for the next PC comes from this calculation.
    next_pc_comb = compute_next_pc(
        cast_to_ext_operand(rd1),
        exec_result_comb,
        decoded_instruction_in.imm,
        decoded_instruction_in.pc,
        decoded_instruction_in.op_q,
        decoded_instruction_in.f3);

    pc_control_out = {($bits(fgmt_pc_control_t)){1'b0}};
    pc_control_out.fetch_mispredict = false;
    pc_control_out.thread_id = decoded_instruction_in.thread_id;
    pc_control_out.current_pc = pc[cast_to_specific(decoded_instruction_in.thread_id)];
    pc_control_out.correct_pc = next_pc_comb;
    pc_control_out.valid = decoded_instruction_in.valid;

    if (decoded_instruction_in.valid
        && fetched_instruction_in.valid
        //&& execute_signal_in.advance
        && decoded_instruction_in.thread_id == fetched_instruction_in.thread_id
        && next_pc_comb != fetched_instruction_in.pc) begin
        pc_control_out.fetch_mispredict = true;
    end

    // This is entirely possible, the fetch unit can give us an incorrect
    // instruction and it's not until here that we figure this out sometimes.
    // We compute this if decode_instruction_in is valid, regardless of whether
    // we advance.
    if (decoded_instruction_in.valid
        //&& execute_signal_in.advance
        && pc[cast_to_specific(decoded_instruction_in.thread_id)] != decoded_instruction_in.pc) begin
        
        wrong_pc = true;
        pc_control_out.correct_pc = pc[cast_to_specific(decoded_instruction_in.thread_id)];
        pc_control_out.valid = true;

        if (true //decoded_instruction_in.valid
            && fetched_instruction_in.valid
            //&& execute_signal_in.advance
            && decoded_instruction_in.thread_id == fetched_instruction_in.thread_id
            && pc[cast_to_specific(decoded_instruction_in.thread_id)] != fetched_instruction_in.pc)
            pc_control_out.fetch_mispredict = true;
        else
            pc_control_out.fetch_mispredict = false;

    end else
        wrong_pc = false;

    pc_control_out.wrong_pc = wrong_pc;
end

always_ff @(posedge clk) begin
    if (reset
        || memory_signal_in.advance
        || execute_signal_in.flush) begin
        // Subtle: we sometimes have advanced an instruction that
        // we will want to flush out of the memory stage input.  When
        // this happens we actually need to "rollback" the instruction
        // by adjusting the true PC in execute.
        if (execute_signal_in.flush
            && !memory_signal_in.advance
            && executed_instruction_out.valid) begin
            pc[executed_instruction_out.thread_id[$bits(thread_id_t)-1:0]] <= executed_instruction_out.pc;
        end
        executed_instruction_out.valid <= false;
    end

    if (execute_signal_in.advance
        || execute_signal_in.flush) begin
        // We only update the PC if we actually exdecuted the correct instruction
        if (decoded_instruction_in.valid
            && !wrong_pc
            && !execute_signal_in.flush) begin
            pc[decoded_instruction_in.thread_id[$bits(thread_id_t)-1:0]] <= next_pc_comb;
        end
        //if (decoded_instruction_in.valid
        //    && wrong_pc) begin
        //    $display("Wrong PC.  Wanting: %x got: %x",
        //        pc[decoded_instruction_in.thread_id[$bits(thread_id_t)-1:0]],
        //        decoded_instruction_in.pc);
        //end
        executed_instruction_out.rd1 <= exec_bypassed_rd1_comb;
        executed_instruction_out.rd2 <= exec_bypassed_rd2_comb;
        executed_instruction_out.rs1 <= decoded_instruction_in.rs1;
        executed_instruction_out.rs2 <= decoded_instruction_in.rs2;
        executed_instruction_out.writeback_instruction.wbs <= decoded_instruction_in.wbs;
        executed_instruction_out.writeback_instruction.wbv <= decoded_instruction_in.wbv;
        executed_instruction_out.writeback_instruction.wbd <= exec_result_comb[`word_size-1:0];
        executed_instruction_out.writeback_instruction.valid <= decoded_instruction_in.valid & !wrong_pc;
        executed_instruction_out.writeback_instruction.thread_id <= decoded_instruction_in.thread_id;
        executed_instruction_out.valid <=
                                        decoded_instruction_in.valid
                                        && !wrong_pc
                                        && !execute_signal_in.flush; 
        executed_instruction_out.next_pc <= next_pc_comb;
        executed_instruction_out.pc <= decoded_instruction_in.pc;
        executed_instruction_out.f3 <= decoded_instruction_in.f3;
        executed_instruction_out.op_q <= decoded_instruction_in.op_q;
        executed_instruction_out.thread_id <= decoded_instruction_in.thread_id;
    end
end

endmodule

module fgmt_memory_writeback_nonblocking #(
    parameter thread_count = 16) (
    input logic       clk
    ,input logic      reset

    // Stage control signalling
    ,input fgmt_stage_signal_t   memory_signal_in

    // For bypassing
    ,input fgmt_reg_file_bypass_t reg_file_bypass_in

    // For connecting stall info to fetch
    ,output thread_stalled_on_data_memory_out[0:thread_count-1]
    ,output cross_thread_pc_control_t cross_thread_pc_control_out

    // For connecting bypass back to execute
    ,output fgmt_memory_instruction_t memory_instruction_out[0:thread_count-1]

    // Datapath proper
    ,output memory_io_req   data_mem_req
    ,input  memory_io_rsp   data_mem_rsp
    ,input fgmt_executed_instruction_t  executed_instruction_in
    ,output fgmt_writeback_instruction_t writeback_instruction_out
    );

import riscv::*;

localparam thread_count_l2 = $clog2(thread_count);
typedef logic [thread_count_l2 - 1:0] thread_id_t;

function automatic generic_thread_id_t cast_to_generic(input thread_id_t id);
    return $bits(generic_thread_id_t)'(id);
endfunction

function automatic thread_id_t cast_to_specific(input generic_thread_id_t id);
    return id[$bits(thread_id_t)-1:0];
endfunction

fgmt_memory_instruction_t memory_instruction[0:thread_count-1];
assign memory_instruction_out = memory_instruction;


/* verilator lint_off UNOPTFLAT */
word bypassed_rd1;
word bypassed_rd2;
/* verilator lint_on UNOPTFLAT */

//assign bypassed_rd1 = executed_instruction_in.rd1;
//assign bypassed_rd2 = executed_instruction_in.rd2;

assign bypassed_rd1 = ((executed_instruction_in.rs1 == 5'd0) ? `word_size'd0 :
            // Bypass from start of writeback
            ((executed_instruction_in.rs1 == writeback_instruction_out.wbs
                && executed_instruction_in.thread_id == writeback_instruction_out.thread_id
                && writeback_instruction_out.valid
                && writeback_instruction_out.wbv) ? writeback_instruction_out.wbd :

            // Bypass on write-through on the register file
            ((executed_instruction_in.rs1 == reg_file_bypass_in.rs
                && executed_instruction_in.thread_id == reg_file_bypass_in.thread_id
                && reg_file_bypass_in.valid) ? reg_file_bypass_in.rd :

            executed_instruction_in.rd1)));

assign bypassed_rd2 =  ((executed_instruction_in.rs2 == 5'd0) ? `word_size'd0 :
            // Bypass from start of writeback
            ((executed_instruction_in.rs2 == writeback_instruction_out.wbs
                && executed_instruction_in.thread_id == writeback_instruction_out.thread_id
                && writeback_instruction_out.valid
                && writeback_instruction_out.wbv) ? writeback_instruction_out.wbd :

            // Bypass on write-through on the register file
            ((executed_instruction_in.rs2 == reg_file_bypass_in.rs
                && executed_instruction_in.thread_id == reg_file_bypass_in.thread_id
                && reg_file_bypass_in.valid) ? reg_file_bypass_in.rd :

            executed_instruction_in.rd2)));


always_ff @(posedge clk) begin
    // Not convinced the bypass is necessary nor working fully here.
    // So these checks are just to see see if it's ever used.
    if(memory_instruction[cast_to_specific(executed_instruction_in.thread_id)].valid &&
        ((memory_instruction[cast_to_specific(executed_instruction_in.thread_id)].writeback_instruction.wbs ==
            executed_instruction_in.rs2 &&
            bypassed_rd2 != executed_instruction_in.rd2) ||
         (memory_instruction[cast_to_specific(executed_instruction_in.thread_id)].writeback_instruction.wbs ==
            executed_instruction_in.rs1 &&
            bypassed_rd1 != executed_instruction_in.rd1)) &&
        executed_instruction_in.valid &&
        memory_signal_in.advance)
        $display("Possibly a bad bypass in memory");

    if (executed_instruction_in.valid && memory_signal_in.advance &&
        (bypassed_rd2 != executed_instruction_in.rd2 ||
         bypassed_rd1 != executed_instruction_in.rd1))
        $display("Interesting.... bypassed in memory");
end


// These are set up here, instead of the always_comb below to
// handle a fake UNOPTFLAT that V erilator complains about.
bool fgmt_internal_control_valid;
word fgmt_internal_control_addr;
word fgmt_internal_control_data;
thread_id_t fgmt_internal_control_thread_id;

bool fgmt_internal_control_do_write;
assign fgmt_internal_control_addr = executed_instruction_in.writeback_instruction.wbd[`word_address_size - 1:0];
assign fgmt_internal_control_valid =
        (executed_instruction_in.valid
         && (executed_instruction_in.op_q == q_store
         || executed_instruction_in.op_q == q_load));
assign fgmt_internal_control_do_write = (executed_instruction_in.op_q == q_store);
assign fgmt_internal_control_thread_id = cast_to_specific(executed_instruction_in.thread_id);
assign fgmt_internal_control_data = bypassed_rd2;

bool is_internal_mmio;
cross_thread_write_register_t cross_thread_write_register;
cross_thread_pc_control_t cross_thread_pc_control;
same_thread_io_result_t same_thread_io_result;

assign cross_thread_pc_control_out = cross_thread_pc_control;

fgmt_internal_control #(.thread_count(thread_count)) fgmt_internal_control_m(
    .valid_in(fgmt_internal_control_valid)
    ,.addr_in(fgmt_internal_control_addr)
    ,.data_in(fgmt_internal_control_data)
    ,.thread_id_in(fgmt_internal_control_thread_id)
    ,.do_write_in(fgmt_internal_control_do_write)
    ,.is_internal_mmio_out(is_internal_mmio)
    ,.cross_thread_write_register_out(cross_thread_write_register)
    ,.cross_thread_pc_control_out(cross_thread_pc_control)
    ,.same_thread_io_result_out(same_thread_io_result)
    );

bool thread_stalled_on_data_memory[0:thread_count-1];
assign thread_stalled_on_data_memory_out = thread_stalled_on_data_memory;

bool writeback_instruction_out_valid;
thread_id_t writeback_instruction_out_thread_id;
thread_id_t last_writeback_instruction_out_thread_id;

always_comb begin
    automatic thread_id_t data_mem_rsp_thread_id = data_mem_rsp.user_tag[thread_count_l2 - 1:0];
    automatic integer current_thread_i, i, ii;
    automatic bool next_thread_valid;
    automatic thread_id_t next_thread;
    next_thread_valid = false;
    next_thread = 0;
    current_thread_i = integer'(last_writeback_instruction_out_thread_id);
    i = 0;
    ii = 0;

    writeback_instruction_out = {($bits(fgmt_writeback_instruction_t)){1'b0}};

    writeback_instruction_out_valid = false;
    writeback_instruction_out_thread_id = 0;
    ////// Respond to memory interface and choose instruction to send to writeback
    if (data_mem_rsp.valid &&
        (memory_instruction[data_mem_rsp_thread_id].op_q == q_load
         || memory_instruction[data_mem_rsp_thread_id].op_q == q_amo
         // Stores are silenetly consumed.
         /*|| memory_instruction[data_mem_rsp_thread_id].op_q == q_store*/)) begin
        // No matter what we need to take the memory response and send it to writeback
        if (!memory_instruction[data_mem_rsp_thread_id].valid)
            $display("Memory response but no entry?");
        writeback_instruction_out = memory_instruction[data_mem_rsp_thread_id].writeback_instruction;
        writeback_instruction_out.wbd = subset_load_data(
                        shuffle_load_data(data_mem_rsp.data, memory_instruction[data_mem_rsp_thread_id].writeback_instruction.wbd[`word_size - 1:0]),
                        cast_to_memory_op(memory_instruction[data_mem_rsp_thread_id].f3));
        writeback_instruction_out.valid = memory_instruction[data_mem_rsp_thread_id].valid;
        writeback_instruction_out_thread_id = data_mem_rsp_thread_id;
    end else begin
        ///// memory response does not need to go to writeback.  Instead search for anything
        ///// that can

        for (ii = 0; ii < thread_count; ii++) begin 
            i = (ii + current_thread_i + 1) % integer'(thread_count);
            if (!next_thread_valid
                && memory_instruction[i].valid &&
                (memory_instruction[i].op_q != q_load
                 && memory_instruction[i].op_q != q_store
                 && memory_instruction[i].op_q != q_amo)) begin
                next_thread = thread_count_l2'(i);
                next_thread_valid = true;
            end
        end
        if (next_thread_valid) begin
            writeback_instruction_out = memory_instruction[next_thread].writeback_instruction;
            writeback_instruction_out_valid = true;
            writeback_instruction_out_thread_id = next_thread;
        end
    end
end


/* verilator lint_off UNOPTFLAT */
bool do_memory;
assign do_memory = !is_internal_mmio
        && memory_signal_in.advance
        && executed_instruction_in.valid
        && data_mem_rsp.ready
        && (executed_instruction_in.op_q == q_store
         || executed_instruction_in.op_q == q_load
         || executed_instruction_in.op_q == q_amo);
/* verilator lint_on UNOPTFLAT */

assign data_mem_req.user_tag = do_memory ? `user_tag_size'(executed_instruction_in.thread_id) : 0;
assign data_mem_req.addr = do_memory ? ((executed_instruction_in.op_q == q_store ||
                            executed_instruction_in.op_q == q_load) ? executed_instruction_in.writeback_instruction.wbd[`word_address_size - 1:0]
                            : executed_instruction_in.rd1) : 0;
assign data_mem_req.data = do_memory ? ((executed_instruction_in.op_q == q_store) ? shuffle_store_data(bypassed_rd2, executed_instruction_in.writeback_instruction.wbd[`word_size - 1:0])
                            : executed_instruction_in.rd2) : 0;
assign data_mem_req.valid = do_memory;
assign data_mem_req.do_write = (do_memory && executed_instruction_in.op_q == q_store) ? shuffle_store_mask(memory_mask(
                cast_to_memory_op(executed_instruction_in.f3)), executed_instruction_in.writeback_instruction.wbd[`word_size - 1:0])
                : (do_memory && executed_instruction_in.op_q == q_amo && executed_instruction_in.f3 == f3_amo_d) ?
                {(`word_size_bytes){1'b1}} : 0;
assign data_mem_req.do_read =(do_memory && executed_instruction_in.op_q == q_load) ? shuffle_store_mask(memory_mask(
                cast_to_memory_op(executed_instruction_in.f3)), executed_instruction_in.writeback_instruction.wbd[`word_size - 1:0])
                : (do_memory && executed_instruction_in.op_q == q_amo && executed_instruction_in.f3 == f3_amo_d) ?
                {(`word_size_bytes){1'b1}} : 0;

/*
// For some reason this code confuses verilator into thinking
// there's a combinatorial loop where there is none.  Either it
// can be in a separate always_comb block or the above continious
// assign statments are sufficient.
//end always_comb begin
    data_mem_req = memory_io_no_req;

    if (!is_internal_mmio
        && memory_signal_in.advance
        && executed_instruction_in.valid
        && data_mem_rsp.ready
        && (executed_instruction_in.op_q == q_store
         || executed_instruction_in.op_q == q_load
         || executed_instruction_in.op_q == q_amo)) begin
        data_mem_req.user_tag = `user_tag_size'(executed_instruction_in.thread_id);
        if (executed_instruction_in.op_q == q_store) begin
            data_mem_req.addr = executed_instruction_in.writeback_instruction.wbd[`word_address_size - 1:0];
            data_mem_req.valid = true;
            data_mem_req.do_write = shuffle_store_mask(memory_mask(
                cast_to_memory_op(executed_instruction_in.f3)), executed_instruction_in.writeback_instruction.wbd[`word_size - 1:0]);
            data_mem_req.data = shuffle_store_data(bypassed_rd2, executed_instruction_in.writeback_instruction.wbd[`word_size - 1:0]);
        end
        else if (executed_instruction_in.op_q == q_load) begin
            data_mem_req.addr = executed_instruction_in.writeback_instruction.wbd[`word_address_size - 1:0];
            data_mem_req.valid = true;
            data_mem_req.do_read = shuffle_store_mask(memory_mask(
                cast_to_memory_op(executed_instruction_in.f3)), executed_instruction_in.writeback_instruction.wbd[`word_size - 1:0]);
        end
        else if (executed_instruction_in.op_q == q_amo) begin
            data_mem_req.addr = executed_instruction_in.rd1;//bypassed_rd1;
            data_mem_req.data = executed_instruction_in.rd2;//bypassed_rd2;
            data_mem_req.valid = true;
            if (executed_instruction_in.f3 == f3_amo_d) begin
                data_mem_req.do_write = {(`word_size_bytes){1'b1}};
                data_mem_req.do_read = {(`word_size_bytes){1'b1}};
            end
        end
    end

end
*/

always_ff @(posedge clk) begin
    if (reset) begin
        for (integer i = 0; i < thread_count; i++) begin
            memory_instruction[i].valid <= false;
            thread_stalled_on_data_memory[i] <= false;
        end
        last_writeback_instruction_out_thread_id <= 0;
    end
    else begin

        // No matter what we process the memory interface
        if (data_mem_rsp.valid) begin
            automatic thread_id_t data_mem_rsp_thread_id = data_mem_rsp.user_tag[thread_count_l2 - 1:0];
            memory_instruction[data_mem_rsp_thread_id].valid <= false;
            thread_stalled_on_data_memory[data_mem_rsp_thread_id] <= false;    
            last_writeback_instruction_out_thread_id <= data_mem_rsp_thread_id;
        end
        // We may have processed a non-load/AMO instruction out
        // Note stores have data_mem_rsp.valid but do not generate a writeback to reg
        if (writeback_instruction_out_valid) begin
            memory_instruction[writeback_instruction_out_thread_id].valid <= false;
            thread_stalled_on_data_memory[writeback_instruction_out_thread_id] <= false;    
            last_writeback_instruction_out_thread_id <= writeback_instruction_out_thread_id;
        end

        if (memory_signal_in.advance && executed_instruction_in.valid) begin
            automatic thread_id_t thread_id = cast_to_specific(executed_instruction_in.thread_id);
            
            // This happens on thread start, and when there's an error.
            if (memory_instruction[thread_id].next_pc != 0
                && memory_instruction[thread_id].next_pc != executed_instruction_in.pc)
                $display("Curious at memory [%d] next_pc %x != pc %x",
                    thread_id, memory_instruction[thread_id].next_pc, executed_instruction_in.pc);

            memory_instruction[thread_id].pc <= executed_instruction_in.pc;
            memory_instruction[thread_id].next_pc <= executed_instruction_in.next_pc;
            if (is_internal_mmio) begin
                //$display("FGMT MMIO: %x", fgmt_internal_control_addr);
                if (cross_thread_write_register.valid) begin
                    memory_instruction[thread_id].writeback_instruction.wbd <= cross_thread_write_register.data;
                    memory_instruction[thread_id].writeback_instruction.wbs <= cross_thread_write_register.rs;
                    memory_instruction[thread_id].writeback_instruction.wbv <= true;
                    memory_instruction[thread_id].writeback_instruction.thread_id <= cross_thread_write_register.thread_id;
                    memory_instruction[thread_id].f3 <= executed_instruction_in.f3;
                    memory_instruction[thread_id].op_q <= q_op;
                    memory_instruction[thread_id].valid <= executed_instruction_in.valid;
                    memory_instruction[thread_id].thread_id <= executed_instruction_in.thread_id;
                    thread_stalled_on_data_memory[thread_id] <= true;
                end
                else
                if (same_thread_io_result.valid) begin
                    memory_instruction[thread_id].writeback_instruction.wbd <= same_thread_io_result.data;
                    memory_instruction[thread_id].writeback_instruction.wbs <= executed_instruction_in.writeback_instruction.wbs;
                    memory_instruction[thread_id].writeback_instruction.wbv <= true;
                    memory_instruction[thread_id].writeback_instruction.thread_id <= cast_to_generic(thread_id);
                    memory_instruction[thread_id].f3 <= executed_instruction_in.f3;
                    memory_instruction[thread_id].op_q <= q_op;
                    memory_instruction[thread_id].valid <= executed_instruction_in.valid;
                    memory_instruction[thread_id].thread_id <= executed_instruction_in.thread_id;
                    thread_stalled_on_data_memory[thread_id] <= true;
                end
                else
                if (cross_thread_pc_control.valid) begin
                    // Cross thread PC control ops turn into no-ops (effectively)
                    memory_instruction[thread_id].writeback_instruction.wbd <= 0;
                    memory_instruction[thread_id].writeback_instruction.wbs <= executed_instruction_in.writeback_instruction.wbs;
                    memory_instruction[thread_id].writeback_instruction.wbv <= false;
                    memory_instruction[thread_id].writeback_instruction.thread_id <= cast_to_generic(thread_id);
                    memory_instruction[thread_id].f3 <= executed_instruction_in.f3;
                    memory_instruction[thread_id].op_q <= q_op;
                    memory_instruction[thread_id].valid <= executed_instruction_in.valid;
                    memory_instruction[thread_id].thread_id <= executed_instruction_in.thread_id;
                end
                else begin
                    // This is really more of an error condition
                    $display("Invalid FGMT MMIO operation: address=%x wbv=%b wbs=%d op_q=%s",
                        executed_instruction_in.writeback_instruction.wbd,
                        executed_instruction_in.writeback_instruction.wbv,
                        executed_instruction_in.writeback_instruction.wbs,
                        executed_instruction_in.op_q == q_load ? "load" :
                        executed_instruction_in.op_q == q_store ? "store" : "unknown"
                        );
                    memory_instruction[thread_id].writeback_instruction.wbd <= same_thread_io_result.data;
                    memory_instruction[thread_id].writeback_instruction.wbs <= executed_instruction_in.writeback_instruction.wbs;
                    memory_instruction[thread_id].writeback_instruction.wbv <= false;
                    memory_instruction[thread_id].writeback_instruction.thread_id <= cast_to_generic(thread_id);
                    memory_instruction[thread_id].f3 <= executed_instruction_in.f3;
                    memory_instruction[thread_id].op_q <= q_op;
                    memory_instruction[thread_id].valid <= executed_instruction_in.valid;
                    memory_instruction[thread_id].thread_id <= executed_instruction_in.thread_id;
                end
            end else begin
                memory_instruction[thread_id].writeback_instruction <= executed_instruction_in.writeback_instruction;
                // for memory ops wbd holds the address, not the data.  AMO uses rd1
                if (executed_instruction_in.op_q == q_amo)
                    memory_instruction[thread_id].writeback_instruction.wbd <= bypassed_rd1;
                memory_instruction[thread_id].f3 <= executed_instruction_in.f3;
                memory_instruction[thread_id].op_q <= executed_instruction_in.op_q;
                memory_instruction[thread_id].valid <= executed_instruction_in.valid;
                memory_instruction[thread_id].thread_id <= executed_instruction_in.thread_id;
                thread_stalled_on_data_memory[thread_id] <= true;
            end
        end
    end
end

endmodule


module fgmt_control # (
    parameter thread_count = 16
    ,parameter flush_pipeline_on_memory_stall = true) (
    input memory_io_rsp inst_mem_rsp
    ,input memory_io_rsp data_mem_rsp
    ,input fgmt_pc_control_t pc_control_in
    ,input fgmt_fetched_instruction_t fetched_instruction_in
    ,input fgmt_decoded_instruction_t decoded_instruction_in
    ,input fgmt_executed_instruction_t executed_instruction_in
    ,input fgmt_memory_instruction_t memory_instruction_in[0:thread_count-1]
    ,input fgmt_writeback_instruction_t writeback_instruction_in
    ,input bool thread_stalled_on_data_memory_in[0:thread_count-1]
    ,output fgmt_stage_signal_t  fetch_signal_out
    ,output fgmt_stage_signal_t  decode_signal_out
    ,output fgmt_stage_signal_t  execute_signal_out
    ,output fgmt_stage_signal_t  memory_signal_out
    ,output fgmt_fetch_update_pc_call_t fetch_update_pc_call_out
    );

import riscv::*;
localparam thread_count_l2 = $clog2(thread_count);
typedef logic [thread_count_l2 - 1:0] thread_id_t;

function automatic generic_thread_id_t cast_to_generic(input thread_id_t id);
    return $bits(generic_thread_id_t)'(id);
endfunction

function automatic thread_id_t cast_to_specific(input generic_thread_id_t id);
    return id[$bits(thread_id_t)-1:0];
endfunction

// Stall / Flush logic 
always_comb begin
    // Start with everything running smooth
    fgmt_stage_signal_init(fetch_signal_out);
    fgmt_stage_signal_init(decode_signal_out);
    fgmt_stage_signal_init(execute_signal_out);
    fgmt_stage_signal_init(memory_signal_out);
    fgmt_fetch_update_pc_init(fetch_update_pc_call_out);
    
    // Trying to issue a load / store but memory system is indicating it cannot accept it.
    if (executed_instruction_in.valid
        && (executed_instruction_in.op_q == q_load
            || executed_instruction_in.op_q == q_store
            || executed_instruction_in.op_q == q_amo)
        && !data_mem_rsp.ready) begin
        fgmt_stage_signal_not_advance(fetch_signal_out);
        fgmt_stage_signal_not_advance(decode_signal_out);
        fgmt_stage_signal_not_advance(execute_signal_out);
        fgmt_stage_signal_not_advance(memory_signal_out);
    end

    // We stall the pipe if the instruction in memory stage cannot advance into the
    // table.  But we permit insert/remove of the table on the same thread    
    if (executed_instruction_in.valid
        && thread_stalled_on_data_memory_in[cast_to_specific(executed_instruction_in.thread_id)]
        && (writeback_instruction_in.valid == false ||
            writeback_instruction_in.thread_id != executed_instruction_in.thread_id)
        ) begin
        fgmt_stage_signal_not_advance(fetch_signal_out);
        fgmt_stage_signal_not_advance(decode_signal_out);
        fgmt_stage_signal_not_advance(execute_signal_out);
        fgmt_stage_signal_not_advance(memory_signal_out);
    end

    // If we flush on a memory stall at all then if the instruction in execute
    // is the same thread id as a pending load then we flush.
    if (flush_pipeline_on_memory_stall
        && decoded_instruction_in.valid
        && thread_stalled_on_data_memory_in[cast_to_specific(decoded_instruction_in.thread_id)]
        && (memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].op_q == q_load
          || memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].op_q == q_amo)) begin
        fgmt_stage_signal_flush_set(execute_signal_out, decoded_instruction_in.thread_id);
        // See note in execute stage.  We sometimes need to roll back
        // an executed instruction.  Note both of these
        // are just suggestions to the fetch stage, but best
        // to get it right.
        if (memory_signal_out.advance)
            fgmt_fetch_update_pc(fetch_update_pc_call_out,
                pc_control_in.thread_id, pc_control_in.current_pc);
        else
            fgmt_fetch_update_pc(fetch_update_pc_call_out,
                executed_instruction_in.thread_id, executed_instruction_in.pc);
    end

    /* 
    We don't need to stall on these because we bypass from the memory
    table.  We still do need to stall on actual load/stores.  See below.

    // We stall the pipe if the instruction to be executed has a table entry
    // for a anything and we are not also processing it out
    if (decoded_instruction_in.valid
        && thread_stalled_on_data_memory_in[cast_to_specific(decoded_instruction_in.thread_id)]
        && (writeback_instruction_in.valid == false ||
            writeback_instruction_in.thread_id != decoded_instruction_in.thread_id)
        ) begin
        fgmt_stage_signal_not_advance(fetch_signal_out);
        fgmt_stage_signal_not_advance(decode_signal_out);
        fgmt_stage_signal_not_advance(execute_signal_out);
    end

    // This is similar to the above case.
    if (fetched_instruction_in.valid
        && thread_stalled_on_data_memory_in[cast_to_specific(fetched_instruction_in.thread_id)]
        //&& (writeback_instruction_in.valid == false ||
        //    writeback_instruction_in.thread_id != fetched_instruction_in.thread_id)
        ) begin
        fgmt_stage_signal_not_advance(fetch_signal_out);
        fgmt_stage_signal_not_advance(decode_signal_out);
        fgmt_stage_signal_not_advance(execute_signal_out);
    end
    */
    // Load use
    if (decoded_instruction_in.valid
        && executed_instruction_in.valid
        && (executed_instruction_in.op_q == q_load ||
            executed_instruction_in.op_q == q_amo)
        && executed_instruction_in.thread_id == decoded_instruction_in.thread_id
        && ((executed_instruction_in.writeback_instruction.wbs == decoded_instruction_in.rs1) ||
            (executed_instruction_in.writeback_instruction.wbs == decoded_instruction_in.rs2))
        ) begin
        fgmt_stage_signal_not_advance(fetch_signal_out);
        fgmt_stage_signal_not_advance(decode_signal_out);
        fgmt_stage_signal_not_advance(execute_signal_out);
    end

    // Load in progress
    // Note it is possible to gain 1 cycle here if we detect the load
    // is also incoming.  But there's a lot of conditions to check and
    // benefit is marginal.  Still,.. TODO in the future.

    if (decoded_instruction_in.valid
        && thread_stalled_on_data_memory_in[cast_to_specific(decoded_instruction_in.thread_id)]
        && (memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].op_q == q_load
          ||memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].op_q == q_amo)
        && (memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.wbs == decoded_instruction_in.rs1 ||
            memory_instruction_in[cast_to_specific(decoded_instruction_in.thread_id)].writeback_instruction.wbs == decoded_instruction_in.rs2)
        ) begin
        fgmt_stage_signal_not_advance(fetch_signal_out);
        fgmt_stage_signal_not_advance(decode_signal_out);
        fgmt_stage_signal_not_advance(execute_signal_out);
    end

    if (execute_signal_out.advance 
        && pc_control_in.fetch_mispredict) begin
        fetch_signal_out.thread_id = pc_control_in.thread_id;
        decode_signal_out.thread_id = pc_control_in.thread_id;
        fgmt_stage_signal_flush_set(fetch_signal_out, pc_control_in.thread_id);
        fgmt_stage_signal_flush_set(decode_signal_out, pc_control_in.thread_id);
    end
    // Update the fetch unit with the latest PC knowledge.  A mispredict
    // can still occur but we didn't detect it in the pipe.
    if (execute_signal_out.advance
        && pc_control_in.wrong_pc
        && pc_control_in.valid) begin
        fgmt_fetch_update_pc(fetch_update_pc_call_out,
            pc_control_in.thread_id, pc_control_in.correct_pc);
    end

end
endmodule


module riscv_pipelined_fgmt #(
    parameter thread_count = 16
    ) (
    input logic       clk
    ,input logic      reset
    ,input logic      [`word_address_size-1:0] reset_pc
    ,output memory_io_req   inst_mem_req
    ,input  memory_io_rsp   inst_mem_rsp
    ,output memory_io_req   data_mem_req
    ,input  memory_io_rsp   data_mem_rsp);

import riscv::*;

localparam thread_count_l2 = $clog2(thread_count);
typedef logic [thread_count_l2 - 1:0] thread_id_t;

function automatic generic_thread_id_t cast_to_generic(input thread_id_t id);
    return $bits(generic_thread_id_t)'(id);
endfunction

function automatic thread_id_t cast_to_specific(input generic_thread_id_t id);
    return id[$bits(thread_id_t)-1:0];
endfunction

fgmt_stage_signal_t fetch_signal, decode_signal, execute_signal, memory_signal;

bool thread_active[0:thread_count-1];
bool thread_stalled_on_data_memory[0:thread_count-1];

fgmt_fetch_update_pc_call_t fgmt_fetch_update_pc_call;
fgmt_fetch_update_pc_return_t fgmt_fetch_update_pc_return;

fgmt_reg_file_bypass_t reg_file_bypass;
fgmt_pc_control_t pc_control;

fgmt_fetched_instruction_t fetched_instruction;
fgmt_decoded_instruction_t decoded_instruction;
fgmt_executed_instruction_t executed_instruction;
fgmt_executed_instruction_t executed_instruction_back;
fgmt_memory_instruction_t memory_instruction[0:thread_count-1];
fgmt_writeback_instruction_t writeback_instruction;

cross_thread_pc_control_t cross_thread_pc_control;


fgmt_control #(
    .thread_count(thread_count)
    ,.flush_pipeline_on_memory_stall(true)
    ) control_m(
    .inst_mem_rsp(inst_mem_rsp)
    ,.data_mem_rsp(data_mem_rsp)
    ,.pc_control_in(pc_control)
    ,.fetched_instruction_in(fetched_instruction)
    ,.decoded_instruction_in(decoded_instruction)
    ,.executed_instruction_in(executed_instruction)
    ,.memory_instruction_in(memory_instruction)
    ,.writeback_instruction_in(writeback_instruction)
    ,.thread_stalled_on_data_memory_in(thread_stalled_on_data_memory)
    ,.fetch_signal_out(fetch_signal)
    ,.decode_signal_out(decode_signal)
    ,.execute_signal_out(execute_signal)
    ,.memory_signal_out(memory_signal)
    ,.fetch_update_pc_call_out(fgmt_fetch_update_pc_call)
    );


fgmt_fetch #(.thread_count(thread_count)) fgmt_fetch_m (
    .clk(clk)
    ,.reset(reset)
    ,.reset_pc(reset_pc)
    // Interface to memory
    ,.inst_mem_req(inst_mem_req)
    ,.inst_mem_rsp(inst_mem_rsp)
    // System state that is read
    ,.thread_active(thread_active)
    ,.thread_stalled_on_data_memory(thread_stalled_on_data_memory)
    // Stage control signalling
    ,.fetch_signal_in(fetch_signal)
    // Interface functions
    ,.fgmt_fetch_update_pc_call_in(fgmt_fetch_update_pc_call)
    ,.fgmt_fetch_update_pc_return_out(fgmt_fetch_update_pc_return)
    // Output
    ,.fgmt_fetched_instruction_out(fetched_instruction)
    );

// Instantiate the decode and writeback module proper
fgmt_decode_and_writeback #(.thread_count(thread_count)) fgmt_decode_and_writeback_m(.clk(clk), .reset(reset)
    // Stage control signalling
    ,.decode_signal_in(decode_signal)

    // Control function interfaces
    ,.reg_file_bypass_out(reg_file_bypass)

    // Principle operation data path
    ,.fetched_instruction_in(fetched_instruction)
    ,.decoded_instruction_out(decoded_instruction)
    ,.writeback_instruction_in(writeback_instruction)
    );


fgmt_memory_writeback_nonblocking #(.thread_count(thread_count)) fgmt_memory_writeback_nonblocking_m (
    .clk(clk), .reset(reset)
    ,.memory_signal_in(memory_signal)

    ,.reg_file_bypass_in(reg_file_bypass)

    ,.thread_stalled_on_data_memory_out(thread_stalled_on_data_memory)
    ,.memory_instruction_out(memory_instruction)
    ,.cross_thread_pc_control_out(cross_thread_pc_control)
    ,.data_mem_req(data_mem_req)
    ,.data_mem_rsp(data_mem_rsp)
    ,.executed_instruction_in(executed_instruction)
    ,.writeback_instruction_out(writeback_instruction)
    );

fgmt_execute #(.thread_count(thread_count)) fgmt_execute_m(
    .clk(clk), .reset(reset)
    ,.reset_pc(reset_pc)
    ,.execute_signal_in(execute_signal)
    ,.memory_signal_in(memory_signal)

    // Execute needs a lot of input to handle bypassing
    ,.fetched_instruction_in(fetched_instruction)
    ,.reg_file_bypass_in(reg_file_bypass)
    ,.executed_instruction_in(executed_instruction)
    ,.writeback_instruction_in(writeback_instruction)
    ,.memory_instruction_in(memory_instruction)
    ,.decoded_instruction_in(decoded_instruction)

    ,.executed_instruction_out(executed_instruction)
    ,.pc_control_out(pc_control)
    );


always_ff @(posedge clk) begin
    automatic thread_id_t thread_id = cast_to_specific(cross_thread_pc_control.thread_id);
    if (cross_thread_pc_control.valid) begin
        if (cross_thread_pc_control.set_enable) begin
            thread_active[thread_id] <= cross_thread_pc_control.enable;
            fgmt_memory_writeback_nonblocking_m.thread_stalled_on_data_memory[thread_id] <= false;
            fgmt_memory_writeback_nonblocking_m.memory_instruction[thread_id].valid <= false;
        end
        if (cross_thread_pc_control.set_pc) begin
            fgmt_fetch_m.thread_state_fetch[thread_id].fetch_pc <= cross_thread_pc_control.pc;
            fgmt_execute_m.pc[thread_id] <= cross_thread_pc_control.pc;            
        end
        if (cross_thread_pc_control.set_pause) begin
            fgmt_fetch_m.thread_state_fetch[thread_id].pause_for <=
                cross_thread_pc_control.pause_for[$bits(pause_t)-1:0];
        end
    end
end

always_ff @(posedge clk) begin
    if (reset) begin
        for (integer i = 0; i < thread_count; i++) begin
            thread_active[i] <= false;
        end
        thread_active[0] <= true;
        fgmt_fetch_m.thread_state_fetch[0].fetch_pc = reset_pc;
        fgmt_execute_m.pc[0] = reset_pc;
    end
end

///////////// Watch dog 

word last_pc;
thread_id_t last_thread;
word watchdog_timer;
localparam deadlock_detection_threadhold = 1000;
word detailed_log_count;
word short_log_count;

function void print_signal(fgmt_stage_signal_t signal); begin
    $write("advance: %d flush: %d ",
        signal.advance, signal.flush);
end
endfunction

always_ff @(posedge clk) begin
    if (reset) begin
        watchdog_timer <= 0;
        last_pc <= 0;
        last_thread <= 0;
        detailed_log_count <= 0;
        short_log_count <= 100;
    end
    else begin
        watchdog_timer <= watchdog_timer + 1;
        if (cast_to_specific(fgmt_decode_and_writeback_m.decoded_instruction_out.thread_id) != last_thread
            || fgmt_decode_and_writeback_m.decoded_instruction_out.pc != last_pc)
            watchdog_timer <= 0;
        if (detailed_log_count > 0)
            detailed_log_count <= detailed_log_count - 1;
        if (short_log_count > 0)
            short_log_count <= short_log_count - 1;

        if (short_log_count > 0) begin
            $display("%5d: (%b,%02d,%h) F: %b,%1b,%02d,%h D: %b,%b,%02d,%h E: %b,%b,%02d,%h (%b,%02d,%b,%h)",
                short_log_count,

                fgmt_fetch_update_pc_call.valid,
                fgmt_fetch_update_pc_call.thread_id,                
                fgmt_fetch_update_pc_call.pc,

                fetch_signal.advance,
                fgmt_fetch_m.to_decode.valid,
                fgmt_fetch_m.to_decode.thread_id,
                fgmt_fetch_m.to_decode.pc,

                decode_signal.advance,
                fgmt_decode_and_writeback_m.decoded_instruction_out.valid,
                fgmt_decode_and_writeback_m.decoded_instruction_out.thread_id,
                fgmt_decode_and_writeback_m.decoded_instruction_out.pc,

                execute_signal.advance,
                fgmt_execute_m.executed_instruction_out.valid,
                fgmt_execute_m.executed_instruction_out.thread_id,
                fgmt_execute_m.executed_instruction_out.pc,

                pc_control.valid,
                pc_control.thread_id,
                pc_control.fetch_mispredict,
                pc_control.correct_pc
                );
        end

        if (watchdog_timer > deadlock_detection_threadhold
            || detailed_log_count > 0) begin
            
            if (watchdog_timer > deadlock_detection_threadhold)
                $display("*** Deadlock detected ***");
            else
                $display("--- Detailed log ---");

            $write("F: ");
            print_signal(fetch_signal);
            $display("valid: %d PC: %h thread: %d",
                fgmt_fetch_m.to_decode.valid,
                fgmt_fetch_m.to_decode.pc,
                fgmt_fetch_m.to_decode.thread_id);

            $write("D: ");
            print_signal(decode_signal);
            $display("valid: %d PC: %h thread: %d",
                fgmt_decode_and_writeback_m.decoded_instruction_out.valid,
                fgmt_decode_and_writeback_m.decoded_instruction_out.pc,
                fgmt_decode_and_writeback_m.decoded_instruction_out.thread_id);

            $write("E: ");
            print_signal(execute_signal);
            $display("valid: %d PC: %h thread: %d",
                fgmt_execute_m.executed_instruction_out.valid,
                fgmt_execute_m.executed_instruction_out.pc,
                fgmt_execute_m.executed_instruction_out.thread_id);

            $write("M: ");
            print_signal(execute_signal);
            $display("");

            $display("--Thread states--");
            for (integer i = 0; i < thread_count; i++) begin
                $write("[%d] active: %d real-PC: %h fetch-PC: %h ",
                    i,
                    thread_active[i],
                    fgmt_execute_m.pc[i],
                    fgmt_fetch_m.thread_state_fetch[i].fetch_pc);
                $display("memory: stalled: %d valid: %d pc: %h",
                    fgmt_memory_writeback_nonblocking_m.thread_stalled_on_data_memory[i],
                    fgmt_memory_writeback_nonblocking_m.memory_instruction[i].valid,
                    fgmt_memory_writeback_nonblocking_m.memory_instruction[i].pc);
            end


        end
    end
end

endmodule
