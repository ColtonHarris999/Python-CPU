`ifndef _clean_core_v
`define _clean_core_v
`include "system.sv"
`include "base.sv"
`include "memory_io.sv"
`include "memory.sv"
`include "riscv_multicycle.sv"
`include "riscv_pipelined.sv"
`include "riscv_multicycle_fgmt.sv"

`include "riscv_pipelined_modularized.sv"
`include "riscv_pipelined_fgmt.sv"

//// This is a wrapper around any core that is used.
//// It used to clean up the interface, but now all it
//// does is provide a single location to perform a design swap

module clean_core(
    input logic       clk
    ,input logic      reset
    ,input logic      [`word_address_size-1:0] reset_pc
    ,output memory_io_req   inst_mem_req
    ,input  memory_io_rsp   inst_mem_rsp
    ,output memory_io_req   data_mem_req
    ,input  memory_io_rsp   data_mem_rsp
    );

`ifdef __64bit__
`include "riscv64_common.sv"
`else
`include "riscv32_common.sv"
`endif

    riscv_pipelined_fgmt core (
    //riscv_multicycle_fgmt core (
    //riscv_multicycle core (
    //riscv_pipelined core (
    //riscv_pipelined_modularized core (
        .clk(clk)
        ,.reset(reset)
        ,.reset_pc(reset_pc)
        ,.inst_mem_req(inst_mem_req)
        ,.inst_mem_rsp(inst_mem_rsp)
        ,.data_mem_req(data_mem_req)
        ,.data_mem_rsp(data_mem_rsp));

endmodule

`endif
