
`define enable_ext_m        1
`define tag_size            5

typedef logic [`tag_size - 1:0]             tag;
typedef logic [5:0]                         shamt;
typedef logic [31:0]                        instr32;
typedef logic [2:0]                         funct3;
typedef logic [6:0]                         funct7;
typedef logic [6:0]                         opcode;
typedef logic signed [`word_size:0]         ext_operand;
typedef logic [`word_size - 1:0]            operand;
typedef logic [`word_size - 1:0]            word;
typedef logic [`word_address_size - 1:0]    word_address;

typedef enum {
     r_format = 0
    ,i_format
    ,s_format
    ,u_format
    ,b_format
    ,j_format
} instr_format;

function automatic bool is_16bit_instruction(logic [31:0] instr);
    if (instr[1:0] == 2'b11)
        return false;
    else
        return true;
endfunction

////// 32 bit instruction decode helpers.
function automatic tag decode_rs2(instr32 instr);
    return instr[24:20];
endfunction

function automatic shamt decode_shamt(instr32 instr);
    return instr[25:20];
endfunction

function automatic tag decode_rs1(instr32 instr);
    return instr[19:15];
endfunction

function automatic tag decode_rd(instr32 instr);
    return instr[11:7];
endfunction

// Must match instruction encoding
typedef enum logic [2:0] {
    f3_addsub  = 0
    ,f3_sll = 1
    ,f3_slt = 2
    ,f3_sltu = 3
    ,f3_xor = 4
    ,f3_sral = 5
    ,f3_or = 6
    ,f3_and = 7
}   f3_op;

// Must match instruction encoding
typedef enum logic [2:0] {
     f3_ext_m_mul = 3'd0
    ,f3_ext_m_mulh = 3'd1
    ,f3_ext_m_mulhsu = 3'd2
    ,f3_ext_m_mulhu = 3'd3
    ,f3_ext_m_div = 3'd4
    ,f3_ext_m_divu = 3'd5
    ,f3_ext_m_rem = 3'd6
    ,f3_ext_m_remu = 3'd7
}   f3_ext_m_op;

function funct3 decode_funct3(instr32 instr);
    return instr[14:12];
endfunction

localparam f7_add = 7'b0000000;
localparam f7_sub = 7'b0100000;
localparam f7_ext_mul = 7'b0000001;

localparam f7a_amoswap = 5'b00001;
localparam f3_amo_w = 3'b010;
localparam f3_amo_d = 3'b011;

function bool f7_mod(funct7 in);
    return in[5];
endfunction

function automatic f3_ext_m_op cast_to_ext_m(funct3 in);
    return f3_ext_m_op'(in);
endfunction


function automatic opcode decode_opcode(instr32 instr);
    return instr[6:0];
endfunction

function automatic logic [`word_size-1:0] decode_imm(instr32 instr, instr_format format);
    case(format)
        i_format : return { {(`word_size - 32 + 21){instr[31]}}, instr[30:20] };
        s_format : return { {(`word_size - 32 + 21){instr[31]}},           instr[30:25], instr[11:8], instr[7] };
        b_format : return { {(`word_size - 32 + 20){instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0 };
        u_format : return { {(`word_size - 32){1'b0}}, instr[31:12], {12{1'b0}} };
        j_format : return { {(`word_size - 32 + 12){instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0 };
        default: return {`word_size{1'b0}};       
    endcase 
endfunction

function automatic ext_operand cast_to_ext_operand(operand in);
    return { in[`word_size - 1], in };
endfunction 

function automatic operand cast_to_operand(ext_operand in);
    return in[`word_size - 1:0];
endfunction

function automatic bool is_negative(ext_operand in);
    return in[`word_size - 1];
endfunction

function automatic bool is_over_or_under(ext_operand in);
    return in[`word_size];
endfunction 

typedef enum logic [4:0] {
    q_load        = 5'b00000
    ,q_store      = 5'b01000
    ,q_madd       = 5'b10000
    ,q_branch     = 5'b11000
    ,q_load_fp    = 5'b00001
    ,q_store_fp   = 5'b01001
    ,q_msub       = 5'b10001
    ,q_jalr       = 5'b11001
    ,q_custom_0   = 5'b00010
    ,q_custom_1   = 5'b01010
    ,q_nmsub      = 5'b10010
    ,q_reserved_0 = 5'b11010
    ,q_misc_mem   = 5'b00011
    ,q_amo        = 5'b01011
    ,q_nmadd      = 5'b10011
    ,q_jal        = 5'b11011
    ,q_op_imm     = 5'b00100
    ,q_op         = 5'b01100
    ,q_op_fp      = 5'b10100
    ,q_system     = 5'b11100
    ,q_auipc      = 5'b00101
    ,q_lui        = 5'b01101
    ,q_reserved_1 = 5'b10101
    ,q_reserved_2 = 5'b11101
    ,q_op_imm32   = 5'b00110
    ,q_op32       = 5'b01110
    ,q_custom_2   = 5'b10110
    ,q_custom_3   = 5'b11110
    ,q_unknown    = 5'b00111
} opcode_q;

function automatic opcode_q decode_opcode_q(instr32 instr);
    // return instr[6:2]   --- this works too, but the code below detects opcodes we don't support
    case (instr[6:2])
// Unfortunately Vivado complains about the simple way. So we take the long way (below)
//        q_load, q_store, q_branch, q_jalr,
//        q_jal, q_op_imm, q_op, q_auipc, q_lui:   return instr[6:2];
            q_load:     return q_load;
            q_store:    return q_store;
            q_branch:   return q_branch;
            q_jalr:     return q_jalr;
            q_jal:      return q_jal;
            q_op_imm:   return q_op_imm;
            q_op:       return q_op;
            q_op_imm32: return q_op_imm32;
            q_op32:     return q_op32;
            q_auipc:    return q_auipc;
            q_lui:      return q_lui;
            q_amo:      return q_amo;
        default:
            return q_unknown;
    endcase
endfunction

function automatic bool decode_writeback(opcode_q in);
    case (in)
        q_load, q_jalr, q_jal, q_op_imm, q_op, q_auipc,
        q_lui, q_op_imm32, q_op32, q_nmadd, q_amo:
            return true;
        default: return false;
    endcase
endfunction

// Must match instruction encoding
typedef enum logic [2:0] {
     memory_b = 0
    ,memory_h = 1
    ,memory_w = 2
    ,memory_d = 3
    ,memory_bu = 4
    ,memory_hu = 5
    ,memory_wu = 6
}   memory_op;

function automatic memory_op cast_to_memory_op(funct3 in);
// This works, except Vivado complains. So we take the long way (below)
//    return in;  // Yes really
    case (in)
        memory_b: return memory_b;
        memory_h: return memory_h;
        memory_w: return memory_w;
        memory_d: return memory_d;
        memory_bu: return memory_bu;
        memory_hu: return memory_hu;
        memory_wu: return memory_wu;
        default: return memory_b;
    endcase;
endfunction

function automatic instr_format decode_format(opcode_q op_q);
    case (op_q)
        q_load, q_op_imm, q_jalr, q_op_imm32:  return i_format;
        q_jal:              return j_format;
        q_branch:           return b_format;
        q_op:               return r_format;
        q_store:            return s_format;
        q_lui, q_auipc:     return u_format;
        q_amo:              return r_format;
        default:
            return r_format;
    endcase
endfunction

function automatic funct7 decode_funct7(instr32 instr, instr_format format);
    return instr[31:25];
endfunction

// Must match instruction encoding
typedef enum logic [2:0] {
     beq = 0
    ,bne = 1
    ,blt = 4
    ,bge = 5
    ,bltu = 6
    ,bgeu = 7
}   branch_ops;

function automatic bool take_branch(ext_operand alu_result, funct3 f3); begin
    logic is_zero = (alu_result[`word_size-1:0] == `word_size'd0) ? true : false;

    case (f3)
        beq:    return is_zero;
        bne:    return !is_zero;
        blt:    return alu_result[`word_size - 1];  // (in1 < in2) ? true : false;
        bge:    return !alu_result[`word_size - 1]; //(in1 >= in2) ? true : false;
        bltu:   return alu_result[`word_size];  // (pos_in1 < pos_in2) ? true : false;
        bgeu:   return !alu_result[`word_size]; //(pos_in1 >= pos_in2) ? true : false;
        default:
            return false;
    endcase
end
endfunction

function automatic word_address compute_next_pc(
     ext_operand    rd1
    ,ext_operand    alu_result
    ,word           imm
    ,word_address   pc
    ,opcode_q       op_q
    ,funct3         f3); begin
    word in1 = pc;
    word in2 = 4;
    case (op_q)
        q_jal:  in2 = imm;
        q_jalr: begin
            in1 = rd1[`word_size-1:0];
            in2 = imm[`word_size-1:0];
        end
        q_branch:
            if (take_branch(alu_result, f3))
                in2 = imm[`word_size-1:0];
        default: begin end
    endcase
    return in1 + in2;
end
endfunction

function automatic ext_operand sign_extend32(logic [31:0] in); begin
    return { {33{in[31]}}, in};    
end
endfunction

function automatic ext_operand zero_extend32(logic [31:0] in); begin
    return { {33{1'b0}}, in};    
end
endfunction

function automatic ext_operand execute(
     ext_operand rd1
    ,ext_operand rd2
    ,ext_operand imm
    ,word        pc
    ,opcode_q    op_q
    ,funct3      f3
    ,funct7      f7);
    logic [31:0] result32;
    ext_operand result;
    ext_operand operand1, operand2;

    operand1 = (op_q == q_auipc)
        ? { 1'b0, pc } : rd1;
    operand2 = (op_q inside {q_op_imm, q_op_imm32, q_load, q_store, q_jalr, q_lui, q_auipc})
        ? imm : rd2;

    case (op_q)
        q_lui:              result = { 1'b0, imm[`word_size-1:0] };
        q_auipc:            result = { 1'b0, pc } + imm;
        q_jal, q_jalr:      result = { 1'b0, pc } + 4;
        q_branch:           result = { 1'b0, operand1[`word_size-1:0] } - { 1'b0, operand2[`word_size-1:0] };
        q_load, q_store, q_amo:    result = operand1 + operand2;
        q_op, q_op_imm: begin
            case (f3)
                f3_addsub:
                    if (op_q == q_op_imm)
                        result = operand1 + operand2;
                    else
                        result = f7_mod(f7) ? (operand1 - operand2) : (operand1 + operand2);
                f3_slt:     result = (operand1 < operand2) ? 1 : 0;
                f3_sltu:    result = { 1'b0, operand1[`word_size-1:0] } < { 1'b0, operand2[`word_size-1:0] } ? 1 : 0;
                f3_sll:     result = operand1 << operand2[5:0];
                f3_sral:    result = f7_mod(f7) ? (operand1 >>> operand2[5:0]) : { 1'b0, operand1[`word_size-1:0] } >> operand2[5:0];
                f3_xor:     result = operand1 ^ operand2;
                f3_or:      result = operand1 | operand2;
                f3_and:     result = operand1 & operand2;
                default: begin
                            $display("Unimplemnted f3: %x", f3);
                            result = 0;
                end
            endcase
        end
        q_op_imm32, q_op32: begin
            case (f3)
                f3_addsub:
                    if (op_q == q_op_imm32)
                        result32 = operand1[31:0] + operand2[31:0];
                    else
                        result32 = f7_mod(f7) ? (operand1[31:0] - operand2[31:0]) : (operand1[31:0] + operand2[31:0]);
                f3_sll:     result32 = operand1[31:0] << operand2[4:0];
                f3_sral:    result32 = f7_mod(f7) ? (operand1[31:0] >>> operand2[4:0]) : (operand1[31:0] >> operand2[4:0]);
                default: begin
                            $display("Unimplemented (32) f3: %x", f3);
                            result32 = 0;
                end
            endcase
            result = {1'b0, {32{result32[31]}}, result32};
        end
        default: begin
            $display("Should never get here: pc=%x op=%b", pc, op_q);
            result = 0;
        end
    endcase
    //if (op_q == q_op_imm32 && f3 == f3_addsub)
    //    $display("%d: %x %x result32: %x result: %x", f7_mod(f7),
    //        operand1, operand2, result32, result);
    return result;
endfunction

function automatic word shuffle_load_data(word in, word low_addr); begin
    logic [7:0] b0 = in[7:0];
    logic [7:0] b1 = in[15:8];
    logic [7:0] b2 = in[23:16];
    logic [7:0] b3 = in[31:24];
    logic [7:0] b4 = in[39:32];
    logic [7:0] b5 = in[47:40];
    logic [7:0] b6 = in[55:48];
    logic [7:0] b7 = in[63:56];

    case (low_addr[2:0])
        3'b000:  return { b7, b6, b5, b4, b3, b2, b1, b0 };
        3'b001:  return { b0, b7, b6, b5, b4, b3, b2, b1 };
        3'b010:  return { b1, b0, b7, b6, b5, b4, b3, b2 };
        3'b011:  return { b2, b1, b0, b7, b6, b5, b4, b3 };
        3'b100:  return { b3, b2, b1, b0, b7, b6, b5, b4 };
        3'b101:  return { b4, b3, b2, b1, b0, b7, b6, b5 };
        3'b110:  return { b5, b4, b3, b2, b1, b0, b7, b6 };
        3'b111:  return { b6, b5, b4, b3, b2, b1, b0, b7 };
    endcase
end
endfunction

function automatic word shuffle_store_data(word in, word low_addr); begin
    logic [7:0] b0 = in[7:0];
    logic [7:0] b1 = in[15:8];
    logic [7:0] b2 = in[23:16];
    logic [7:0] b3 = in[31:24];
    logic [7:0] b4 = in[39:32];
    logic [7:0] b5 = in[47:40];
    logic [7:0] b6 = in[55:48];
    logic [7:0] b7 = in[63:56];

    case (low_addr[2:0])
        3'b000:  return { b7, b6, b5, b4, b3, b2, b1, b0 };
        3'b001:  return { b6, b5, b4, b3, b2, b1, b0, b7 };
        3'b010:  return { b5, b4, b3, b2, b1, b0, b7, b6 };
        3'b011:  return { b4, b3, b2, b1, b0, b7, b6, b5 };
        3'b100:  return { b3, b2, b1, b0, b7, b6, b5, b4 };
        3'b101:  return { b2, b1, b0, b7, b6, b5, b4, b3 };
        3'b110:  return { b1, b0, b7, b6, b5, b4, b3, b2 };
        3'b111:  return { b0, b7, b6, b5, b4, b3, b2, b1 };
    endcase
end
endfunction


function automatic word subset_load_data(word in, memory_op op);
    case (op)
        memory_d:   return in;
        memory_w:   return { {(`word_size - 32 + 0){in[31]}}, in[31:0] };
        memory_h:   return { {(`word_size - 32 + 16){in[15]}}, in[15:0] };
        memory_b:   return { {(`word_size - 32 + 24){in[7]}}, in[7:0] };
        memory_bu:  return { {(`word_size - 32 + 24){1'b0}}, in[7:0] };
        memory_hu:  return { {(`word_size - 32 + 16){1'b0}}, in[15:0] };
        memory_wu:  return { {(`word_size - 32 + 0){1'b0}}, in[31:0] };
        default:    return in;
    endcase
endfunction

function automatic logic [7:0] shuffle_store_mask(logic [7:0] mask, word low_addr);
    case (low_addr[2:0])
        3'b000:  return { mask[7], mask[6], mask[5], mask[4], mask[3], mask[2], mask[1], mask[0] };
        3'b001:  return { mask[6], mask[5], mask[4], mask[3], mask[2], mask[1], mask[0], mask[7] };
        3'b010:  return { mask[5], mask[4], mask[3], mask[2], mask[1], mask[0], mask[7], mask[6] };
        3'b011:  return { mask[4], mask[3], mask[2], mask[1], mask[0], mask[7], mask[6], mask[5] };
        3'b100:  return { mask[3], mask[2], mask[1], mask[0], mask[7], mask[6], mask[5], mask[4] };
        3'b101:  return { mask[2], mask[1], mask[0], mask[7], mask[6], mask[5], mask[4], mask[3] };
        3'b110:  return { mask[1], mask[0], mask[7], mask[6], mask[5], mask[4], mask[3], mask[2] };
        3'b111:  return { mask[0], mask[7], mask[6], mask[5], mask[4], mask[3], mask[2], mask[1] };
    endcase
endfunction

function automatic logic [7:0] memory_mask(memory_op op);
    case (op)
        memory_b, memory_bu:    return 8'b00000001;
        memory_h, memory_hu:    return 8'b00000011;
        memory_w, memory_wu:    return 8'b00001111;
        memory_d:               return 8'b11111111;
        default:                return 8'b11111111;
    endcase
endfunction

function word subset_load_data_amo(word in, word addr, funct3 f3);
    if (f3 == f3_amo_d)
        return in;
    if (addr[2] == zero)
        return sign_extend32(in[31:0])[63:0];
    else
        return sign_extend32(in[63:32])[63:0];
endfunction

