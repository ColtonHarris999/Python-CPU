`ifndef _riscv_multicycle_fgmt
`define _riscv_multicycle_fgmt
/*

This is a very simple 7 stage multicycle RISC-V 32bit design.

The stages are fetch, fetch, decode, execute, memory, memory, writeback

*/

`include "system.sv"
`include "ports.sv"

`define thread_status_word  0
`define thread_pc           1
`define thread_pause        2

`include "riscv.sv"

module riscv_multicycle_fgmt #(
    parameter thread_count = 16
    ) (
     input logic clk
    ,input logic reset
    ,input logic [`word_address_size-1:0]       reset_pc
    ,output memory_io_req   inst_mem_req
    ,input  memory_io_rsp   inst_mem_rsp
    ,output memory_io_req   data_mem_req
    ,input  memory_io_rsp   data_mem_rsp);

import riscv::*;

localparam thread_count_l2 = $clog2(thread_count);
typedef logic [thread_count_l2 - 1:0] thread_id_t;


/*

 Almost all of the lower 32KB is for internal processor control
 Really anything can be mapped into this space for accessing CPU
 specific regs.  In this design there's a lot of control for
 the FGMT aspect.  But the infrastructure built for this MMIO
 mapping of CPU regs is general enough that any CPU specific reg
 can be mapped into it.

*/


localparam internal_mmio_control_low = `fgmt_internal_mmio_low;
localparam internal_mmio_control_mask = (internal_mmio_control_low - 1);
localparam internal_mmio_control_high = `fgmt_internal_mmio_high;
`define internal_mmio_size  21

// Thread control
localparam thread_master_control_block_addr = (`internal_mmio_size'h0010 + internal_mmio_control_low);
localparam thread_control_block_addr = (`internal_mmio_size'h0100 + internal_mmio_control_low);
localparam thread_integer_register_block_addr = (`internal_mmio_size'h1000 + internal_mmio_control_low);
localparam thread_integer_register_block_mask = `internal_mmio_size'(32 * `word_size_bytes - 1);
localparam thread_control_block_size = 32; // size of tcb per thread
`define thread_status_word  0
`define thread_pc           1
`define thread_pause        2
`define thread_reserved     3

bool    is_internal_mmio;
logic [`internal_mmio_size-1:0] internal_mmio_addr;
logic [`word_size-1:0]  internal_mmio_read_result;
logic [`word_size-1:0]  internal_mmio_write_data;
logic [`word_size/8 - 1:0] do_internal_write;
logic [`word_size/8 - 1:0] do_internal_read;

logic internal_mmio_regread;
logic internal_mmio_regwrite;
logic thread_active[0:thread_count-1];
logic thread_stalled_on_data_memory[0:thread_count-1];
logic thread_stalled_on_instruction_memory[0:thread_count-1];
logic [thread_count_l2 - 1:0] internal_mmio_reg_thread_select;
tag internal_mmio_rs;

// Layout of TCMCB
// thread_id
// thread_count
// addr(thread control block start)
// addr(thread integer register block start)

bool reset_thread_stall_valid;
thread_id_t reset_thread_stall;
word reset_thread_stall_to;

thread_id_t set_pc_of_thread;
bool set_pc_of_thread_valid;
word set_pc_of_thread_to;

thread_id_t set_pause_of_thread;
bool set_pause_of_thread_valid;
word set_pause_of_thread_to;

`define pause_bits 10
logic [`pause_bits-1:0] pause_counts[0:thread_count-1];

always_comb begin
    internal_mmio_read_result = `word_size'(1'h0);
    internal_mmio_regread = false;
    internal_mmio_regwrite = false;
    internal_mmio_rs = `tag_size'h00;
    internal_mmio_reg_thread_select = 0;
    reset_thread_stall = 0;
    reset_thread_stall_to = 0;
    reset_thread_stall_valid = false;
    set_pc_of_thread = 0;
    set_pc_of_thread_to = 0;
    set_pc_of_thread_valid = false;

    if (current_stage == stage_mem && is_internal_mmio) begin
        /*
        struct thread_master_control_block {
            unsigned long current_thread;                           // read only
            unsigned long thread_count;                             // read only
            struct thread_control_block *thread_control_blocks;     // read only
            struct thread_integer_register_block *thread_integer_register_blocks;   // read only
        };
        */
        //$display("IS_INTERNAL_MMIO: %x current_thread = %x do_internal_write=%d do_internal_read=%d", internal_mmio_addr, current_thread, do_internal_write, do_internal_read);
        case (internal_mmio_addr)
            thread_master_control_block_addr:
                internal_mmio_read_result = `word_size'(current_thread);

            (thread_master_control_block_addr + 1*`word_size_bytes):
                internal_mmio_read_result = `word_size'(thread_count);

            (thread_master_control_block_addr + 2*`word_size_bytes):
                internal_mmio_read_result = `word_size'(thread_control_block_addr);

            (thread_master_control_block_addr + 3*`word_size_bytes):
                internal_mmio_read_result = `word_size'(thread_integer_register_block_addr);
        endcase;

        if (internal_mmio_addr >= thread_control_block_addr &&
            internal_mmio_addr < (thread_control_block_addr + thread_control_block_size * thread_count)) begin
            logic [thread_count_l2-1:0] thread_of_interest =
                thread_count_l2'(
                    (internal_mmio_addr - thread_control_block_addr) >> (
                        $clog2(`word_size_bytes) +
                        $clog2(thread_control_block_size/`word_size_bytes)));

            logic [$clog2(thread_control_block_size/`word_size_bytes)-1:0] offset =
                $clog2(thread_control_block_size/`word_size_bytes - 1)'(internal_mmio_addr >> $clog2(`word_size_bytes));

            /*
            struct thread_control_block {
                volatile unsigned long status_word;                // variable
                volatile unsigned long pc;                         // read/write
                volatile unsigned long delay;
                volatile unsigned long reserved;
            };
            */
            case (offset)
                `thread_status_word:
                    if (do_internal_write != 0) begin
                        //$display("%d/%x Setting thread %d status to %x", current_thread, pc[current_thread], thread_of_interest, internal_mmio_write_data[0]);
                        reset_thread_stall_valid = true;
                        reset_thread_stall = thread_of_interest;
                        reset_thread_stall_to = internal_mmio_write_data;
                    end
                    else begin
                        //$display("Reading thread %d status", thread_of_interest);
                        internal_mmio_read_result = `word_size'(
                            { thread_stalled_on_data_memory[thread_of_interest], thread_active[thread_of_interest] });
                    end

                `thread_pc: 
                    if (do_internal_write != 0) begin
                        //$display("Setting thread %d PC to %x", thread_of_interest, internal_mmio_write_data);
                        set_pc_of_thread_valid = true;
                        set_pc_of_thread = thread_of_interest;
                        set_pc_of_thread_to = internal_mmio_write_data;
                    end else begin
                        //$display("Reading thread %d PC", thread_of_interest);
                        internal_mmio_read_result = pc[thread_of_interest];
                    end
                `thread_pause:
                    if (do_internal_write != 0) begin
                        //$display("Setting thread %d pause to %x", thread_of_interest, internal_mmio_write_data);
                        set_pause_of_thread_valid = true;
                        set_pause_of_thread = thread_of_interest;
                        set_pause_of_thread_to = internal_mmio_write_data;

                    end else begin
                        //$display("Reading thread pause %d", thread_of_interest);
                        internal_mmio_read_result = `word_size'(pause_counts[thread_of_interest]);
                    end
            endcase;
        end

        if (internal_mmio_addr >= thread_integer_register_block_addr &&
            internal_mmio_addr < (thread_integer_register_block_addr + 32 * `word_size_bytes * thread_count)) begin
            logic [thread_count_l2-1:0] thread_of_interest = thread_count_l2'(internal_mmio_addr >> $clog2(`word_size_bytes) + $clog2((32 * `word_size_bytes)/`word_size_bytes));
            logic [4:0] offset = 5'((internal_mmio_addr & thread_integer_register_block_mask) >> $clog2(`word_size_bytes));
            internal_mmio_reg_thread_select = thread_of_interest;
            
            /*
            struct thread_integer_register_block {
                volatile native_t regs[32];           // read/write
            };
            */
            if (do_internal_write != 0) begin
                //$display("MMIO cross thread write to register %d on thread %d to %x", offset, thread_of_interest, internal_mmio_write_data);
                internal_mmio_regwrite = true;
                internal_mmio_rs = offset;
            end else begin
                //$display("MMIO cross thread read of register %d on thread %d", offset, thread_of_interest);
                internal_mmio_regread = true;
                internal_mmio_rs = offset;
            end
            
        end
    end    

end

typedef enum {
    stage_fetch
    ,stage_decode
    ,stage_execute
    ,stage_mem
    ,stage_writeback
    ,stage_thread_select
}   stage;

stage   current_stage;





/*

 Instruction fetch

*/
word_address    pc[0:thread_count - 1];

thread_id_t current_thread;


typedef struct packed {
    bool        issued;
//    thread_id_t thread_id;
    word        addr;

    instr32     instruction_read;
    bool        finished;
} stalled_fetch_transaction;
stalled_fetch_transaction stalled_fetch_transactions[0:thread_count-1];

always_comb begin
    inst_mem_req = memory_io_no_req;
    inst_mem_req.addr = pc[current_thread];
    inst_mem_req.user_tag = (`user_tag_size)'(current_thread);
    inst_mem_req.valid = inst_mem_rsp.ready
                            && (current_stage == stage_fetch)
                            && stalled_fetch_transactions[current_thread].issued == false;
    inst_mem_req.do_read[3:0] = 4'b1111;
end

/*
always_ff @(posedge clk) begin
    if (current_thread != 0) begin
        $display("[%d] PC = %x reg_file[%d][2] = %x", current_thread, pc[current_thread], current_thread, reg_file[current_thread][2]);
    end
end

always_ff @(posedge clk) begin
    if (instruction_addr[63] != 1 && instruction_valid) begin
        $display("FGMT [%d] issueing invalid request for %x pc[%d] = %x next_pcs[%d] = %x",
            current_thread, instruction_addr, current_thread, pc[current_thread], current_thread, next_pcs[current_thread]);
    end   

    if (data_addr[63] != 1 && (data_read_valid || data_write_valid)) begin
        $display("FGMT [%d] issueing data request for %x at PC=%x fetched_instruction = %x valid=%d",
            current_thread, data_addr, pc[current_thread], fetched_instruction, fetched_instruction_valid);
    end
end
*/
always_ff @(posedge clk) begin

    if (reset) begin
        for (integer i = 0; i < thread_count; i++) begin
            stalled_fetch_transactions[i].issued <= false;
            stalled_fetch_transactions[i].finished <= false;
            thread_stalled_on_instruction_memory[i] <= false;
        end
    end else begin
        // When in fetch, potentially issue a fetch request
        if (inst_mem_req.valid) begin
            //$display("Issueing instruction on %d address: %x",
            //    current_thread, pc[current_thread]);
            stalled_fetch_transactions[current_thread].issued <= true;
            stalled_fetch_transactions[current_thread].finished <= false;
            thread_stalled_on_instruction_memory[current_thread] <= true;
        end
        
        // Handle a force reset for a thread
        if (current_stage == stage_mem && reset_thread_stall_valid) begin
            stalled_fetch_transactions[reset_thread_stall].issued <= false;
            stalled_fetch_transactions[reset_thread_stall].finished <= false;
            thread_stalled_on_instruction_memory[reset_thread_stall] <= false;
        end else
        // Handle a force reset for a thread
        if (current_stage == stage_mem && set_pc_of_thread_valid) begin
            stalled_fetch_transactions[set_pc_of_thread].issued <= false;
            stalled_fetch_transactions[set_pc_of_thread].finished <= false;
            thread_stalled_on_instruction_memory[set_pc_of_thread] <= false;
        end else
        // When in writeback void out the fetch state for the thread
        if (current_stage == stage_writeback) begin
            stalled_fetch_transactions[current_thread].issued <= false;
            stalled_fetch_transactions[current_thread].finished <= false;
        end

        // No matter the stage, capture the return from fetch
        if (inst_mem_rsp.valid) begin
            automatic thread_id_t thread = inst_mem_rsp.user_tag[thread_count_l2 - 1:0];
            if (stalled_fetch_transactions[thread].issued) begin
                //if (thread == 1)
                //    $display("instruction_response_valid on thread 1 with %x", instruction_read);
                stalled_fetch_transactions[thread].finished <= true;
                stalled_fetch_transactions[thread].instruction_read <= shuffle_store_data(inst_mem_rsp.data, inst_mem_rsp.addr)[31:0];
                thread_stalled_on_instruction_memory[thread] <= false;
                //$display("Received instruction: %x tag: %x",
                //    instruction_read, instruction_response_tag);
            end
        end
    end
end


instr32 fetched_instruction;
assign fetched_instruction = stalled_fetch_transactions[current_thread].instruction_read;

logic fetched_instruction_valid;
assign fetched_instruction_valid = (stalled_fetch_transactions[current_thread].issued
                            && stalled_fetch_transactions[current_thread].finished);

/*

  Instruction decode

*/

tag     rs1;
tag     rs2;
word    rd1;
word    rd2;
tag     wbs;
word    wbd;
logic   wbv;
word    reg_file_rd1;
word    reg_file_rd2;
word    imm;
funct3  f3;
funct7  f7;
opcode_q op_q;
instr_format format;
bool    is_memory_op;

word    reg_file[0:thread_count - 1][0:31];

always_comb begin
    rs1 = decode_rs1(fetched_instruction);
    rs2 = decode_rs2(fetched_instruction);
    wbs = decode_rd(fetched_instruction);
    f3 = decode_funct3(fetched_instruction);
    op_q = decode_opcode_q(fetched_instruction);
    format = decode_format(op_q);
    imm = decode_imm(fetched_instruction, format);
    wbv = decode_writeback(op_q);
    f7 = decode_funct7(fetched_instruction, format);
end

logic read_reg_valid;
logic write_reg_valid;
logic [thread_count_l2 - 1:0] reg_thread_select;
tag reg_rs1;
tag reg_rs2;
tag reg_ws;
word reg_wbd;
word internal_regread_result;
bool internal_regread_init;
bool internal_regread_valid;

// Because MEM and WB are variable length stages we don't exactly know
// when we read the register file for an internal reg-read.  So we capture
// the result if we do and conditional it in at writeback.
always_ff @(posedge clk) begin
    if (current_stage == stage_fetch)
        internal_regread_valid <= false;
    if (internal_regread_init) begin
        internal_regread_result <= reg_file_rd1;
        internal_regread_valid <= true;
    end
end

always_ff @(posedge clk) begin
    if (read_reg_valid) begin
        //if (current_thread != reg_thread_select)
            //$display("CROSS THREAD READ: %d reading %d on %d and %d", current_thread, reg_thread_select, reg_rs1, reg_rs2);
        reg_file_rd1 <= reg_file[reg_thread_select][reg_rs1];
        reg_file_rd2 <= reg_file[reg_thread_select][reg_rs2];
    end
    else if (write_reg_valid) begin
        //if (current_thread != reg_thread_select)
            //$display("CROSS THREAD WRITE: %d writing %d on %d with %x", current_thread, reg_thread_select, reg_ws, reg_wbd);
        reg_file[reg_thread_select][reg_ws] <= reg_wbd;
    end
end

/* Select what to writeback:
    A load that was delayed
    The current instruction (add, etc)
    A load/store that actually targets the register file.
*/
tag delayed_load_ws;
word delayed_load_data;
thread_id_t delayed_load_thread_id;
bool writeback_delayed_load;

always_comb begin
    read_reg_valid = false;
    write_reg_valid = false;
    reg_ws = 0;
    reg_wbd = 0;
    reg_rs1 = 0;
    reg_rs2 = 0;
    reg_thread_select = 0;
    internal_regread_init = false;

    //// Reg write
    if (writeback_delayed_load) begin
        write_reg_valid = true;
        reg_thread_select = delayed_load_thread_id;
        reg_wbd = delayed_load_data;
        reg_ws = delayed_load_ws;
    end else
    if (current_stage == stage_writeback && wbv) begin
        if (is_internal_mmio ||
            (op_q != q_load && op_q != q_store && op_q != q_amo)) begin
            write_reg_valid = true;
            reg_thread_select = current_thread;
            reg_ws = wbs;
            reg_wbd = wbd;
        end
    end else
    if (current_stage == stage_mem && internal_mmio_regwrite) begin
        //$display("internal_mmio_regwrite: [%d]%d = %x", internal_mmio_reg_thread_select, internal_mmio_rs, internal_mmio_write_data);
        write_reg_valid = true;
        reg_thread_select = internal_mmio_reg_thread_select;
        reg_wbd = internal_mmio_write_data;
        reg_ws = internal_mmio_rs;
    end

    //// Reg read
    if (current_stage == stage_decode) begin
        read_reg_valid = true;
        reg_thread_select = current_thread;
        reg_rs1 = rs1;
        reg_rs2 = rs2;
    end
    if (current_stage == stage_mem && internal_mmio_regread) begin
        read_reg_valid = true;
        reg_thread_select = internal_mmio_reg_thread_select;
        reg_rs1 = internal_mmio_rs;
        internal_regread_init = true;
    end
end


////////////////////////////////////////////////////////////////////////////////////////////
//
//
//
/////////////////////////////////////////////////////////////////////////////////////////////

logic memory_stage_complete;
always_comb begin
    if (!is_internal_mmio && (op_q == q_load || op_q == q_store || op_q == q_amo)) begin
        // So long as we can issue the memory op then this stage is complete
        if (data_mem_rsp.ready)
            memory_stage_complete = true;
        else
            memory_stage_complete = false;
    end else
        memory_stage_complete = true;
end

/*

 Instruction execute

 */

always_comb begin
    if (rs1 == `tag_size'd0)
        rd1 = `word_size'd0;
    else
        rd1 = reg_file_rd1;        
    if (rs2 == `tag_size'd0)
        rd2 = `word_size'd0;
    else
        rd2 = reg_file_rd2;        
end

ext_operand exec_result_comb;
word next_pc_comb;
always_comb begin
    exec_result_comb = execute(
        cast_to_ext_operand(rd1),
        cast_to_ext_operand(rd2),
        cast_to_ext_operand(imm),
        pc[current_thread],
        op_q,
        f3,
        f7);
    next_pc_comb = compute_next_pc(
        cast_to_ext_operand(rd1),
        exec_result_comb,
        imm,
        pc[current_thread],
        op_q,
        f3);
end


word exec_result;
word next_pc;

always_ff @(posedge clk) begin
    if (current_stage == stage_execute) begin
        exec_result = exec_result_comb[`word_size-1:0];
        next_pc <= next_pc_comb;

        if ((op_q == q_store || op_q == q_load) &&
            exec_result >= (`word_size)'(internal_mmio_control_low)
            && exec_result < (`word_size)'(internal_mmio_control_high)) begin
            is_internal_mmio = true;
        end else
            is_internal_mmio = false;
    end
end


always_comb begin
    data_mem_req = memory_io_no_req;

    data_mem_req.user_tag = `user_tag_size'({current_thread});
    do_internal_read = {(`word_size_bytes){1'b0}};
    do_internal_write = {(`word_size_bytes){1'b0}};
    internal_mmio_write_data = {(`word_size){1'b0}};
    internal_mmio_addr = {(`internal_mmio_size){1'b0}};


    if (current_stage == stage_mem &&
        (op_q == q_store || op_q == q_load || op_q == q_amo)) begin
        if (!is_internal_mmio && data_mem_rsp.ready) begin
            if (op_q == q_store) begin
                data_mem_req.addr = exec_result[`word_address_size - 1:0];
                data_mem_req.valid = true;
                data_mem_req.do_write = shuffle_store_mask(memory_mask(cast_to_memory_op(f3)), exec_result);
                data_mem_req.data = shuffle_store_data(rd2, exec_result);
            end else
            if (op_q == q_load) begin
                data_mem_req.addr = exec_result[`word_address_size - 1:0];
                data_mem_req.valid = true;
                data_mem_req.do_read = shuffle_store_mask(memory_mask(cast_to_memory_op(f3)), exec_result);
            end else
            if (op_q == q_amo) begin
                data_mem_req.addr = rd1;
                data_mem_req.data = rd2;
                data_mem_req.valid = true;
                if (f3 == f3_amo_d) begin
                    data_mem_req.do_write = {(`word_size_bytes){1'b1}};
                    data_mem_req.do_read = {(`word_size_bytes){1'b1}};
                end
`ifdef __64bit__
                else begin
                    //?
                    $display("32 bit AMO?");
                    data_mem_req.do_write = 8'h0f;
                    data_mem_req.do_read = 8'h0f;
                end
`endif
            end
        end else if (is_internal_mmio) begin
            internal_mmio_addr = exec_result[`internal_mmio_size - 1:0];
            if (op_q == q_store) begin
                do_internal_write = shuffle_store_mask(memory_mask(cast_to_memory_op(f3)), exec_result);
                internal_mmio_write_data = shuffle_store_data(rd2, exec_result);
            end else begin
                do_internal_read = shuffle_store_mask(memory_mask(cast_to_memory_op(f3)), exec_result);
            end

        end
    end

end


typedef struct packed {
    bool        valid;
    bool        finished;
    word        addr;
    bool        write_valid;
    bool        read_valid;
    logic [`word_size_bytes-1:0] read_byte;
    logic [`word_size_bytes-1:0] write_byte;
    word        load_result;
    tag         wbs;
    bool        wbv;
    word        exec_result;
    funct3      f3;
    opcode_q    op_q;
    word        rd1;
} stalled_memory_transaction;
stalled_memory_transaction stalled_memory_transactions[0:thread_count-1];

word next_pcs[0:thread_count-1];

word internal_load_result;

always_ff @(posedge clk) begin
    automatic logic [thread_count_l2 - 1:0] response_thread = data_mem_rsp.user_tag[thread_count_l2 - 1:0];

    if (reset) begin
        for (integer i = 0; i < thread_count; i++) begin
            stalled_memory_transactions[i].valid <= false;
            stalled_memory_transactions[i].finished <= false;
            thread_stalled_on_data_memory[i] <= false;
            thread_active[i] <= false;
        end
        thread_active[0] <= true;
    end else begin
        // Store the next_pc in the next PC map
        if (current_stage == stage_fetch)
            next_pcs[current_thread] <= pc[current_thread];

        if (current_stage == stage_execute)
            next_pcs[current_thread] <= next_pc_comb;
        else
        // This is written this way to enable a good synthesizer to optimize the next_pcs structure
        if (current_stage == stage_mem && set_pc_of_thread_valid) begin
            next_pcs[set_pc_of_thread] <= set_pc_of_thread_to;
        end

        // Send all memory transactions into the scoreboard
        if (current_stage == stage_mem && !is_internal_mmio && (data_mem_req.valid)) begin
            if (stalled_memory_transactions[current_thread].valid)
                $display("Curious situation, issuing memory request but already in scoreboard?");
            stalled_memory_transactions[current_thread].valid <= true;
            stalled_memory_transactions[current_thread].finished <= false;
            stalled_memory_transactions[current_thread].addr <= data_mem_req.addr;
            stalled_memory_transactions[current_thread].write_valid <= (data_mem_req.do_write != 0);
            stalled_memory_transactions[current_thread].read_valid <= (data_mem_req.do_read != 0);
            stalled_memory_transactions[current_thread].read_byte <= data_mem_req.do_read;
            stalled_memory_transactions[current_thread].write_byte <= data_mem_req.do_write;
            stalled_memory_transactions[current_thread].wbs <= wbs;
            stalled_memory_transactions[current_thread].wbv <= wbv;
            stalled_memory_transactions[current_thread].exec_result <= exec_result;
            stalled_memory_transactions[current_thread].f3 <= f3;
            stalled_memory_transactions[current_thread].rd1 <= rd1;
            stalled_memory_transactions[current_thread].op_q <= op_q;
            thread_stalled_on_data_memory[current_thread] <= true;
        end

        // Process any incoming responses from the memory system
        if (data_mem_rsp.valid) begin
            if (data_mem_rsp.user_tag == {(`user_tag_size){1'b1}})
                $display("Memory reply with bogus user tag");

            if (stalled_memory_transactions[response_thread].valid) begin
                stalled_memory_transactions[response_thread].load_result <= data_mem_rsp.data;
                if (stalled_memory_transactions[response_thread].finished)
                    $display("Curious situation, reply from memory system but already finished?"); 
                stalled_memory_transactions[response_thread].finished <= true;
                // Process stores immediately and out of cycle with the core.
                if (stalled_memory_transactions[response_thread].op_q == q_store) begin
                    stalled_memory_transactions[response_thread].finished <= false;
                    stalled_memory_transactions[response_thread].valid <= false;
                    thread_stalled_on_data_memory[response_thread] <= false;
                end
            end else begin
                $display("Response for thread %d with no matching scoreboard data %x V:%d F:%d S:%d",
                    response_thread, data_mem_rsp.data,
                    stalled_memory_transactions[response_thread].valid,
                    stalled_memory_transactions[response_thread].finished,
                    thread_stalled_on_data_memory[response_thread]);
            end
        end
        // Handle thread pauses
        if (current_stage == stage_mem && set_pause_of_thread_valid) begin
            if (set_pause_of_thread_to > `word_size'({(`pause_bits){1'b1}}))
                pause_counts[set_pause_of_thread] <= {(`pause_bits){1'b1}};
            else
                pause_counts[set_pause_of_thread] <= set_pause_of_thread_to[`pause_bits-1:0];
            if (set_pause_of_thread_to != 0)
                thread_active[set_pause_of_thread] <= false; 
        end
        if (current_stage == stage_thread_select) begin
            for (integer i = 0; i < thread_count; i++) begin
                if (pause_counts[i] != 0) begin
                    if (pause_counts[i] == 1)
                        thread_active[i] <= true;
                    pause_counts[i] <= pause_counts[i] - 1;
                end
            end
        end
        // handle a programatic reset for a thread
        if (current_stage == stage_mem && reset_thread_stall_valid) begin
            /// TOOD: should be reset_thread_stall?
            stalled_memory_transactions[reset_thread_stall].valid <= false;
            stalled_memory_transactions[reset_thread_stall].finished <= false;
            thread_stalled_on_data_memory[reset_thread_stall] <= false;
            thread_active[reset_thread_stall] <= reset_thread_stall_to[0];
            pause_counts[reset_thread_stall] <= 0;
        end

        if (current_stage == stage_mem)
            internal_load_result <= internal_mmio_read_result;

        // Update the scoreboard if we process those responses
        if (writeback_delayed_load) begin
            thread_stalled_on_data_memory[delayed_load_thread_id] <= false;
            stalled_memory_transactions[delayed_load_thread_id].valid <= false;
            stalled_memory_transactions[delayed_load_thread_id].finished <= false;
        end
    end
end



logic writeback_stage_complete;
always_comb begin
    writeback_stage_complete = false;
    writeback_delayed_load = false;
    delayed_load_ws = 0;
    delayed_load_data = 0;
    delayed_load_thread_id = 0;

    if (current_stage == stage_writeback || current_stage == stage_thread_select) begin
        integer i;
        // process the first deferred load
        for (i = 0; i < thread_count; i++) begin
            if (!writeback_delayed_load &&
                stalled_memory_transactions[i].valid &&
                stalled_memory_transactions[i].finished) begin
                delayed_load_ws = stalled_memory_transactions[i].wbs;
                if (stalled_memory_transactions[i].op_q == q_load)
                    delayed_load_data = subset_load_data(
                        shuffle_load_data(stalled_memory_transactions[i].load_result,
                            stalled_memory_transactions[i].exec_result),
                        cast_to_memory_op(stalled_memory_transactions[i].f3));
                else // AMO
                    delayed_load_data = subset_load_data_amo(stalled_memory_transactions[i].load_result,
                        stalled_memory_transactions[i].rd1,
                        stalled_memory_transactions[i].f3);
                writeback_delayed_load = true;
                delayed_load_thread_id = thread_count_l2'(i);
            end
        end
    end
    if (writeback_delayed_load == false)
        writeback_stage_complete = true;

    // Default (which coccurs when delayed_load is false) is to process the instruction
    wbd = exec_result;
    if (current_stage == stage_writeback) begin
        if (is_internal_mmio && op_q == q_load) begin
            if (!internal_mmio_regread) begin
                wbd = internal_load_result;
            end
            else begin
                wbd = internal_regread_valid ?  internal_regread_result : reg_file_rd1;
            end
        end else
            wbd = exec_result;
    end
end



bool thread_select_stage_complete;
thread_id_t next_thread;
bool next_thread_valid;

always_comb begin
    integer current_thread_i = 0, i = 0, ii = 0;

    next_thread_valid = false;
    next_thread = 0;
    thread_select_stage_complete = false;
    if (current_stage == stage_thread_select) begin
        current_thread_i = integer'(current_thread);
        for (ii = 0; ii < thread_count; ii++) begin 
            i = (ii + current_thread_i + 1) % integer'(thread_count);
            if (!next_thread_valid &&
                thread_active[i] &&
                !thread_stalled_on_data_memory[i] &&
                !thread_stalled_on_instruction_memory[i]) begin
                next_thread = thread_count_l2'(i);
                next_thread_valid = true;
            end
        end 
    end
    if (next_thread_valid)
        thread_select_stage_complete = true;
end

word stalls;

always_ff @(posedge clk) begin
    if (reset) begin
        pc[0] = reset_pc;
        current_thread = 0;
        stalls = 0;
    end
    else begin
        if (current_stage == stage_thread_select) begin
            if (next_thread_valid) begin
                current_thread = next_thread;
                pc[current_thread] = next_pcs[current_thread];
            end
            else begin
                stalls++;
                /// No active thread
                /// We'll spin here, but this is where low-power mode would go
            end
        end
    end
end

/*

 Stage control

 */
always_ff @(posedge clk) begin
    if (reset) begin
        current_stage <= stage_fetch;
    end
    else begin
        case (current_stage)
            stage_fetch:
                if (thread_stalled_on_instruction_memory[current_thread])
                    current_stage <= stage_thread_select;
                else if (fetched_instruction_valid)
                    current_stage <= stage_decode;
            stage_decode:
                current_stage <= stage_execute;
            stage_execute:
                current_stage <= stage_mem;
            stage_mem:
                if (memory_stage_complete)
                    current_stage <= stage_writeback;
            stage_writeback:
                if (writeback_stage_complete)
                    current_stage <= stage_thread_select;
            stage_thread_select:
                if (thread_select_stage_complete)
                    current_stage <= stage_fetch;
            default:
                current_stage <= stage_fetch;
        endcase
    end
end

function string stage_name(stage name);
    case (name)
        stage_fetch:    return "fetch  ";
        stage_decode:   return "decode ";
        stage_execute:  return "execute";
        stage_mem:      return "memory ";
        stage_writeback:return "writeba";
        stage_thread_select:return "threads";
        default: return "error";
    endcase 
endfunction

always_ff @(posedge clk) begin
//    if (current_thread != 0)
//        $display("[%d] %s: %x fetched_instruction = %x valid=%d", current_thread, stage_name(current_stage), pc[current_thread],
//                fetched_instruction, fetched_instruction_valid);
end

word debug_counter;
always_ff @(posedge clk) begin
    if (reset)
        debug_counter <= 0;
    else begin
        debug_counter <= debug_counter + 1;
        if ((debug_counter & 64'h0000_0000_000f_ffff) == 64'd0) begin
            $display("Counter: %d - Stalls: %d Stalls percent: %d",
                debug_counter, stalls, stalls * 100 / debug_counter);
/*
            for (integer i = 0; i < thread_count; i++) begin
                $write("PC[%d] = %x   IS=%b II=%b IF=%b IA=%x   ",
                    
                    i, pc[i],

                    thread_stalled_on_instruction_memory[i],
                    stalled_fetch_transactions[i].issued,
                    stalled_fetch_transactions[i].finished,
                    stalled_fetch_transactions[i].addr);
                $write("DS=%b DI=%b DF=%b DA=%x\n",
                    thread_stalled_on_data_memory[i],
                    stalled_memory_transactions[i].valid,
                    stalled_memory_transactions[i].finished,
                    stalled_memory_transactions[i].addr
                    );
            end
*/
        end

    end
end

endmodule : riscv_multicycle_fgmt
`endif
