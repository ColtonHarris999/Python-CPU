`ifndef _riscv_pipelined_v
`define _riscv_pipelined_v

/*

design:
    pipeline is your standard 5 stage pipeline fetch/decode/exec/mem/wb

    The design expects instruction, data and register file to be clocked memories.
    This means read results appear in the next clock cycle.  Register file bypass
    is handled here so that an ordinary SRAM is sufficient.

    The "front end" of this design is fully speculative.  It only needs to respond
    to misprediction signals to start fetching from a corrected new address.
    A small BTB is used at the fetch stage.  A little goes a long way.  The lower two
    bits of the PC are not part of the BTB.  Set btb_bits to 30 to use the full PC
    or trim accordingly to use less space but decrease accuracy.  Size 8, bits 10 
    works fine for small programs.  BTB can be disabled at a 20-25% performance loss.

    The execution stage maintains the correct PC.  Without a BTB this PC is
    optimized away.

    All data memory requests are non-speculative and only appear once per instruction
    meaning the memory system is not expected to be idempotent.  See memory signals
    (below) for further discussoin on interfacing.

    The processor /can/ send spurious instruction requests and can even send
    multiple instruction fetch requests for the same instruction.  The memory
    system should play along.  Bad addresses should be ignored.  Duplicates serviced.

 memory signals:
    addr - address
    write - data to be written
    read - data returned on a read
    write_byte - which byte in the aligned 32 bit address (always aligned) to write
    read_valid - do a read of an aligned 32 bit address
    write_valid - do a write
    ack - asserted atleast one cycle before the data is returned
    ready - asserted at the same time the data is returned

    Note an arbitrary number of cycles is permissable between ack and ready. 
    The semantics of these two signals is "ack" implies the memory system
    accepts the request.  At this point the valid/addr/etc signals can be
    de-asserted or repurposed for the next request.  "valid" is an assertion
    by the memory system the request is ready.

 BTB:
    The BTB is optional (parameter) but generally a good thing, improving
    performance by 20%.  There are two implementations, a tiny CAM and a RAM
    based design.  The RAM is sized to be one BRAM on Xilinx FPGAs.

    Note that both BTBs end up being on the critical path of the design (12-20-2020).
    Currently with 64KB instruction stores, the BTB takes 25% of the critical path
    delay.  Their ultimate usefulness thus may be a wash.

 Future improvement ideas:

    * Add a pipeline stage after reg read that just does bypass (possibly)
    * Add a pipeline stage after execute that does next PC calculation (possibly)
    * Support hardware multiplication (and division?)

*/

`include "base.sv"
`include "system.sv"

`define btb_bram

`include "riscv.sv"
module riscv_pipelined #(
    parameter btb_enable = false          // use a BTB?
    ) (
    input logic       clk
    ,input logic      reset
    ,input logic      [`word_address_size-1:0] reset_pc
    ,output memory_io_req   inst_mem_req
    ,input  memory_io_rsp   inst_mem_rsp
    ,output memory_io_req   data_mem_req
    ,input  memory_io_rsp   data_mem_rsp);

import riscv::*;

localparam btb_size = 8;    // size of tiny BTB
localparam btb_bits = 10;   // bits of the PC

logic fetch_advance, fetch_flush;
logic decode_advance, decode_flush;
logic exec_advance;
logic mem_advance;
logic wb_advance;

logic   decode_in_valid;
logic   decode_in_instruction;

bool    decode_out_valid;
tag     decode_out_rs1;
tag     decode_out_rs2;
tag     decode_out_wbs;
bool    decode_out_wbv;
word    decode_out_imm;
funct3  decode_out_f3;
funct7  decode_out_f7;
opcode_q decode_out_op_q;
instr_format decode_out_format;
word    decode_out_pc;

//
// Vivado will convert our clocked read into an unclocked read
// that occurs in the execution stage.  This can occur even if
// you write the Verilog for an unclocked read in decode.  To
// prevent this unwanted optimization we tag the register file
// as dont_touch.
//
`syn_dont_touch word    exec_in_rd1;
`syn_dont_touch word    exec_in_rd2;

bool    exec_out_valid;

word    exec_out_rd1;
word    exec_out_rd2;
tag     exec_out_rs1;
tag     exec_out_rs2;
tag     exec_out_wbs;
bool    exec_out_wbv;
funct3  exec_out_f3;
opcode_q    exec_out_op_q;
ext_operand exec_out_alu_result;

bool    mem_out_valid;
tag     mem_out_wbs;
bool    mem_out_wbv;
funct3  mem_out_f3;
opcode_q mem_out_op_q;
ext_operand mem_out_alu_result;

word wb_out_wbd;
bool wb_out_wbv;
tag  wb_out_wbs;
bool wb_out_valid;

word_address    pc;
word_address    fetch_pc;
word_address    next_pc_comb;

`syn_ram_no_collision word    reg_file[0:31];


word issued_fetch_pc;
bool fetch_out_valid;
instr32 selected_instruction_read;
bool selected_instruction_response_valid;
word selected_fetch_out_pc;


always_comb begin
    inst_mem_req = memory_io_no_req;

    inst_mem_req.addr = fetch_pc;
    inst_mem_req.do_read[3:0] = 4'b1111;
    inst_mem_req.valid = !reset && inst_mem_rsp.ready;
    inst_mem_req.user_tag = 0;

    if (fetch_out_valid &&
        inst_mem_rsp.valid &&
        inst_mem_rsp.addr == issued_fetch_pc) begin
        selected_instruction_response_valid = true;
        selected_instruction_read = shuffle_store_data(inst_mem_rsp.data, inst_mem_rsp.addr)[31:0];
        selected_fetch_out_pc = inst_mem_rsp.addr;
    end else begin
        selected_instruction_read = 0;
        selected_instruction_response_valid = false;
        selected_fetch_out_pc = 0;
    end
end

always_ff @(posedge clk) begin
    if (reset) begin
        fetch_pc <= reset_pc;
        fetch_out_valid <= false;
        issued_fetch_pc <= 0;
    end else begin
        if (inst_mem_req.valid) begin
            fetch_out_valid <= inst_mem_req.valid; 
            issued_fetch_pc <= fetch_pc;
            if (fetch_advance && selected_instruction_response_valid)
                fetch_pc <= fetch_pc + 4;
        end

        if (fetch_flush) begin
            fetch_pc <= next_pc_comb;
            fetch_out_valid <= false;
        end
    end
end



/*
`ifndef btb_bram

typedef struct packed {
    logic [btb_bits - 1:0]    match_on;
    logic [btb_bits - 1:0]    next_pc;
}   btb_entry;

// Optimized away if btb_enable is false.
btb_entry   btb[0:btb_size - 1];
logic       [$clog2(btb_size) - 1: 0]   btb_replace;
integer     btb_index;

always_ff @(posedge clk) begin
    if (reset) begin
        fetch_pc <= reset_pc;
        if (btb_enable)
            btb_replace <= 0;
    end else begin
        if (fetch_advance) begin
            fetch_pc <= fetch_pc + 4;
            if (btb_enable) begin
                for (btb_index = 0; btb_index < btb_size; btb_index++)
                    if (btb[btb_index].match_on == fetch_pc[btb_bits + 1:2])
                        fetch_pc <= { fetch_pc[31:btb_bits + 2], btb[btb_index].next_pc, 2'b00 };
            end
        end
        if (fetch_flush) begin
            fetch_pc <= next_pc_comb;
            if (btb_enable) begin
                btb[btb_replace] <= { pc[btb_bits + 1:2], next_pc_comb[btb_bits + 1:2] };
                btb_replace <= (btb_replace + 1) == btb_size ? 0 : btb_replace + 1;
            end
        end
    end
end

`else

/// This style of BTB uses a ram. 
/// Sizes are set here to uses one BRAM for a Xilinx 36Kbit BRAM device
///
/// The don_touch attribute prevents Vivado from pushing the read into
/// the next clock cycle.... which is not what we intended from
/// a max path perspective. 
`syn_ram_no_collision logic [`word_size - 1:0]    btb[0:1024-1];
`syn_dont_touch logic [`word_size - 1:0]    btb_read;
logic [`word_size - 1:0]    btb_alternate;
logic           btb_use_alternate;

initial begin
    if (btb_enable)
        for (int i = 0; i < 1024; i++)
            btb[i] = 0;
end
always_ff @(posedge clk) begin
    if (reset) begin
        fetch_pc <= reset_pc;
        if (btb_enable) begin
            btb_use_alternate <= true;
            btb_alternate <= reset_pc;
        end
    end else begin
        if (fetch_advance) begin
            if (btb_enable)
                fetch_pc <= (btb_use_alternate) ? btb_alternate : btb_read;
            else
                fetch_pc <= fetch_pc + 4;
        end
        if (fetch_flush) begin
            fetch_pc <= next_pc_comb;
            if (btb_enable) begin
                btb[fetch_pc[10 + 2 - 1:2]] <= next_pc_comb;
                btb_alternate <= next_pc_comb + 4;
                btb_use_alternate <= true;
            end
        end else if (btb_enable) begin
            btb_use_alternate <= false;
        end
        if (btb_enable) begin
            btb_read <= btb[fetch_pc[10 + 2 - 1:2]];
        end
    end
end

`endif
*/

word    reg_file_bypass_rd;
tag     reg_file_bypass_rs;
bool    reg_file_bypass_valid;

initial begin
    for (int i = 0; i < 32; i++)
        reg_file[i] = `word_size'd0;
end

always_ff @(posedge clk) begin
    word    wbd;
    automatic bool set_invalid = false;
    automatic tag     rs1 = decode_rs1(selected_instruction_read);
    automatic tag     rs2 = decode_rs2(selected_instruction_read);
    automatic opcode_q op_q = decode_opcode_q(selected_instruction_read);
    automatic instr_format format = decode_format(op_q);
    automatic tag read_reg_rs1;
    automatic tag read_reg_rs2;

    if (reset)
        reg_file_bypass_valid <= false;

    if (reset || decode_flush) begin
        decode_out_valid <= false;
        set_invalid = true;
    end else begin
        if (decode_advance) begin

            if (selected_instruction_response_valid)
                decode_out_valid <= true;
            else
                set_invalid = true;

            decode_out_rs1 <= rs1;
            decode_out_rs2 <= rs2;
            decode_out_wbs <= decode_rd(selected_instruction_read);
            decode_out_f3 <= decode_funct3(selected_instruction_read);
            decode_out_op_q <= op_q;
            decode_out_format <= format;
            decode_out_imm <= decode_imm(selected_instruction_read, format);
            decode_out_wbv <= decode_writeback(op_q);
            decode_out_f7 <= decode_funct7(selected_instruction_read, format);
            decode_out_pc <= selected_fetch_out_pc;
        end else if (exec_advance) begin
            decode_out_valid <= false;
            set_invalid = true;
        end

    end

    if (decode_advance) begin
        read_reg_rs1 = rs1;
        read_reg_rs2 = rs2;
    end else begin
        read_reg_rs1 = decode_out_rs1;
        read_reg_rs2 = decode_out_rs2;
    end

    // If stalled we read the register file for the previously decoded instruction
    // This is subtle but simplifies some of the bypass logic
    exec_in_rd1 <= reg_file[read_reg_rs1];
    exec_in_rd2 <= reg_file[read_reg_rs2];            


    ////// Not necessary, but can aid in debugging
    if (set_invalid) begin
        decode_out_rs1 <= 0;
        decode_out_rs2 <= 0;
        decode_out_wbs <= 0;
        decode_out_f3 <= 0;
        decode_out_op_q <= q_op;
        decode_out_format <= r_format;
        decode_out_imm <= 0;
        decode_out_wbv <= 0;
        decode_out_f7 <= 0;
        decode_out_pc <= 0;
    end

    // Write back
    if (!reset && wb_advance && wb_out_valid && wb_out_wbv) begin
        reg_file[wb_out_wbs] <= wb_out_wbd;
        reg_file_bypass_rs <= wb_out_wbs;
        reg_file_bypass_rd <= wb_out_wbd;
        reg_file_bypass_valid <= true;
    end

end

ext_operand exec_result_comb;
word exec_bypassed_rd1;
word exec_bypassed_rd2;
logic fetch_mispredict;

word exec_rd1;
word exec_rd2;

always_comb begin
    word rd1;
    word rd2;

    // By pass in the following priority: zero, from start of mem, from start of WB, from completed WB, and finally reg file
    rd1 =   
            // Zero takes priority over all
            ((decode_out_rs1 == 5'd0) ? `word_size'd0 :
            // Bypass from start of memory stage when not a load
            ((decode_out_rs1 == exec_out_wbs && exec_out_valid && exec_out_wbv && exec_out_op_q != q_load && exec_out_op_q != q_amo) ? exec_out_alu_result[`word_size - 1:0] :
            // Bypass from writeback
            ((decode_out_rs1 == mem_out_wbs && mem_out_valid && wb_out_wbv) ? wb_out_wbd :
            // Bypass on write-through on the register file
            ((decode_out_rs1 == reg_file_bypass_rs && reg_file_bypass_valid) ? reg_file_bypass_rd
            // Believe the register file
                : exec_in_rd1))));

    rd2 =   ((decode_out_rs2 == 5'd0) ? `word_size'd0 :
            ((decode_out_rs2 == exec_out_wbs && exec_out_valid && exec_out_wbv && exec_out_op_q != q_load) ? exec_out_alu_result[`word_size - 1:0] :
            ((decode_out_rs2 == mem_out_wbs && mem_out_valid && wb_out_wbv) ? wb_out_wbd :
            ((decode_out_rs2 == reg_file_bypass_rs && reg_file_bypass_valid) ? reg_file_bypass_rd : exec_in_rd2))));

    exec_rd1 = rd1;
    exec_rd2 = rd2;

    exec_bypassed_rd1 = rd1;
    exec_bypassed_rd2 = rd2;

    exec_result_comb = execute(
        cast_to_ext_operand(rd1),
        cast_to_ext_operand(rd2),
        cast_to_ext_operand(decode_out_imm),
        decode_out_pc,
        decode_out_op_q,
        decode_out_f3,
        decode_out_f7);

    // "ground truth" for the next PC comes from this calculation.
    next_pc_comb = compute_next_pc(
        cast_to_ext_operand(rd1),
        exec_result_comb,
        decode_out_imm,
        decode_out_pc,
        decode_out_op_q,
        decode_out_f3);

    if (decode_out_valid && next_pc_comb != selected_fetch_out_pc)
        fetch_mispredict = true;
    else
        fetch_mispredict = false;

end

word exec_out_pc;

always_ff @(posedge clk) begin
    if (reset) begin
        exec_out_valid <= false;
        pc <= reset_pc;
    end else begin
        if (exec_advance) begin
            pc <= next_pc_comb;
            exec_out_rd1 <= exec_bypassed_rd1;
            exec_out_rd2 <= exec_bypassed_rd2;
            exec_out_rs1 <= decode_out_rs1;
            exec_out_rs2 <= decode_out_rs2;
            exec_out_wbs <= decode_out_wbs;
            exec_out_wbv <= decode_out_wbv;
            exec_out_f3 <= decode_out_f3;
            exec_out_op_q <= decode_out_op_q;
            exec_out_alu_result <= exec_result_comb;
            exec_out_valid <= decode_out_valid;
            exec_out_pc <= decode_out_pc;
        end else if (mem_advance)
            exec_out_valid <= false;
    end
end

always_comb begin
    automatic word  rd2;
    automatic word  rd1;

    data_mem_req = memory_io_no_req;

    rd2 = `word_size'd0;

    // Bypass in the result of a load.  This also ends up (re)bypassing rs2 on non-load instruction
    rd2 =   ((exec_out_rs2 == 5'd0) ? `word_size'd0 :
            ((exec_out_rs2 == wb_out_wbs && wb_out_valid && wb_out_wbv) ? wb_out_wbd :
            ((exec_out_rs2 == reg_file_bypass_rs && reg_file_bypass_valid) ? reg_file_bypass_rd : exec_out_rd2)));

    rd1 =   ((exec_out_rs1 == 5'd0) ? `word_size'd0 :
            ((exec_out_rs1 == wb_out_wbs && wb_out_valid && wb_out_wbv) ? wb_out_wbd :
            ((exec_out_rs1 == reg_file_bypass_rs && reg_file_bypass_valid) ? reg_file_bypass_rd : exec_out_rd1)));

    // We stall on MEM / WB stalling.  Otherwise we continue to issue the
    if (mem_advance && exec_out_valid &&
        (exec_out_op_q == q_store || exec_out_op_q == q_load || exec_out_op_q == q_amo)) begin
        data_mem_req.addr = exec_out_alu_result[`word_address_size - 1:0];
        data_mem_req.user_tag = 0;
        if (exec_out_op_q == q_store) begin
            data_mem_req.valid = true;
            data_mem_req.do_write = shuffle_store_mask(memory_mask(cast_to_memory_op(exec_out_f3)), exec_out_alu_result[`word_size - 1:0]);
            data_mem_req.data = shuffle_store_data(rd2, exec_out_alu_result[`word_size - 1:0]);
        end
        else if (exec_out_op_q == q_load) begin  // q_load
            data_mem_req.valid = true;
            data_mem_req.do_read = shuffle_store_mask(memory_mask(cast_to_memory_op(exec_out_f3)), exec_out_alu_result[`word_size - 1:0]);
        end
        else if (exec_out_op_q == q_amo) begin
            data_mem_req.addr = rd1;
            data_mem_req.data = rd2;
            data_mem_req.valid = true;
            if (exec_out_f3 == f3_amo_d) begin
                data_mem_req.do_write = {(`word_size_bytes){1'b1}};
                data_mem_req.do_read = {(`word_size_bytes){1'b1}};
            end
        end
    end
end

always_ff @(posedge clk) begin
    if (reset)
        mem_out_valid <= false;
    else
    if (mem_advance) begin
        mem_out_wbs <= exec_out_wbs;
        mem_out_wbv <= exec_out_wbv;
        mem_out_f3 <= exec_out_f3;
        mem_out_op_q <= exec_out_op_q;
        mem_out_alu_result <= exec_out_alu_result;
        mem_out_valid <= exec_out_valid;
    end else if (wb_advance)
        mem_out_valid <= false;
end

always_comb begin
    if (wb_advance && mem_out_valid) begin
        if (mem_out_op_q == q_load || mem_out_op_q == q_amo) begin
            wb_out_wbd = subset_load_data(
                                shuffle_load_data(data_mem_rsp.data, mem_out_alu_result[`word_size - 1:0]),
                                cast_to_memory_op(mem_out_f3));
            // Stall pipeline unti load returns
            wb_out_valid = data_mem_rsp.valid & mem_out_valid;
        end else if (mem_out_op_q == q_store) begin 
            wb_out_wbd = mem_out_alu_result[`word_size - 1:0];
            // Stores do not require confirmation to advance
            wb_out_valid = mem_out_valid;
        end else begin
            wb_out_wbd = mem_out_alu_result[`word_size - 1:0];
            // Non load/stores just move through
            wb_out_valid = mem_out_valid;
        end
        wb_out_wbv = mem_out_wbv & wb_out_valid;
        wb_out_wbs = mem_out_wbs;
    end else begin
        wb_out_valid = false;
        wb_out_wbs = 0;
        wb_out_wbv = false;
        wb_out_wbd = 0;
    end
end


// Stall / Flush logic 
always_comb begin
    // Start with everything running smooth
    fetch_advance = true;
    decode_advance = true;
    exec_advance = true;
    mem_advance = true;
    wb_advance = true;

    fetch_flush = false;
    decode_flush = false;

    // Fetch can be issued, but the memory system says it won't be handled.
    if (!inst_mem_rsp.ready) begin
        fetch_advance = false;
        decode_advance = false;
        exec_advance = false;
    end

    // Fetch issued, but reply is late
    if (fetch_out_valid && !inst_mem_rsp.valid) begin
        fetch_advance = false;
        decode_advance = false;
        exec_advance = false;
    end

    // Trying to issue a load / store but memory system is indicating it cannot accept it.
    if (exec_out_valid
        && (exec_out_op_q == q_load
            || exec_out_op_q == q_store || exec_out_op_q == q_amo)
        && !data_mem_rsp.ready) begin
        fetch_advance = false;
        decode_advance = false;
        exec_advance = false;
        mem_advance = false;
        //wb_advance = false;
    end

    // Load/store has been issued but the response has not come back yet.
    if (mem_out_valid
        && (mem_out_op_q == q_load || mem_out_op_q == q_store || mem_out_op_q == q_amo)
        && !data_mem_rsp.valid) begin
        fetch_advance = false;
        decode_advance = false;
        exec_advance = false;
        mem_advance = false;
        wb_advance = false;
    end        

    // Load use
    if (decode_out_valid && exec_out_valid
        && (exec_out_op_q == q_load || exec_out_op_q == q_amo)
        && ((exec_out_wbs == decode_out_rs1) ||
            (exec_out_wbs == decode_out_rs2))) begin
        fetch_advance = false;
        decode_advance = false;
        exec_advance = false;
    end

    if (fetch_mispredict && exec_advance) begin
        fetch_flush = true;
        decode_flush = true;
    end

end

endmodule : riscv_pipelined

`endif
