`ifndef _memory_sv
`define _memory_sv

`include "system.sv"
`include "memory_io.sv"

module memory32 #(
    parameter size = 4096                       // in bytes
    ,parameter initialize_mem = 0
    ,parameter byte0 = "data0.hex"
    ,parameter byte1 = "data1.hex"
    ,parameter byte2 = "data2.hex"
    ,parameter byte3 = "data3.hex"
    ,parameter enable_rsp_addr = 1
    ) (
    input   clk
    ,input  reset

    ,input memory_io_req32  req
    ,output memory_io_rsp32 rsp
    );

    localparam size_l2 = $clog2(size);

    // Data memory
    reg [7:0]   data0[0:size/4 - 1];
    reg [7:0]   data1[0:size/4 - 1];
    reg [7:0]   data2[0:size/4 - 1];
    reg [7:0]   data3[0:size/4 - 1];

    initial begin
        // Vivado simulation fills the BRAM with X's and this makes a complete mess of
        // branch mis-predictions that come from the processor.
        for (int i = 0; i < size/4; i++) begin
            data0[i] = 8'd0;
            data1[i] = 8'd0;
            data2[i] = 8'd0;
            data3[i] = 8'd0;
        end

        if (initialize_mem) begin
            $readmemh(byte0, data0, 0);
            $readmemh(byte1, data1, 0);
            $readmemh(byte2, data2, 0);
            $readmemh(byte3, data3, 0);
        end
    end

    always @(posedge clk) begin
        rsp <= memory_io_no_rsp32;
        if (req.valid) begin
            rsp.user_tag <= req.user_tag;
            if (is_any_byte32(req.do_read)) begin
                if (enable_rsp_addr)
                    rsp.addr <= req.addr;
                rsp.valid <= 1'b1;
                rsp.user_tag <= req.user_tag;
                rsp.data[7:0] <= data0[req.addr[size_l2 - 1:2]];
                rsp.data[15:8] <= data1[req.addr[size_l2 - 1:2]];
                rsp.data[23:16] <= data2[req.addr[size_l2 - 1:2]];
                rsp.data[31:24] <= data3[req.addr[size_l2 - 1:2]];
            end else if (is_any_byte32(req.do_write)) begin
                if (enable_rsp_addr)
                    rsp.addr <= req.addr;
                rsp.valid <= 1'b1;
                rsp.user_tag <= req.user_tag;
                if (req.do_write[0]) data0[req.addr[size_l2 - 1:2]] <= req.data[7:0];
                if (req.do_write[1]) data1[req.addr[size_l2 - 1:2]] <= req.data[15:8];
                if (req.do_write[2]) data2[req.addr[size_l2 - 1:2]] <= req.data[23:16];
                if (req.do_write[3]) data3[req.addr[size_l2 - 1:2]] <= req.data[31:24];
            end else begin
                rsp.valid <= 1'b0;
            end
        end
    end

endmodule


module memory64 #(
    parameter size = 4096                       // in bytes
    ,parameter initialize_mem = 0
    ,parameter byte0 = "data0.hex"
    ,parameter byte1 = "data1.hex"
    ,parameter byte2 = "data2.hex"
    ,parameter byte3 = "data3.hex"
    ,parameter byte4 = "data4.hex"
    ,parameter byte5 = "data5.hex"
    ,parameter byte6 = "data6.hex"
    ,parameter byte7 = "data7.hex"
    ,parameter enable_rsp_addr = 1
    ) (
    input   clk
    ,input  reset

    ,input memory_io_req64  req
    ,output memory_io_rsp64 rsp
    );

    localparam size_l2 = $clog2(size);

    // Data memory
    reg [7:0]   data0[0:size/8 - 1];
    reg [7:0]   data1[0:size/8 - 1];
    reg [7:0]   data2[0:size/8 - 1];
    reg [7:0]   data3[0:size/8 - 1];
    reg [7:0]   data4[0:size/8 - 1];
    reg [7:0]   data5[0:size/8 - 1];
    reg [7:0]   data6[0:size/8 - 1];
    reg [7:0]   data7[0:size/8 - 1];

    initial begin
        // Vivado simulation fills the BRAM with X's and this makes a complete mess of
        // branch mis-predictions that come from the processor.
        for (int i = 0; i < size/8; i++) begin
            data0[i] = 8'd0;
            data1[i] = 8'd0;
            data2[i] = 8'd0;
            data3[i] = 8'd0;
            data4[i] = 8'd0;
            data5[i] = 8'd0;
            data6[i] = 8'd0;
            data7[i] = 8'd0;
        end

        if (initialize_mem) begin
            $readmemh(byte0, data0, 0);
            $readmemh(byte1, data1, 0);
            $readmemh(byte2, data2, 0);
            $readmemh(byte3, data3, 0);
            $readmemh(byte4, data4, 0);
            $readmemh(byte5, data5, 0);
            $readmemh(byte6, data6, 0);
            $readmemh(byte7, data7, 0);
        end
    end

    logic            phase;
    logic            two_phase;
    memory_io_req64  saved_req;
    memory_io_req64  use_req;

    always_comb begin
        if (phase == zero)
            use_req = req;
        else 
            use_req = saved_req;
    end

    always @(posedge clk) begin
        if (req.valid && phase == one)
            $display("***REQ on memory while not READY");

        rsp <= memory_io_no_rsp64;
        if (reset) begin
            phase <= zero;
            saved_req <= memory_io_no_req64;
        end else begin
            saved_req <= req;

            if (use_req.valid || phase == one) begin
                if (is_any_byte64(use_req.do_read) && is_any_byte64(use_req.do_write))
                    two_phase = true;
                else 
                    two_phase = false;

                if (two_phase && phase == zero) begin
                    //$display("AMOSWAP detected. %x Data to be written: %x %x %x %x",
                    //    use_req.addr, use_req.data, req.addr, saved_req.addr, use_req.addr);
                end
                if (phase == zero && is_any_byte64(use_req.do_read)) begin
                    rsp.data[7:0] <= data0[use_req.addr[size_l2 - 1:3]];
                    rsp.data[15:8] <= data1[use_req.addr[size_l2 - 1:3]];
                    rsp.data[23:16] <= data2[use_req.addr[size_l2 - 1:3]];
                    rsp.data[31:24] <= data3[use_req.addr[size_l2 - 1:3]];
                    rsp.data[39:32] <= data4[use_req.addr[size_l2 - 1:3]];
                    rsp.data[47:40] <= data5[use_req.addr[size_l2 - 1:3]];
                    rsp.data[55:48] <= data6[use_req.addr[size_l2 - 1:3]];
                    rsp.data[63:56] <= data7[use_req.addr[size_l2 - 1:3]];

                    rsp.user_tag <= use_req.user_tag;
                    rsp.valid <= true;
                    if (enable_rsp_addr)
                        rsp.addr <= use_req.addr;

                    if (two_phase) begin
                        rsp.ready <= false;
                        phase <= one;
                    end
                end else if (((phase == zero && !two_phase) || phase == one) && is_any_byte64(use_req.do_write)) begin
                    //if (phase == one)
                    //    $display("SECOND PHASE %x Data to be written: %x", use_req.addr, use_req.data);

                    if (use_req.do_write[0]) data0[use_req.addr[size_l2 - 1:3]] <= use_req.data[7:0];
                    if (use_req.do_write[1]) data1[use_req.addr[size_l2 - 1:3]] <= use_req.data[15:8];
                    if (use_req.do_write[2]) data2[use_req.addr[size_l2 - 1:3]] <= use_req.data[23:16];
                    if (use_req.do_write[3]) data3[use_req.addr[size_l2 - 1:3]] <= use_req.data[31:24];
                    if (use_req.do_write[4]) data4[use_req.addr[size_l2 - 1:3]] <= use_req.data[39:32];
                    if (use_req.do_write[5]) data5[use_req.addr[size_l2 - 1:3]] <= use_req.data[47:40];
                    if (use_req.do_write[6]) data6[use_req.addr[size_l2 - 1:3]] <= use_req.data[55:48];
                    if (use_req.do_write[7]) data7[use_req.addr[size_l2 - 1:3]] <= use_req.data[63:56];

                     // See above.  On two phase operations (e.g. AMOSWAP) we respond on the first phase
                    if (phase == zero) begin
                        rsp.user_tag <= use_req.user_tag;
                        rsp.valid <= true;
                        if (enable_rsp_addr)
                            rsp.addr <= use_req.addr;
                    end                    
                    phase <= zero;
                end

            end
        end
    end
endmodule

`ifdef __64bit__
`define memory memory64
`else
`define memory memory32
`endif

`endif
