#!/bin/bash

source ./site-config.sh

if [ "$RISCV_MODEL" == "_32bit" ] ; then
    extra=""
else
    extra="-64"
fi


$RISCV_PREFIX-objcopy -O binary -j .text -g $1 $1.bin
./dumphex $extra -i $1.bin -o code -base 0 -size 0x10000 -strip -byte
rm $1.bin

$RISCV_PREFIX-objcopy -O binary -R .text -g $1 $1.bin
./dumphex $extra -i $1.bin -o data -base 0 -size 0x10000 -strip -byte
#rm $1.bin


#./dumphex -i $1.bin -o code -base 0 -size 65536 -strip -word
#./dumphex -64 -i $1.bin -o data -base 65536 -size 65536 -strip -word




