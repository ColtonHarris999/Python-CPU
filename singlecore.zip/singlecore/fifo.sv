`ifndef _fifo_v
`define _fifo_v
module fifo #(
            // TODO: Add pass through?  Add simultanious insert/delete when at capacity?
             parameter fifo_depth = 2
            ,parameter type fifo_type = logic) (
             input logic     clk
            ,input logic     reset

            ,input fifo_type in
            ,input logic     in_valid
            ,output logic    in_ready

            ,output fifo_type out 
            ,output logic    out_valid
            ,input logic     out_ready
            );

    logic [$clog2(fifo_depth) - 1:0]    head;
    logic [$clog2(fifo_depth) - 1:0]    tail;
    fifo_type data[0:fifo_depth - 1];

    logic [$clog2(fifo_depth) - 1:0]    next_head;
    logic [$clog2(fifo_depth) - 1:0]    next_tail;
    logic has_space;
    logic has_data;

    assign next_head = (head + 1) == fifo_depth ? 0 : head + 1;
    assign next_tail = (tail + 1) == fifo_depth ? 0 : tail + 1;
    assign has_data = (head != tail);
    assign has_space = (next_head != tail);
    //
    // this is the logic for simultanious insert/delete.
    // enable if you dare.
    // assign has_space = (next_head != tail) || (out_ready);  

    assign in_ready = has_space;
    assign out_valid = has_data;
    assign out = data[tail];

    always_ff @(posedge clk) begin
        if (reset) begin
            head <= 0;
            tail <= 0;
        end
        else begin
            // Manage insertions
            if (in_valid && has_space) begin
                data[head] <= in;
                head <= next_head;
            end

            // Manage removals
            if (out_ready && has_data) begin
                tail <= next_tail;
            end
        end
    end
endmodule

`endif