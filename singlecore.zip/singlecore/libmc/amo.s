.text
#.ifdef _64bit
.globl amoswap64

amoswap64:
    amoswap.d  a0, a1, (a0)
    ret
#.endif
