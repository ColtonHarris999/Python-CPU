.text
.globl pause

pause:
    add  a0, zero, zero
    addi a1, zero, 10
loop_here:
    addi a0, a0, 1
    blt a0, a1, loop_here
    ret

