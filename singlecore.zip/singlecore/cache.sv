/*

 Cache module.

    Features:
        + configurable line size, set size, and associativity.
        + non-blocking MSHR handling
        + Can be disabled for true pass-through functionality
        + 1 cycle hit access
        + Supports a pipelined downstream memory system
        + Supports out of order upstream requests
    Limitations:
        - direct mapped is not supported.  It wouldn't be difficult to
        add but the math used in the addressing assumes associativity is 2 or more
        - When a MSHR is active for a set further hits to that set
        are permitted, but no further misses.
        - On "error" conditions such MSHR conflicts, the current design
        spends a couple extra cycles when it wouldn't need to.
        - MSHRs store the line.  This is done to simplify the logic
        and to enable concurrent access with the memory sending responses.
        But the down side to this is the extra space.
*/

`include "system.sv"
`include "riscv.sv"

typedef struct packed {
    bool valid;
    bool dirty;
} cache_meta_data_t;

localparam initial_cache_meta_data = 2'b00;

module compute_lru #(
    parameter set_count = 4
    ) (
    input logic [$clog2(set_count) - 1:0] mru
    ,input logic [$clog2(set_count) - 1:0] lru_in[0:set_count-1]
    ,output logic [$clog2(set_count) - 1:0] lru
    ,output logic [$clog2(set_count) - 1:0] lru_out[0:set_count-1]
    );

function logic [$clog2(set_count) - 1:0] cast_to_lru(integer i);
    return ($clog2(set_count))'(i);
endfunction

always_comb begin
    lru = cast_to_lru(0);
    for (integer i = 0; i < set_count; i++)
        if (lru_in[i] == 0)
            lru = cast_to_lru(i);

    for (integer i = 0; i < set_count; i++) begin
        lru_out[i] = 0;
        if (lru_in[i] < mru)
            lru_out[i] = lru_in[i];
        else if (cast_to_lru(i) == mru)
            lru_out[i] = {$clog2(set_count){1'b1}};
        else 
            lru_out[i] = lru_in[i] - 1;
    end
end

endmodule

module cache_set #(
    parameter set_size = 32
    ,parameter line_size = 64
    ,parameter set_count = 4 
    ,parameter initial_lru_value = 0
    ) (
    input clk
    ,input reset

    ,input bool do_write_in
    ,input riscv::word write_address_in
    ,input [line_size * 8 - 1:0] line_in
    ,input cache_meta_data_t cache_meta_data_in

    ,input bool do_read_in
    ,input riscv::word read_address_in
    ,output riscv::word address_out
    ,output [line_size * 8 - 1:0] line_out
    ,output cache_meta_data_t cache_meta_data_out
    ,input [$clog2(set_count)-1:0] lru_in
    ,output [$clog2(set_count)-1:0] lru_out
    ,input bool do_lru_update_in
    );

import riscv::*;

localparam set_size_l2 = $clog2(set_size);
localparam line_size_l2 = $clog2(line_size);
localparam lru_size_l2 = $clog2(set_count);
localparam size_of_byte = 8;

typedef logic [set_size_l2 - 1:0]               index_t;
typedef logic [line_size * size_of_byte -1:0]   line_t;
typedef logic [lru_size_l2 - 1:0]               lru_t;
typedef logic [line_size_l2 - 1:0]              line_address_t;
typedef logic [line_size_l2 - 1 + 3:0]          line_bit_address_t;
typedef logic [size_of_byte-1:0]                line_as_array_t[0:line_size-1];
typedef logic [`word_size - set_size_l2 - line_size_l2 - 1:0] cache_tag_t;



function word form_address(input cache_tag_t cache_tag, input index_t index, input line_address_t line_address);
    return { cache_tag, index, line_address };
endfunction    

function index_t index(input word address);
    return address[set_size_l2 + line_size_l2 - 1:line_size_l2];
endfunction

function cache_tag_t cache_tag(input word address);
    return address[`word_size - 1: set_size_l2 + line_size_l2];
endfunction

function line_address_t line_address(input word address);
    return address[line_size_l2 - 1:0];
endfunction

line_t            lines[0:set_size-1];
cache_tag_t       tags[0:set_size-1];
cache_meta_data_t cache_meta_data[0:set_size-1];
lru_t             lru[0:set_size-1];

word last_read_address_in;
cache_tag_t       tag_out;

assign address_out = form_address(tag_out,
    index(last_read_address_in),
    line_address(last_read_address_in));

always_ff @(posedge clk) begin
    if (reset) begin
        for (integer i = 0; i < set_size; i++) begin
            cache_meta_data[i] <= initial_cache_meta_data;
            lru[i] <= initial_lru_value;
        end
    end else begin
        if (do_read_in) begin
            line_out <= lines[index(read_address_in)];
            cache_meta_data_out <= cache_meta_data[index(read_address_in)];
            tag_out <= tags[index(read_address_in)];
            lru_out <= lru[index(read_address_in)];
            last_read_address_in <= read_address_in;
        end
        if (do_write_in) begin
            // Written this way with the variable because V erilator is lame
            automatic index_t write_index = index(write_address_in);
            lines[write_index] <= line_in;
            cache_meta_data[write_index] <= cache_meta_data_in;
            tags[write_index] <= cache_tag(write_address_in);
        end
        if (do_lru_update_in) begin
            automatic index_t write_index = index(write_address_in);
            lru[write_index] <= lru_in;
        end
    end
end
endmodule

module cache #(
    parameter set_size = 32
    ,parameter line_size = 64
    ,parameter set_count = 4
    ,parameter mshr_count = 16
    ) (
    input clk
    ,input reset
    ,input enabled_in
    ,input memory_io_req            upstream_mem_req_in
    ,output memory_io_rsp           upstream_mem_rsp_out
    ,output memory_io_req           downstream_mem_req_out
    ,input  memory_io_rsp           downstream_mem_rsp_in
    );

import riscv::*;

localparam set_size_l2 = $clog2(set_size);
localparam line_size_l2 = $clog2(line_size);
localparam line_size_in_words = line_size / `word_size_bytes;
localparam lru_size_l2 = $clog2(set_count);
localparam size_of_byte = 8;

typedef logic [$clog2(set_count)-1:0]           set_number_t;
typedef logic [set_size_l2 - 1:0]               index_t;
typedef logic [line_size * size_of_byte -1:0]   line_t;
typedef logic [line_size_l2 - 1:0]              line_address_t;
typedef logic [line_size_l2 - 1 + 3:0]          line_bit_address_t;
typedef logic [size_of_byte-1:0]                line_as_array_t[0:line_size-1];
typedef logic [lru_size_l2 - 1:0]               lru_t;
typedef logic [`word_size - set_size_l2 - line_size_l2 - 1:0] cache_tag_t;

function word form_address(input cache_tag_t cache_tag, input index_t index, input line_address_t line_address);
    return { cache_tag, index, line_address };
endfunction    

function index_t index(input word address);
    return address[set_size_l2 + line_size_l2 - 1:line_size_l2];
endfunction

function cache_tag_t cache_tag(input word address);
    return address[`word_size - 1: set_size_l2 + line_size_l2];
endfunction

function line_address_t line_address(input word address);
    return address[line_size_l2 - 1:0];
endfunction

function line_bit_address_t line_bit_address(input word address);
    return { line_address(address), 3'b000 };
endfunction

function line_bit_address_t line_bit_address_base(input word address);
    return { line_address({ address[`word_size - 1 -: `word_size - $clog2(`word_size_bytes)], $clog2(`word_size_bytes)'(0) } ), 3'b000 };
endfunction

function line_as_array_t line_to_array(input line_t line);
    line_as_array_t result;
    for (integer i = 0; i < line_size; i++)
        result[i] = line[i * size_of_byte -: size_of_byte];
    return result;
endfunction

function line_t array_to_line(input line_as_array_t line);
    line_t result;
    for (integer i = 0; i < line_size; i++)
        result[i * size_of_byte -: size_of_byte] = line[i];
    return result;
endfunction    

function word extract_word(input line_t line, input word address);
    //$display("Returning: %x : %x", address, line[line_bit_address(address) + `word_size - 1 -: `word_size]);
    return line[line_bit_address_base(address) + `word_size - 1 -: `word_size];
endfunction

function line_t update_data(
    input line_t line
    ,input word address
    ,input word data
    ,input bool [`word_size_bytes-1:0] mask);
    line_t new_line;
    new_line = line;
    //$display("update_data: address=%x base_bit=%x", address, line_bit_address_base(address));
    for (integer i = 0; i < `word_size_bytes; i++)
        if (mask[i]) begin
            //$display("Writing into: [%d -: 8] value %x",
            //    line_bit_address_base(address) + ($bits(line_bit_address_t) + 1)'((i + 1) * size_of_byte) - 1,
            //    data[(i + 1) * size_of_byte - 1 -: size_of_byte]                
            //    );
            new_line[line_bit_address_base(address) + ($bits(line_bit_address_t) + 1)'((i + 1) * size_of_byte) - 1 -: size_of_byte] = data[(i + 1) * size_of_byte - 1 -: size_of_byte];
        end
    return new_line;
endfunction

function logic [$clog2(set_count) - 1:0] cast_to_lru(integer i);
    return ($clog2(set_count))'(i);
endfunction

// When enabled_in == false the internal state machine is locked to idle.
/* verilator lint_off UNOPTFLAT */
memory_io_rsp upstream_internal_io_rsp;
memory_io_req upstream_internal_io_req;
memory_io_rsp downstream_internal_io_rsp;
memory_io_req downstream_internal_io_req;
/* verilator lint_on UNOPTFLAT */
assign downstream_internal_io_rsp = enabled_in == false ? memory_io_no_rsp : downstream_mem_rsp_in;
assign upstream_internal_io_req = enabled_in == false ? memory_io_no_req : upstream_mem_req_in;
assign upstream_mem_rsp_out = enabled_in == false ? downstream_mem_rsp_in : upstream_internal_io_rsp;
assign downstream_mem_req_out = enabled_in == false ? upstream_mem_req_in : downstream_internal_io_req;

word read_address;
word write_address;
line_t line_to_write;
cache_meta_data_t cache_meta_data_to_write;
line_t line_read[0:set_count-1];
cache_meta_data_t cache_meta_data_read[0:set_count-1];
word address_read[0:set_count-1];

bool do_read;
bool do_write[0:set_count-1];
bool do_lru_update;
lru_t lru_read[0:set_count-1];
lru_t lru_to_write[0:set_count-1];

generate for (genvar mg = 0; mg < set_count; mg++) begin
    cache_set #(
            .set_size(set_size)
            ,.line_size(line_size)
            ,.set_count(set_count)
            ,.initial_lru_value(mg))
        the_cache_set(.clk(clk),.reset(reset)

            ,.do_write_in(do_write[mg])            
            ,.write_address_in(write_address)
            ,.line_in(line_to_write)
            ,.cache_meta_data_in(cache_meta_data_to_write)

            ,.do_read_in(do_read)
            ,.read_address_in(read_address)
            ,.address_out(address_read[mg])
            ,.line_out(line_read[mg])
            ,.cache_meta_data_out(cache_meta_data_read[mg])
            ,.lru_in(lru_to_write[mg])
            ,.lru_out(lru_read[mg])
            ,.do_lru_update_in(do_lru_update)
            );            
    end
endgenerate

typedef struct packed {
    bool            valid;
    bool            completed;
    bool            do_fetch;
    bool            do_writeback;
    word            address;
    set_number_t    allocated_set;
    line_t          line;
    memory_io_req   upstream_memory_io_req;
    logic [line_size_l2-1:0]    sent;
    logic [line_size_l2-1:0]    received;
} mshr_t;

mshr_t  mshrs[0:mshr_count-1];

typedef enum {
    // Cache will only accept upstream (from core) requests when idle.
    // In this state the request is routed to the cache memory banks.
    idle

    // In this state the cache response is formulated.  A hit is
    // responded to during (combinatorially) in this cycle, leading to 1 cycle hit
    ,finish_read_of_internal_state

    // In this state we setup the replay of a saved transactions, usually
    // a fetch from downstream (memory) and subsequent replay of delayed request
    ,retry_memory_operation

    // This is an error state.  We bounce here and then back to retry_memory_operaiton
    // when we do not have enough MSHRs to handle the miss.  However, we also
    // just don't accept them (see combinatorial logic), so this state can go away
    // or we can accept requests more liberally.
    ,no_free_mshr

    // This state occurs when the upstream request misses and the particular set
    // has outstanding MSHR traffic on it.  In this situation we monitor the MSHRs
    // waiting for them to finish and when they replay first the deferred transaction
    // and finally the transaction from upstream, which gets tucked away in _copy
    ,concurrent_mshr_retry

    // This is similar to concurrent_mshr_retry but does not retire finished MSHR
    // entries.  The state machine could be modified to remove this state and just
    // use concurrent_mshr_retry
    ,use_saved_copy
} state_t;


state_t state;

// Primary saved upstream request
memory_io_req saved_upstream_mem_req_in;

// Use for concurrent handling of MSHR retirements and requests.
memory_io_req saved_upstream_mem_req_in_copy;

set_number_t    matching_set;
bool            matching_set_valid;

lru_t mru;
lru_t lru;

assign mru = matching_set;
compute_lru #(.set_count(set_count)) the_update_lru (
    .mru(mru)
    ,.lru_in(lru_read)
    ,.lru(lru)
    ,.lru_out(lru_to_write)
);

logic [$clog2(mshr_count)-1:0] wrote_mshr_to_cache;
bool wrote_mshr_to_cache_valid;

logic [$clog2(mshr_count)-1:0] allocated_mshr;
bool allocated_mshr_valid;
logic [$clog2(mshr_count)-1:0] second_allocated_mshr;
bool second_allocated_mshr_valid;
logic [$clog2(mshr_count)-1:0] last_processed_mshr;
bool concurrent_mshr;

// Performance counters
word hits;
word fetches;
word writebacks;

always_comb begin
    // Initialize wires to avoid latches
    automatic logic [$clog2(mshr_count):0]    free_mshrs = 0;

    upstream_internal_io_rsp = memory_io_no_rsp;
    upstream_internal_io_rsp.ready = false;
    read_address = 0;
    write_address = 0;
    for (integer i = 0; i < set_count; i++)
        do_write[i] = false;
    do_read = false;
    cache_meta_data_to_write = {($bits(cache_meta_data_t)){1'b0}};
    wrote_mshr_to_cache_valid = false;
    wrote_mshr_to_cache = 0;
    line_to_write = {($bits(line_to_write)){1'b0}};
    do_lru_update = false;
    concurrent_mshr = false;
    allocated_mshr_valid = false;
    allocated_mshr = 0;
    second_allocated_mshr_valid = false;
    second_allocated_mshr = 0;

    // We constantly scan the MSHRs preparing two for use
    for (integer i = 0; i < mshr_count; i++) begin
        if (!mshrs[i].valid)
            free_mshrs = free_mshrs + 1;
        if (!allocated_mshr_valid && !mshrs[i].valid) begin
            allocated_mshr = $clog2(mshr_count)'(i);
            allocated_mshr_valid = true;
        end else
        if (allocated_mshr_valid && !second_allocated_mshr_valid
            && !mshrs[i].valid) begin
            second_allocated_mshr = $clog2(mshr_count)'(i);
            second_allocated_mshr_valid = true;
        end
    end

    //$display("Cache miss on %x", saved_upstream_mem_req_in.addr);
    for (integer i = 0; i < mshr_count; i++) begin
        // For now we do not support concurrent
        // MSHRs that are accessing the same set.  When this
        // occurs we go to a retry state
        if (mshrs[i].valid && //mshrs[i].do_fetch &&
            form_address(
                0,
                index(saved_upstream_mem_req_in.addr),
                0) ==
            form_address(
                0,
                index(mshrs[i].address),
                0))
            concurrent_mshr = true;
    end


    if (state == idle && free_mshrs >= 2)
        upstream_internal_io_rsp.ready = true;

    read_address = saved_upstream_mem_req_in.addr;
    write_address = saved_upstream_mem_req_in.addr;

    if (state == idle && upstream_internal_io_req.valid) begin 
        read_address = upstream_internal_io_req.addr;
        do_read = true;
    end else if (state == retry_memory_operation) begin
        read_address = saved_upstream_mem_req_in.addr;  // Redundant for clarity
        do_read = true;
    end

    //// Isn't reliable in comb blocks
    //if (state != idle && state != update_internal_state && upstream_internal_io_req.valid) begin
    //    $display("Upstream mem_req while cache indicates it is busy state=%d", state);
    //end

    // Figure out if we have the address we are interested in.
    matching_set_valid = false;
    matching_set = 0;
    for (integer i = 0; i < set_count; i++) begin
        if (cache_meta_data_read[i].valid
            && cache_tag(address_read[i]) == cache_tag(saved_upstream_mem_req_in.addr)) begin
                matching_set_valid = true;
                matching_set = cast_to_lru(i);
        end
        //if (state == finish_read_of_internal_state)
        //    $display("%d comparing %x to %x tag %x to %x -- %b/%d meta: %b",
        //        i, address_read[i], saved_upstream_mem_req_in.addr,
        //        cache_tag(address_read[i]),
        //        cache_tag(saved_upstream_mem_req_in.addr),
        //        matching_set_valid,
        //        matching_set,
        //        cache_meta_data_read[i].valid
        //        );
    end

    if (state == finish_read_of_internal_state
        && matching_set_valid
        && saved_upstream_mem_req_in.do_read != 0) begin
        upstream_internal_io_rsp.valid = true;
        upstream_internal_io_rsp.addr = saved_upstream_mem_req_in.addr;
        upstream_internal_io_rsp.user_tag = saved_upstream_mem_req_in.user_tag;
        upstream_internal_io_rsp.data = extract_word(line_read[matching_set],
                                            saved_upstream_mem_req_in.addr);
        //$display("returning data: %x: %x", 
        //    saved_upstream_mem_req_in.addr,
        //    upstream_internal_io_rsp.data);
        do_lru_update = true;
        //$display("Read return: %x", upstream_internal_io_rsp.data);
    end

    // not an 'else'.  This lets us handle AMOSWAP
    // If we match and we are writing we update the data.
    if (state == finish_read_of_internal_state
        && matching_set_valid
        && saved_upstream_mem_req_in.do_write != 0) begin

        // Communicate upstream that this request is handled, but see the _ff block for details
        upstream_internal_io_rsp.valid = true;
        upstream_internal_io_rsp.addr = saved_upstream_mem_req_in.addr;
        upstream_internal_io_rsp.user_tag = saved_upstream_mem_req_in.user_tag;

        cache_meta_data_to_write.valid = true;
        cache_meta_data_to_write.dirty = true;
        do_write[matching_set] = true;

        line_to_write = update_data(
            line_read[matching_set]
            ,saved_upstream_mem_req_in.addr
            ,saved_upstream_mem_req_in.data
            ,saved_upstream_mem_req_in.do_write);
        do_lru_update = true;

        //$display("Writing data: %x:%x mask=%x"
        //    ,saved_upstream_mem_req_in.addr
        //    ,saved_upstream_mem_req_in.data
        //    ,saved_upstream_mem_req_in.do_write);

        //$display("Doing write: %x %x", write_address, line_to_write);
    end else begin
        // Cache miss.
        // See below

    end

    // When idle and not being used, look at the MSHRs for any that need to be
    // moved into the cache proper.
    if ((state == idle || state == concurrent_mshr_retry)
        && !upstream_internal_io_req.valid) begin
        for (integer i = 0; i < mshr_count; i++) begin
            if (!wrote_mshr_to_cache_valid
                && mshrs[i].valid
                && mshrs[i].received == line_size_l2'(line_size_in_words)) begin

                wrote_mshr_to_cache_valid = true;
                wrote_mshr_to_cache = ($bits(wrote_mshr_to_cache))'(i);

                if (mshrs[i].do_fetch) begin
                    //$display("Writing cache line: %x set %d value: %x",
                    //    mshrs[i].address, mshrs[i].allocated_set, mshrs[i].line);
                    cache_meta_data_to_write.valid = true;
                    cache_meta_data_to_write.dirty = false;
                    line_to_write = mshrs[i].line;
                    write_address = mshrs[i].address;
                    do_write[mshrs[i].allocated_set] = true;
                end
            end
        end
    end else if (state == finish_read_of_internal_state
        && !matching_set_valid && !concurrent_mshr) begin
        // If we are going to move this line into an MSHR for writeback
        // invalidate it in the cache.
        //$display("Invalidating cache line: %x", saved_upstream_mem_req_in.addr);
        cache_meta_data_to_write.valid = false;
        cache_meta_data_to_write.dirty = false;
        write_address = saved_upstream_mem_req_in.addr;
        do_write[lru] = true;
    end

    downstream_internal_io_req = memory_io_no_req;
    if (downstream_internal_io_rsp.ready
        && mshrs[last_processed_mshr].valid
        ) begin
        if (mshrs[last_processed_mshr].do_fetch
            && mshrs[last_processed_mshr].sent != line_size_l2'(line_size_in_words)
            ) begin
            downstream_internal_io_req.valid = true;
            downstream_internal_io_req.user_tag = `user_tag_size'(last_processed_mshr);
            downstream_internal_io_req.addr = mshrs[last_processed_mshr].address +
                (`word_size'(mshrs[last_processed_mshr].sent) << $clog2(`word_size_bytes));
            downstream_internal_io_req.do_read = `whole_word;
        end else if (mshrs[last_processed_mshr].do_writeback &&
            mshrs[last_processed_mshr].sent != line_size_l2'(line_size_in_words)
            ) begin
            downstream_internal_io_req.valid = true;
            downstream_internal_io_req.user_tag = `user_tag_size'(last_processed_mshr);
            downstream_internal_io_req.addr = mshrs[last_processed_mshr].address +
                (`word_size'(mshrs[last_processed_mshr].sent) << $clog2(`word_size_bytes));
            downstream_internal_io_req.do_write = `whole_word;
            downstream_internal_io_req.data = extract_word(
                mshrs[last_processed_mshr].line, (`word_size'(mshrs[last_processed_mshr].sent) << $clog2(`word_size_bytes)));
        end
    end
end


bool req_copy_valid;

always_ff @(posedge clk) begin
    if (reset) begin
        for (integer i = 0; i < mshr_count; i++) begin
            mshrs[i].valid <= false;
        end
        last_processed_mshr <= 0;
        req_copy_valid <= false;
        hits <= 0;
        writebacks <= 0;
        fetches <= 0;
    end else begin
        automatic integer next_valid_mshr = 0;
        automatic bool next_valid_mshr_valid = false;
        // Process any incoming responses
        if (downstream_internal_io_rsp.valid) begin
            automatic integer mshr = integer'(downstream_internal_io_rsp.user_tag);
            //if (!mshrs[mshr].valid)
            //    $display("Curious, memory response to invalid MSHR");
            if (mshrs[mshr].do_fetch) begin
                //$display("Fetched: %x:%x to insert into line",
                //    downstream_internal_io_rsp.addr,
                //    downstream_internal_io_rsp.data);
                mshrs[mshr].line <= update_data(mshrs[mshr].line,
                    downstream_internal_io_rsp.addr,
                    downstream_internal_io_rsp.data,
                    `whole_word);
                mshrs[mshr].received <= mshrs[mshr].received + 1;
            end else if (mshrs[mshr].do_writeback) begin
                mshrs[mshr].received <= mshrs[mshr].received + 1;
            end
        end

        // Study the MSHRs and process any that we can
        if (downstream_internal_io_rsp.ready
            && mshrs[last_processed_mshr].valid
            ) begin
            if (mshrs[last_processed_mshr].sent != line_size_l2'(line_size_in_words)
                ) begin
                mshrs[last_processed_mshr].sent <= mshrs[last_processed_mshr].sent + 1;
            end
        end else if (!mshrs[last_processed_mshr].valid) begin
            for (integer i = 0; i < mshr_count; i++) begin
                if (!next_valid_mshr_valid
                    && mshrs[i].valid
                    && $clog2(mshr_count)'(i) != last_processed_mshr) begin
                    next_valid_mshr = i;
                    next_valid_mshr_valid = true;
                end
            end
            last_processed_mshr <= $clog2(mshr_count)'(next_valid_mshr);
        end

        case (state)
            idle: begin
                if (upstream_internal_io_req.valid) begin
                    state <= finish_read_of_internal_state;
                    saved_upstream_mem_req_in <= upstream_internal_io_req;
                    saved_upstream_mem_req_in_copy <= upstream_internal_io_req;
                    //$display("New REQ: addr:%x index=%d",
                    //    upstream_internal_io_req.addr,
                    //    index(upstream_internal_io_req.addr));
                end else begin
                    if (wrote_mshr_to_cache_valid) begin
                        if (mshrs[wrote_mshr_to_cache].do_fetch) begin
                            saved_upstream_mem_req_in <= mshrs[wrote_mshr_to_cache].upstream_memory_io_req;
                            //$display("MSHR complete, going to retry state");
                            state <= retry_memory_operation;
                        end
                        mshrs[wrote_mshr_to_cache].valid <= false;
                    end
                end
            end
            finish_read_of_internal_state: begin
                if (matching_set_valid) begin
                    // Cache has the data, process the request and respond
                    hits <= hits + 1;
                    if (req_copy_valid)
                        state <= use_saved_copy;
                    else
                        state <= idle;
                end else begin
                    if (concurrent_mshr) begin 
                        //$display("Concurrent MSHR.  Retrying");
                        state <= concurrent_mshr_retry;
                    end else begin
                        // Search for one or two MSHRs to use
                        if (!allocated_mshr_valid) begin
                            //$display("No MSHRs left");
                            state <= no_free_mshr;
                        end
                        if (cache_meta_data_read[lru].valid
                            && cache_meta_data_read[lru].dirty &&
                            !second_allocated_mshr_valid) begin
                            //$display("One MSHR left but two are needed");
                            state <= no_free_mshr;
                        end

                        //$display("Setting up fetch MSHR: %d words=%d", allocated_mshr, line_size_in_words);
                        mshrs[allocated_mshr].valid <= true;
                        mshrs[allocated_mshr].allocated_set <= lru;
                        mshrs[allocated_mshr].address <= form_address(
                            cache_tag(saved_upstream_mem_req_in.addr),
                            index(saved_upstream_mem_req_in.addr),
                            line_size_l2'(0));
                        mshrs[allocated_mshr].do_fetch <= true;
                        mshrs[allocated_mshr].upstream_memory_io_req <= saved_upstream_mem_req_in;
                        mshrs[allocated_mshr].do_writeback <= false;
                        mshrs[allocated_mshr].sent <= 0;
                        mshrs[allocated_mshr].received <= 0;
                        fetches <= fetches + 1;
                        if (cache_meta_data_read[lru].valid
                            && cache_meta_data_read[lru].dirty) begin
                            //$display("Setting up Writeback MSHR: %d", second_allocated_mshr);
                            mshrs[second_allocated_mshr].valid <= true;
                            mshrs[second_allocated_mshr].allocated_set <= 0;
                            mshrs[second_allocated_mshr].address <= form_address(
                                cache_tag(address_read[lru]),
                                index(address_read[lru]),
                                0);
                            mshrs[second_allocated_mshr].do_fetch <= false;
                            mshrs[second_allocated_mshr].upstream_memory_io_req <= memory_io_no_req;
                            mshrs[second_allocated_mshr].do_writeback <= true;
                            mshrs[second_allocated_mshr].line <= line_read[lru];
                            mshrs[second_allocated_mshr].sent <= 0;
                            mshrs[second_allocated_mshr].received <= 0;
                            writebacks <= writebacks + 1;
                        end
                        //$display("MSHRs allocated, returning to idle: %b:%d and %b:%d",
                        //    allocated_mshr_valid, 
                        //    allocated_mshr,
                        //    second_allocated_mshr_valid,
                        //    second_allocated_mshr);

                        state <= idle;
                    end
                end
            end
            retry_memory_operation: begin
                // This is a normal state.  Occurs when a read from memory finishes
                // and we retry the memory operation.
                //$display("Retrying memory operation: %x", saved_upstream_mem_req_in.addr);
                state <= finish_read_of_internal_state;
            end

            // These are error states.  Not much to do but attempt to retry 
            // the memory operation.
            no_free_mshr: begin
                //$display("Out of MSHRs");
                state <= retry_memory_operation;
            end
            concurrent_mshr_retry: begin
                //$display("Concurrent MSHR");
                if (wrote_mshr_to_cache_valid) begin
                    if (mshrs[wrote_mshr_to_cache].do_fetch) begin
                        saved_upstream_mem_req_in <= mshrs[wrote_mshr_to_cache].upstream_memory_io_req;
                        //$display("MSHR complete, going to retry state");
                        state <= retry_memory_operation;
                    end
                    req_copy_valid <= true;
                    mshrs[wrote_mshr_to_cache].valid <= false;
                end else begin
                    req_copy_valid <= false;
                    saved_upstream_mem_req_in <= saved_upstream_mem_req_in_copy;
                    state <= retry_memory_operation;
                end
            end
            use_saved_copy: begin
                //$display("Restarting saved copy REQ");
                saved_upstream_mem_req_in <= saved_upstream_mem_req_in_copy;
                req_copy_valid <= false;
                state <= retry_memory_operation;
            end
        endcase
    end
end

endmodule
