`ifndef _ports_v
`define _ports_v


// Width of all port accesses
`define port_address_size 20


`define port_cpu_halt `port_address_size'h0
`define port_is_halted `port_address_size'h8
`define port_cpu_reset `port_address_size'h10
`define port_accelerator_control_in `port_address_size'h18
`define port_accelerator_control_out `port_address_size'h20
`define port_net_sync_read_return `port_address_size'h30
`define port_net_sync_write `port_address_size'h38
`define port_net_sync_read `port_address_size'h40
`define port_net_async_read `port_address_size'h48
`define port_config_timer_high `port_address_size'h50
`define port_config_timer_low `port_address_size'h58
`define port_config_space_tiles_x `port_address_size'h60
`define port_config_space_tiles_y `port_address_size'h68
`define port_config_space_tile_x `port_address_size'h70
`define port_config_space_tile_y `port_address_size'h78
`define port_config_space_is_host `port_address_size'h80
`define port_config_space_local_memories `port_address_size'h88
`define port_config_space_max_local_size `port_address_size'h90
`define port_config_space_memory_size `port_address_size'h98
`define port_config_space_atomic_inc `port_address_size'ha0
`define port_putc `port_address_size'ha8
`define port_axi00_control `port_address_size'h100
`define port_axi00_busy `port_address_size'h108
`define port_axi00_addr_low `port_address_size'h110
`define port_axi00_addr_high `port_address_size'h118
`define port_axi00_buffer_size `port_address_size'h120
`define port_axi_control_start `port_address_size'h200
`define port_axi_control_done `port_address_size'h208
`define port_axi_control_ready `port_address_size'h210
`define port_axi_control_idle `port_address_size'h218
`define port_axi_control_scalar00 `port_address_size'h220
`define port_axi_control_scalar01 `port_address_size'h228
`define port_axi_control_scalar02 `port_address_size'h230
`define port_axi_control_scalar03 `port_address_size'h238
`define port_axi_control_a_low `port_address_size'h240
`define port_axi_control_a_high `port_address_size'h248
`define port_axi_control_b_low `port_address_size'h250
`define port_axi_control_b_high `port_address_size'h258
`define port_axi00_data_base `port_address_size'h280
`define fgmt_internal_mmio_low `port_address_size'h10000
`define fgmt_internal_mmio_high `port_address_size'h20000


`endif
